#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <cstring>
#include <set>
#include <queue>
#include <algorithm>
#include <vector>
#include <map>
#include <cctype>
#include <cmath>
#include <stack>
#include <sstream>
#include <list>
#include <assert.h>
#include <bitset>
#include <numeric>
#define debug() puts("++++")
#define gcd(a, b) __gcd(a, b)
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define fi first
#define se second
#define pb push_back
#define sqr(x) ((x)*(x))
#define ms(a,b) memset(a, b, sizeof a)
#define sz size()
#define be begin()
#define ed end()
#define pu push_up
#define pd push_down
#define cl clear()
#define lowbit(x) -x&x
#define all 1,n,1
#define FOR(i,n,x)  for(int i = (x); i < (n); ++i)
#define freopenr freopen("in.in", "r", stdin)
#define freopenw freopen("out.out", "w", stdout)
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> P;
const int INF = 0x3f3f3f3f;
const LL LNF = 1e17;
const double inf = 1e20;
const double PI = acos(-1.0);
const double eps = 1e-8;
const int maxn = 5e5 + 7;
const int maxm = 2000000 + 7;
const LL mod = 1e9 + 9;
const int dr[] = {-1, 1, 0, 0, 1, 1, -1, -1};
const int dc[] = {0, 0, 1, -1, 1, -1, 1, -1};
int n, m;
inline bool is_in(int r, int c) {
	return r >= 0 && r < n && c >= 0 && c < m;
}





int f[maxn];

void getFail(char *s){
	f[0] = f[1] = 0;
	for(int i = 1; s[i]; ++i){
		int j = f[i];
		while(j && s[i] != s[j])  j = f[j];
		f[i+1] = s[i] == s[j] ? j + 1: 0;
	}
}



void get_inverse(){
	inv[1] = 1;
	for(int i = 2; i < mod; ++i){
		f[i] = (mod - mod/i) * inv[mod%i] % mod;
	}
}

struct Edge{
	int from, to, dist;
};
struct HeapNode{
	int d, u;
	bool operator < (const HeapNode &rhs) const{
		return d > rhs.d;
	}
};



struct Dijkstra{
	int n, m;
	vector<Edge> edges;
	vector<int> G[maxn];
	int d[maxn];
	bool done[maxn];
	int p[maxn];

	void init(int n){
		this->n = n;
		for(int i = 0; i < n; ++i)  G[i].cl;
		edges.cl;
	}

	void add_edge(int from, int to, int dist){
		edges.pb((Edge){from, to, dist});
		edges.pb((Edge){to, from, dist});
		G[from].pb(edges.sz-2);
		G[to].pb(edges.sz-1);
	}

	void dijkstra(int s){
		ms(d, INF);  ms(done, 0); ms(p, -1);
		d[s] = 0;
		priority_queue<HeapNode> pq;
		pq.push((HeapNode){0, s});

		while(!pq.empty()){
			HeapNode x = pq.top();  pq.pop();
			int u = x.u;
			if(done[u])  continue;
			done[u] = true;
			for(auto &i: G[u]){
				Edge &e = edges[i];
				if(d[e.to] > d[u] + e.dist){
					d[e.to] = d[u] + e.dist;
					pq.push((HeapNode){d[e.to], e.to});
					p[e.to] = u;
				}
			}
		}
	}
};


bool vis[maxn];
int match[maxn];

void dfs(int u){
	vis[u] = true;
	for(auto &v: G[u]){
		int w = match[v];
		if(w == -1 || !vis[w] && dfs(w)){
			match[u] = v;
			match[v] = u;
			return true;
		}
	}
	return false;
}


void exgcd(int a, int b, int &d, int &x, int &y){
	if(!b){ d = a;  a = 1; y = 0; }
	else{ exgcd(b, a%b, d, y, x);  y -= x*(a/b);  }
}



struct Edge{
	int from, to, cap, flow;
};

struct Dinic{
	int n, m, s, t;
	vector<Edge>edges;
	vector<int> G[maxn];
	int cur[maxn];
	int d[maxn];
	bool vis[maxn];

	void init(int n){
		this->n = n;
		edges.cl;
		for(int i = 0; i < n; ++i)  G[i].cl;
	}

	void add_edge(int from, int to, int cap){
		edges.pb((Edge){from, to, cap, 0});
		edges.pb((Edge){to, from, 0, 0});
		G[from].pb(edges.sz - 2);
		G[to].pb(edges.sz - 1);
	}

	bool bfs(){
		ms(vis, 0);
		d[s] = 0;  vis[s] = true;
		queue<int> q;  q.push(s);
		while(!q.empty()){
			int u = q.front();  q.pop();
			for(auto &i: G[u]){
				Edge &e = edges[i];
				if(!vis[e.to] && e.flow < e.cap){
					d[e.to] = d[u] + 1;
					q.push(e.to);
					vis[e.to] = true;
				}
			}
		}
		return vis[t];
	}

	int dfs(int u, int a){
		if(u == t || a == 0)  return a;
		int flow = 0, f;
		for(int &i = cur[u]; i < G[u].sz; ++i){
			Edge &e = edges[G[u][i]];
			if(d[e.to] == d[u] + 1 && (f = dfs(e.to, min(a, e.cap-e.flow)))){
				flow += f;
				edges[G[u][i]].flow += f;
				edges[G[u][i]^1] -= f;
				a -= f;
				if(a == 0)  break;
			}
		}
		return flow;
	}

	int max_flow(int s, int t){
		this->s = s;
		this->t = t;
		int ans = 0;
		while(bfs()){ ms(cur, 0);  ans += dfs(s, INF); }
		return ans;
	}
};





struct Trie{
	int ch[maxnode][sigma];
	int val[maxn];
	int sz;

	void init(){
		ms(ch[0], 0);
		sz = 1;
	}

	int idx(char ch){ return c - 'a'; }

	void insert(char *s){
		int u = 0;
		for(int i = 0; s[i]; ++i){
			int c = idx(s[i]);
			if(!ch[u][c]){
				ms(ch[sz], 0]);
				val[sz] = 0;
				ch[u][c] = sz++;
			}
			u = ch[u][c];
		}
		val[u] = 1;
	}

	int query(char *s){
		int u = 0;
		for(int i = 0; s[i]; ++i){
			int c = idx(s[i]);
			if(!ch[u][c])  return 0;
			u = ch[u][c];
		}
		return val[u];
	}
};


struct Aho{
	int ch[maxnode][sigma];
	int val[maxnode];
	int f[maxnode];
	int last[maxnode];
	int sz;

	void init(){
		ms(ch[0], 0);
		sz = 1;
	}

	int idx(char c){ return c - 'a'; }

	void insert(char *s){
		int u = 0;
		for(int i = 0; s[i]; ++i){
			int c = idx(s[i]);
			if(!ch[u][c]){
				val[sz] = 0;
				ms(ch[sz], 0);
				ch[u][c] = sz++;
			}
			u = ch[u][c];
		}
		val[u] = 1;
	}

	void getFail(){
		queue<int> q;
		for(int i = 0; i < sigma; ++i){
			int u = ch[0][i];
			if(u){
				last[u] = 0;
				f[u] = 0;
				q.push(u);
			}
		}

		while(!q.empty()){
			int r = q.front();  q.pop();
			for(int c = 0; c < sigma; ++c){
				int u = ch[r][c];
				if(!u)  continue;
				q.push(u);
				int v = f[r];
				while(v && !ch[v][c])  v = f[v];
				f[u] = ch[v][c];
				last[u] = val[f[u]] ? f[u] : last[f[u]];
			}
		}
	}

	void query(char *s){
		int j = 0;
		for(int i = 0; s[i]; ++i){
			int c = idx(s[i]);
			while(j && ch[j][c])  j = f[j];
			if(j)  print(j);
			else if(last[j])  print(last[j]);
		}
	}
};

int dfs(int pos, bool is, bool ok){
	if(!pos)  return 1;
	int &ans = dp[pos][is];
	if(ans >= 0)  return ans;
	int n = ok ? a[pos] : 9;
	int res = 0;
	for(int i = 0; i <= n; ++i){
		if(is && i == 2)  continue;
		if(i == 6)  res += dfs(pos-1, true, ok && i == n);
		else res += dfs(pos-1, false, ok && i == n);
	}
	if(!ok)  ans = res;
	return res;
}



struct Edge{
	int from, to, cap, flow, cost;
};

struct MCMF{
	int n, m;
	vector<Edge> edges;
	vector<int> G[maxn];
	bool inq[maxn];
	int d[maxn];
	int a[maxn];
	int p[maxn];

	void init(int n){
		this-> n = n;
		for(int i = 0; i < n; ++i)  G[i].cl;
		edges.cl;
	}

	void add_edge(int from, int to, int cap, int cost){
		edges.pb((Edge){from, to, cap, 0, cost});
		edges.pb((Edge){to, from 0, 0, -cost});
		m = edges.sz;
		G[from].pb(m-2);
		G[to].pb(m-1);
	}

	bool bellmanford(int s, int t, int &flow, int &cost){
		ms(inq, 0);  ms(d, INF); a[s] = INF;  p[s] = 0;
		queue<int> q;  q.push(s);  d[s] = 0;  inq[s] = true;

		while(!q.empty()){
			int u = q.front();  q.pop();
			for(int i = 0; i < G[u].sz; ++i){
				Edge &e = edges[G[u][i]];
				if(e.cap > e.flow && d[e.to] > d[u] + e.cost){
					d[e.to] = d[u] + e.cost;
					p[e.to] = u;
					if(!inq[u])  q.push(e.to);
					inq[e.to] = true;
				}
			}
		}
	}
};




struct Edge{
  int from, to, cap, flow, cost;
};
  
struct MinCostMaxFlow{
  int n, m, s, t;
  vector<Edge> edges;
  vector<int> G[maxn];
  int d[maxn];
  int p[maxn];
  int a[maxn];
  bool inq[maxn];
  
  void init(int n){
    this-> n = n;
    for(int i = 0; i < n; ++i)  G[i].cl;
    edges.cl;
  }
  
  void addEdge(int from, int to, int cap, int cost){
    edges.pb((Edge){from, to, cap, 0, cost});
    edges.pb((Edge){to, from, 0, 0, -cost});
    m = edges.sz;
    G[from].pb(m - 2);
    G[to].pb(m - 1);
  }
  
  bool bellman(int &flow, int &cost){
    ms(d, INF);  d[s] = 0;  ms(inq, 0);  inq[s] = 1;
    p[s] = 0;  a[s] = INF;
    queue<int> q;  q.push(s);
    while(!q.empty()){
      int u = q.front();  q.pop();
      inq[u] = 0;
      for(int i = 0; i < G[u].sz; ++i){
        Edge &e = edges[G[u][i]];
        if(e.cap > e.flow && d[e.to] > d[u] + e.cost){
          p[e.to] = G[u][i];
          d[e.to] = d[u] + e.cost;
          a[e.to] = min(a[u], e.cap - e.flow);
          if(!inq[e.to]){ q.push(e.to);  inq[e.to] = 1; }
        }
      }
    }
    if(d[t] == INF)  return false;
    flow += a[t];
    cost += a[t] * d[t];
    int u = t;
    while(u != s){
      edges[p[u]].flow += a[t];
      edges[p[u]^1].flow -= a[t];
      u = edges[p[u]].from;
    }
    return true;
  }
  
  int minCostMaxFlow(int s, int t){
    this-> s = s;
    this-> t = t;
    int cost = 0, flow = 0;
    while(bellman(flow, cost));
    return cost;
  }
};


vector<int> G[maxn];
int in[maxn];
 
int main(){
  int T;  cin >> T;
  while(T--){
    scanf("%d %d", &n, &m);
    for(int i = 1; i <= n; ++i)  G[i].clear();
    memset(in, 0, sizeof in);
    for(int i = 0; i < m; ++i){
      int a, b;
      scanf("%d %d", &a, &b);
      G[a].push_back(b);
      ++in[b];
    }
    LL ans = 0;
    int mmin = INF;
    priority_queue<int> pq;
    for(int i = 1; i <= n; ++i)  if(!in[i])
      pq.push(i);
 
    while(!pq.empty()){
      int u = pq.top();  pq.pop();
      mmin = min(mmin, u);
      ans += mmin;
      for(int i = 0; i < G[u].size(); ++i){
        int v = G[u][i];  --in[v];
        if(!in[v])  pq.push(v);
      }
    }
    cout << ans << endl;
  }
  return 0;
}





