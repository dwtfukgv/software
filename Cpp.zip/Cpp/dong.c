#include "stdio.h"  // C 语言基础功能
#include "stdlib.h"  // rand 使用的
#include "time.h"  // 时间函数
// include 引入头文件


void guessMagicNum(){
    srand((unsigned)time(NULL));  // 初始化一个随机数的随机种子
    const int num = rand() % 100 + 1;  // 随机一个数字在 [1, 100] rand 是 int 范围的随机数 -2147483648 ～ 2147483647 取模 100 0 - 99
    const int n = 10;

    int i = 1;
    for( ; i <= n; ++i){  // ++i  <=> i += 1  <=> i = i + 1
        printf("Please guess a magic number:");
        int magicNum;
        scanf("%d", &magicNum);
        if(magicNum == num){
            printf("counter = %d\n", i);
            return ;
        }
        printf("Wrong!Too %s!\n", magicNum < num ? "low" : "high");
    }
    printf("counter = %d\n", n);
}

void evaluateService(){
    printf("Please enter the response score of forty students:\n");
    const int n = 10;
    int i = n + 1;
    int score[10] = {0};

    while(--i){
        int x;  scanf("%d", &x);
        ++score[--x];
    }

    printf("Grade    Count    Histogram\n");
    while(i < n){
        int x;
        printf("%5d    %5d    ", i + 1, x = score[i++]);
        while(x--)  putchar('*');  putchar('\n');
    }
}


void guessDigit(){
    srand((unsigned)time(NULL));
    const int length = 4;
    int data[length];
    for(int i = 0; i < length; ++i){
    recompute:
        data[i] = rand() % 10;
        for(int j = 0; j < i; ++j)
            if(data[j] == data[i])  goto recompute;
    }
    
    printf("How many times do you want to guess?");
    int n, i = 1;  scanf("%d", &n);
    for( ; i <= n; ++i){
        printf("No.%d of %d times\n", i, n);
        printf("Please input %d different numbers:\n", length);
        int x;  scanf("%d", &x);
        int index = length;
        int a = 0, b = 0;
        while(index--){
            int num = x % 10;
            x /= 10;
            if(data[index] == num)  ++b;
            else {
                for(int j = 0; j < length; ++j)
                    if(data[j] == num){
                        ++a;  break;
                    }
            }
        }
        printf("%dA%dB\n", a, b);
        if(b == length){
            printf("Congratulations, you got it at No.%d\n", i);
            break;
        }
    }
    if(i > n)  printf("Sorry, you haven't guess the right number!\n");
    printf("Correct answer is:");
    for(int i = 0; i < length; ++i)  printf("%d", data[i]);
    printf("\n");        
}


void diceGame(){
    srand((unsigned)time(NULL));
    int first = rand() % 6 + 1;
    int second = rand() % 6 + 1;
    const int point = first + second;
    printf("Player rolled %d + %d = %d\n", first, second, point);
    if(point == 7 || point == 11)  puts("Palyer wins");
    else if(point == 2 || point == 3 || point == 12)  puts("Player loses");
    else {
        printf("Point is %d\n", point);
        int n = 7;
        while(n--){
            first = rand() % 6 + 1;
            second = rand() % 6 + 1;
            const int sum = first + second;
            printf("Player rolled %d + %d = %d\n", first, second, sum);
            if(sum == point){
                puts("Player wins");
                return;
            }
        }
        puts("Player loses");
    }
}

 
int main(){
    // guessMagicNum();
    // evaluateService();
    // guessDigit();
    diceGame();
    return 0;
}
