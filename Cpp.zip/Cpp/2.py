#!/usr/bin/env python
# -*- coding: utf-8  -*-
import requests
import json
import time
import openpyxl
from datetime import date
import datetime
import sys
import random

fill = '*' * 10
error_fill = '#' * 15

def get_content_response(url, headers):
	cnt = 3
	while cnt:
		cnt -= 1
		try:
			return requests.post(url, headers=headers)
		except Exception as e:
			print(e)
			print(fill, "pulling email content fail", fill)
			if cnt:
				print(fill, "try again", fill)
	return None


url = 'https://partner.outlook.cn/owa/service.svc?action=FindConversation&app=Mail'
headers = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    "action": "FindConversation",
    "content-type": "application/json; charset=utf-8",
    "ms-cv": "vxddw/jxIc9/UWmbRWFGjD.67",
    "sec-ch-ua": "\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"",
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
	"x-owa-canary": "QhD4SfpaMUiB1feS0ly3ojBrg_m1DNkYhR5glNxuzyj3fx1-tJuZpO0xVZepiVsBe6HWMLqXIug.",
    "x-owa-correlationid": "9736814a-47f5-2579-40f5-beaa2e2c9617",
    "x-owa-sessionid": "63604c99-1aa6-461a-9967-729ceefac689",
    "x-owa-urlpostdata": "%7B%22__type%22%3A%22FindConversationJsonRequest%3A%23Exchange%22%2C%22Header%22%3A%7B%22__type%22%3A%22JsonRequestHeaders%3A%23Exchange%22%2C%22RequestServerVersion%22%3A%22V2018_01_08%22%2C%22TimeZoneContext%22%3A%7B%22__type%22%3A%22TimeZoneContext%3A%23Exchange%22%2C%22TimeZoneDefinition%22%3A%7B%22__type%22%3A%22TimeZoneDefinitionType%3A%23Exchange%22%2C%22Id%22%3A%22China%20Standard%20Time%22%7D%7D%7D%2C%22Body%22%3A%7B%22ParentFolderId%22%3A%7B%22__type%22%3A%22TargetFolderId%3A%23Exchange%22%2C%22BaseFolderId%22%3A%7B%22__type%22%3A%22FolderId%3A%23Exchange%22%2C%22Id%22%3A%22AQMkADcyNDYxN2EzLTk3ZDAtNDcxNy04ZjJkLWJhOWRjZGViZTU3ZAAuAAADZYEqpnD0h0ajKHSBYch%2BPwEAUJqLgm%2FkJ0GXuJy%2FACOYHQAAAgEJAAAA%22%7D%7D%2C%22ConversationShape%22%3A%7B%22__type%22%3A%22ConversationResponseShape%3A%23Exchange%22%2C%22BaseShape%22%3A%22IdOnly%22%7D%2C%22ShapeName%22%3A%22ReactConversationSentItemsListView%22%2C%22Paging%22%3A%7B%22__type%22%3A%22IndexedPageView%3A%23Exchange%22%2C%22BasePoint%22%3A%22Beginning%22%2C%22Offset%22%3A0%2C%22MaxEntriesReturned%22%3A25%7D%2C%22ViewFilter%22%3A%22All%22%2C%22SortOrder%22%3A%5B%7B%22__type%22%3A%22SortResults%3A%23Exchange%22%2C%22Order%22%3A%22Descending%22%2C%22Path%22%3A%7B%22__type%22%3A%22PropertyUri%3A%23Exchange%22%2C%22FieldURI%22%3A%22ConversationLastDeliveryTime%22%7D%7D%5D%2C%22FocusedViewFilter%22%3A-1%7D%7D",
    "Cookie": "ClientId=27BEEF93F80E4C4DA5103FD53C573277; OIDC=1; RoutingKeyCookie=v2:9oMjCSbWk8X85d4BvFHZo4oUMtku32nMq1Y2pN+F0C4=:724617a3-97d0-4717-8f2d-ba9dcdebe57d@kanzhun.com; OptInH=kSscmEw7vse0A7b5oePqbmaNbCprvbudh7wn4PZw0ho; MSFPC=GUID=6e60b4e550244dddb8a2a7a57b4b2f0d&HASH=6e60&LV=202104&V=4&LU=1619607173978; UC=1ef7f104ec584346bc9bac307c937320; as=Y2RgYGAEYmYgZjE0M7YEAA; DefaultAnchorMailbox=zhangli02@kanzhun.com; O365Consumer=0; domainName=kanzhun.com; SuiteServiceProxyKey=PIADlnQHhN5I1S9HTN7Xfjlj+JoqCE4PtK4XYYIpWa4=&9lhLDqhVRekEYLQjsoIUAQ==; OutlookSession=9c5e29addd8a4974b2dbdaf04e5d7180; X-OWA-RedirectHistory=AliSSnUBwiBp9LUM2Qg; OpenIdConnect.token.v1=AQAAAAAEAADRuAuCDSIhf2KlbFcoroyL8Y5XGo5K19hYL12kVqeTBkumud3hWCCwYrIpsH9fpjtwkpV91/1buKxpHaWIW2ugz6bd8muoLHNta1jt1dt2R4EU8MxR41nwqkFJUVAiE0Pq9h9TwoWcDVyhWZRgyj3yFcmmB6JjaNx0qNnanlS0O28eraiLbTK2mpW0I2KTWopRF0LsLM1gmwVP8EGSamuEaDM2Pdl0FG1ZeJ1pZSBBFZRpt+zZiKNZm+FRV78i8DuYTi5NIdOWe74iEWoLNe/isTfefxh8tP0qmkdM9xnm6TNNzd1KbO31ba3LnY+3o/4gXMbMxTauFhrJvsKw6To5IiVnNuHBP/VJBXKWkw23LJXfCGWuHopHggwiQWYcMKKJYZXXmKQArVGAzzKTLlKtC5xuUbYUbBNxRe/O+JPNYSJWS/jBKymPGsSJtvGSmhQ0lG8luoIRibHf5FVUNAclOvEnK9W4ZNubZh0I/+CH0Fb8Ba44woq6wDuyCNh5LwxvamO/lDADa7x6kGDKfNlYomA/nx5L+NyCi1fAltImy7diFpVa8NeBkjWbW1O2t0LQyNKXrlkd2Hp+W9tagxtRbQYG519N2db3kgGWQaIjUQMD4Ixk2JQrfzqUsQb142jyx10LZAQC3KhFaxvaKs2JVEg72O0uwSVwlr5SeUYyWnFclS9L2lLgtK64GO3Coome3g6YLQuY/t3JShL6VmhslruSJtnKslSNY2uF2kLa00UozCPk9lUXok/fORWVCyTW5isp5YMnmOYVd8I9fJajj3MkJFvrS6ZqEj37cvaRzXVIbRpQkJOhwaQpHJ0oVkqocZ/UoQ8rJGIKG+dwnQBBHqKo24e3TaebhxWnLSSUF1WQhHY5iNBykRfAreHUnXECYr7dW1NY9FazFDnrDaqRG3JoOyRn4Ripsb0gOfsaSURZNWMzJ0ScLBNwbCyuvJu8jKQF4+V4I0mK6AFcib8MHAVVciD9gtPSyL93e9NqL61UscNOJVETB9jZgfmwr849biOkP/3LaeDSsEtzg6cRlgVpBv861qmKBJnUHfgReZIkzV69t0C4EfYorlxjw5wvK0Qhv+U7ZRNaimY/adj2qUJok145nhw9X7RAfbsGtJ5bSEgJ7Vxn3RGg82SHTVxWcj+lc45JVA+X6kx8sgy8fuKoJaomzQBBykZ2QjYlugFdlXBYvRJ5UWAACKvdvfBreSPHZX8+P1RqcO9X9Td+ZryoDUCUe3Sgy8FKiAtW5FuBI9bSs/q7KSBij+WCeCkJ8+F0sqClsFmFP4i7p0KctRdMkFOZpHdg3DrVRTliwhTbOwedruNvXrrJNIU/6QWnJiOYo0cXBbvrBiGwH0FEAAEAALePr8R3TBysOYakp9f7TF95K+VXKTqPYFv791M/Ra29b2DvQgD6Ruqzlem+Dk+Z2W9GIt2gnadOdo5XcYqYloQuS1Mz8eJmmGTRCp6DuGFHEoQAK3xSHWdvptPdTwGei/mhwG07UWYkcuoI7vGF1+4BLGB1E7UwMcSFZl5NnIfUYB9zPjiMhEmyUAYIyfYsvlQU+Vi8TIcfB9y5F0Yfl/vYw7b2aiY7xsHXgfHgZcHNSJwjrXNnb9/t6t58JU+FWH0vumTSCe2aw3MaJkRXHMfyjJAs3Mu1FLb8N0aKHlteotQgJsV3HIbWOy+R0rEGRBmaCDgqkaxYf+Mt9wNb7msAAQAAuL0pex7c0WdVRbXyZXj2ygaUbee3GY63lcEi7lbGsJv5dSXbvOSG15lKuxM0TGLryn3+h4pwiTB038QdffkIWiZk10yx8Hb5Ffn3ajxhCbp1gHwJM/xkrPQM+OjCrQfKyFiWUMGOwCag61pRa7N62oV0H7dS6wbY3GodIgw62R1WdSdsbp3FzPBuVtl/fEdOWWrrda5fN1e/RzO8u7HOSUNDi/9x21TcTrlEHcSOPWYAOX75ujUfWSvbnjzyRdo4InQAvxBfxabbrZfrnfXdS6oHpPLkOuLuwSAoMw2dm2z34NxUNjdXfTKQBwFgO0VrrZuHTzZZh4UvoDbmkrE9QgABAAA3ywSRVSluFfIBvCUd+9p7sMEAQhT/aqQ9s0sictNyNk++2U+Oqnt1zZwvuC0OAdgIhjel4cM75u80XcNujUFKimBxcX+jxfdCgwCVXbuOjiiMaTbTXYKXUB3ykudeFul++jc8JCPqmUO7YiXIl6e7lUJdEpNRyJ4n5/FTOXhSTWSOlBXbrssTBFnUt4kFxDmA0ge0vUWOYqW2CmLq4JaFyn1QC/6vCXkqSU5BBW5fm1Gh18ltu2FuVn9KCRG2/4ooyoIhMDuE3fi3ffxYfEr8oho3AvjdcmxRAolvf+D8aKfrHixa7Y1deqhG7aMxgD/bkzF5awgIGlBsmBFkslHR; X-OWA-CANARY=QhD4SfpaMUiB1feS0ly3ojBrg_m1DNkYhR5glNxuzyj3fx1-tJuZpO0xVZepiVsBe6HWMLqXIug."
}

init_date = date.fromisoformat('1899-12-30')

remove_mark = (' ', ':', '.', '：', '。', '(', ')', '（', '）', ' ')
threshold = .69

def date_to_days(date_):
	return (date.fromisoformat(date_) - init_date).days

def days_to_date(days):
	return init_date + datetime.timedelta(days=days)

def remove_char(s):
	res = ''
	for c in s:
		if c not in remove_mark:
			res += c
	return res.lower()


def is_match(t1, t2):
	if t1 is None or t2 is None:
		return False
	s1, s2 = remove_char(t1), remove_char(t2)

	dp = [[0 for j in range(len(s2)+5)] for i in range(len(s1)+5)]
	for i in range(1, len(s1) + 1):
		for j in range(1, len(s2) + 1):
			dp[i][j] = (dp[i-1][j-1] + 1 if s1[i-1] == s2[j-1] else max(dp[i-1][j], dp[i][j-1]))
	# print(fill, s1, s2, dp[len(s1)][len(s2)], fill)
	res = dp[len(s1)][len(s2)] * 1.0 / max(len(s1), len(s2))
	if res > threshold:
		print(fill, s1, s2, dp[len(s1)][len(s2)], fill)
	return res



def insert_to_excel(file_name, date_=1, tag_=1, value=1):
	data = (date_, tag_, value)
	wb = openpyxl.load_workbook(file_name)
	wbs = wb.active
	row0, col0 = None, None
	for i in wbs.iter_rows():
		row0 = i
		break
	for i in wbs.iter_cols():
		col0 = i
		break
	# print(len(row0))
	# print(len(col0))
	delta = date_to_days(date_)
	row, col, score = 0, 0, threshold
	for i in range(1, len(col0) + 1):
		if wbs.cell(i, 1).value == delta:
			row = i
			break

	if not row:
		print(error_fill, data, "error not found the row date", date_, error_fill)
		return
	cols = []
	for i in range(1, len(row0) + 1):
		tmp_score = is_match(wbs.cell(1, i).value, tag_)
		if tmp_score > score:
			cols = [i]
			score = tmp_score
		elif tmp_score == score:
			cols.append(i)

	if not cols:
		print(error_fill, data, "warn not found the col tag", tag_, error_fill) 
		return
	if len(cols) > 1:
		print(error_fill, data, "error found more than one col tags", tag_, [wbs.cell(1, i).value for i in cols])
		return
	col = cols[0]
	print(fill, data, "found row:", (row, str(days_to_date(wbs.cell(row, 1).value))), "col:", (col, wbs.cell(1, col).value), fill)
	# print(fill, date_, tag_, row, col, "-----")
	wbs.cell(row, col, value)
	wb.save(file_name)
	# print(rows[3][0].value == (date.fromisoformat('2021-04-02') - init_date).days)
	# _date = date.fromisoformat(row)
	# wb.save(file)




def grab_email_from_outlook(url, headers, is_sleep=True):
	rand = random.randint(1, 3)
	if is_sleep and rand % 3 != 0:
		print("termimal this progress for the rand is", rand)
		return
	if is_sleep:
		t = random.randint(11, 60 * 55)
		print("the progress need sleep", t, "seconds")
		time.sleep(t)
	response = get_content_response(url, headers)
	if response is None:
		print(error_fill, "program scrapes email from outlook failed", error_fill)
		return
	obj = json.loads(response.text)
	print(fill, "program scrapes email from outlook success", fill)
	print(fill, obj, fill)


def resolve_email(start_date, end_date, file_name):
	response = get_content_response(url, headers)
	if response is None:
		print(error_fill, "program scrapes email from outlook failed", error_fill)
		return
	obj = json.loads(response.text)
	print(fill, "program scrapes email from outlook success", fill)
	body = obj.get('Body')
	conversations = body.get('Conversations')
	for conversation in conversations:
		cur_date = conversation.get('LastDeliveryTime')[:10]
		if cur_date < start_date or cur_date > end_date or '总' in conversation.get('ConversationTopic') or '日报' not in conversation.get('ConversationTopic'):
			print(fill, "resolving", conversation.get("LastSender").get("Mailbox").get("Name") + "'s", conversation.get("ConversationTopic"), "email, ingnore this one", fill)
			continue
		print(fill, "resolving", conversation.get("LastSender").get("Mailbox").get("Name") + "'s", conversation.get("ConversationTopic"), "email", fill)
		content = conversation.get('Preview').replace('\r\n\r\n', '\n')
		print(content)
		for line in content.split("\n"):
			print(line)
			line = remove_char(line)
			print(line)
			i = 0
			while i < len(line):
				tag, num = '', 0
				while i < len(line) and not line[i].isdigit():
					tag += line[i]
					i += 1
				while i < len(line) and line[i].isdigit():
					num = num * 10 + ord(line[i]) - ord('0')
					i += 1
				if num:
					print(fill, cur_date, tag, num, fill)
					insert_to_excel(file_name, cur_date, tag, num)
					print("\n")
		# time.sleep(1)
		# return




if __name__ == '__main__':
	if len(sys.argv) == 4:
		resolve_email(sys.argv[1], sys.argv[2], sys.argv[3])
	elif len(sys.argv) == 2:
		grab_email_from_outlook(url, headers, False)
	else:
		grab_email_from_outlook(url, headers)


