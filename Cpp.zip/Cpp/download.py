#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# import urllib2
# import json
# import os
# from lxml import etree
# import shutil


# def get_response_data(url):
#     request = urllib2.Request(url)
#     request.add_header('Accept', 'application/json')
#     response = urllib2.urlopen(request)
#     return response.read()

# if __name__ == '__main__':
# 	res = get_response_data('https://www.shuangyulin.com/inc/ssa.asp?searchClassId=3&q=&PageNo=1')
# 	print res
#     
#     
#     

# print(int(input()) * int(input()))

# a = 1
# print(a)

# ### 整数  浮点数 字符串 字符 布尔
# #   int  float str       True False
# #   

# b = 1.2
# c = "我爱你"
# d = '我爱你'
# e = "1"


# f = int(e) # a
# g = str(a) # e

# h = "1.2"
# i = float(h)

# print(a, b, c, d, e)

# #####

# j = input()
# k = input()
# print(j)
# print("==========")
# print(k)


# # + - * / //
# a = "I "
# b = "love"
# c = a + b  # "I love"
# d = "i " + "love"
# e = "i love"

# a = "i" * 2  # "ii"

# 控制语句

# a = 4
# if a == 1:
#     print("a =4535rettftre", 1)
#     print("====")
# elif a == 2:
#     print("a !=", 1)
#     print("===")
# elif a == 3:
#     print("a >", 2)
# else:
#     print("else")

# # 条件判断  == !=  > < >= <=
# # 输入一个数，如果这个数等于13 输出，这个数的平方，如果这个数等于20，输出这个数，如果等于100，输出101，都不是，输出 我是傻屌

# if not a != 13:

# if a == 13:
#     print()
# if a == 20:
#     print(a)
# if a == 100:
#     print()
# if a != 13:
#     if a != 20:
#         if a != 100:
#             print()

# # 关系  and or not
# if a != 13 and a != 20 and a != 200:
#     print()


# a = int(input())
# if a < 0 or a > 10:
#     print("=====")

# str  len   
a = "i love you"
length = len(a)
print(length)

# list tuple
a = [1, 2, 3, 4, 5]
a.append('i')
a.append(16.0)
print(a)
print(len(a))
a[0] = "a"
print(a) # ["a", 2, 3, 4...]
a[1] = "B"
print(a)
print(a[0])  # "a"
print(a[2])  # 3
b = (1, 2, 3)
print(b)
print(b[0])

b = tuple(a)
print(b)
a = list(b)
a = [1, 2, 1, 2]
print(a)
print(a)

# a.insert(2, "r")
print(a)
# a.pop()
# a.pop(1)

a.remove(2)# [1, 1, 2]
a = [1, 2, 3, 4, 5, 6]
b = a[1:4] # [1, 4)
b = a[:4]
b = a[1:]
print(b)



