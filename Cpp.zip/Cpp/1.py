#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
# File Name: 1.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-05-18 10:50

import importlib.util,subprocess
if importlib.util.find_spec('browsercookie') is None:
   subprocess.check_call(['pip', 'install', 'browsercookie'])
import browsercookie
cookies = browsercookie.safari()
site_cookies = []
mws_cookies=''
for cookie in cookies:
   print(cookie.name)