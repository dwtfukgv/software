public class Foo {
  public static int test() {
    int a = 0;
    try {
      int b = 10 / 0;
      return a = a + 1;
    } catch(Exception e) {
      return a = a + 2;
    } finally {
      return a + 3;
    }
  }


  public static void main(String[] args) {
    System.out.println(test());
  }
}

