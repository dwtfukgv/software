

public class BooleanTest {
    public static void main(String []args){
        String a = "dwt01 34a";
        System.out.println(a.replaceAll("\\d|\\s", ""));
    }
}