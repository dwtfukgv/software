public class Parent<Object> {
    public Number get(Object key){
        return 0;
    }
}

