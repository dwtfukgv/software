#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <cstring>
#include <set>
#include <queue>
#include <algorithm>
#include <vector>
#include <map>
#include <cctype>
#include <ctime>
#include <stack>
#include <sstream>
#include <list>
#include <assert.h>
#include <bitset>
#include <numeric>
#include <unordered_map>
#include <unordered_set>
#define debug() puts("++++")
#define print(x) cout<<"====== "<<(x)<<" ====="<<endl;
// #define gcd(a, b) __gcd(a, b)
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define fi first
#define se second
#define pb emplace_back
#define sqr(x) ((x)*(x))
#define ms(a,b) memset(a, b, sizeof a)
#define _mod(x) ((x) % mod + mod) % mod
#define ls(t, v) t[t.size()-1] = (v)
#define gls(t) t[t.size()-1]
#define es(it) erase(it)
#define rs(n) resize(n)
#define sz size()
#define be begin()
#define ed end()
#define rbe rbegin()
#define red rend()
#define bk back()
#define et empty()
#define ft front()
#define tp top()
#define pp pop()
#define ps push
#define ist insert
#define uset unordered_set
#define umap unordered_map
#define pu push_up
#define pd push_down
#define cl clear()
#define lowbit(x) -x&x
// #define all 1,n,1
#define FOR(i,n,x)  for(int i = (x); i < (n); ++i)
#define freopenr freopen("in.in", "r", stdin)
#define freopenw freopen("out.out", "w", stdout)
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> P;
const int INF = 0x3f3f3f3f;
const LL LNF = 1e17;
const double inf = 1e20;
const double PI = acos(-1.0);
const double eps = 1e-12;
const int maxn = 100000 + 7;
const int maxm = 3000 + 7;
const LL mod = 1e9 + 7;
const int dr[] = {-1, 1, 0, 0, 1, 1, -1, -1};
const int dc[] = {0, 0, 1, -1, 1, -1, 1, -1};
int n, m;

inline bool is_in(int r, int c) {
  return r >= 0 && r < n && c >= 0 && c < m;
}


inline int read_int(){
  int x;  scanf("%d", &x);  return x;
}

int p[100];

inline int Find(int x) {
  return x == p[x] ? x : (p[x] = Find(p[x]));
}

// void quick_sort(int *a, int l, int r) {
//   if (l >= r)  return;
//   int i = l, j = r;
//   int x = a[l];
//   while(i < j) {
//     while(i < j && a[j] >= x)  --j;
//     if (i < j)  a[i++] = a[j];
//     while(i < j && a[i] <= x)  ++i;
//     if (i < j)  a[j--] = a[i];
//   }
//   a[i] = x;
//   quick_sort(a, l, i - 1);
//   quick_sort(a, i + 1, r);
// }

// void merge_sort(int *a, int l, int r, int *t) {
//   if (l >= r)  return;
//   int m = l + r >> 1;
//   merge_sort(a, l, m, t);
//   merge_sort(a, m + 1, r, t);
//   int i = l, j = m + 1, k = 0;
//   while(i <= m && j <= r)  {
//     if (a[i] <= a[j])  t[k++] = a[i++];
//     else t[k++] = a[j++];
//   }
//   while(i <= m)  t[k++] = a[i++];
//   while(j <= r)  t[k++] = a[j++];
//   for(i = l; i <= r; ++i)  a[i] = t[i-l];
// }



// void adjust_heap(int *a, int i, int n) {
//   while(i * 2 + 1 < n) {
//     int l = i * 2 + 1, r = i * 2 + 2;
//     if (r >= n || a[l] > a[r]) {
//       if (a[l] > a[i]) {
//         swap(a[l], a[i]);
//         i = l;
//       } else break;
//     } else {
//       if (a[r] > a[i]) {
//         swap(a[i], a[r]);
//         i = r;
//       } else break;
//     }
//   }
// }

// void build_heap(int *a, int n) {
//   for(int i = n / 2 - 1; i >= 0; --i) {
//     adjust_heap(a, i, n);
//   }
// }

// void heap_sort(int *a, int n) {
//   build_heap(a, n);
//   for (int i = n - 1; i >= 1; --i) {
//     swap(a[i], a[0]);
//     adjust_heap(a, 0, i);
//   }
// }


void quick_sort(int *a, int l, int r) { 
  if (l >= r) {
    return;
  }

  int i = l, j = r;
  int base = a[l];
  while (i < j) {
    while (i < j && a[j] >= base)  --j;
    if (i < j)  a[i++] = a[j];
    while (i < j && a[i] <= base)  ++i;
    if (i < j)  a[j--] = a[i];
  }
  a[i] = base;
  quick_sort(a, l, i - 1);
  quick_sort(a, i + 1, r);
}

void shell_sort(int *a, int n) {
  for (int i = n >> 1; i; i >>= 1) {
    for (int j = i; j < n; ++j) {
      int k = j;
      int base = a[k];
      while (k - i >= 0 && a[k-i] > base)  a[k] = a[k-i], k -= i;
      a[k] = base;
    }
  }
}

void adjust_heap(int *a, int i, int n) {

  while (i * 2 + 1 < n) {
    int l = i * 2 + 1, r = i * 2 + 2;
    if (r >= n || a[l] > a[r]) {
      if (a[l] > a[i]) {
        swap(a[l], a[i]);
        i = l;
      } else break;
    } else if (a[r] > a[i]) {
      swap(a[r], a[i]);
      i = r;
    } else break;
  }
}

void heap_sort(int *a, int n) {

  for (int i = n / 2 - 1; i >= 0; --i) {
    adjust_heap(a, i, n);
  }
  for (int i = n - 1; i >= 0; --i) {
    swap(a[i], a[0]);
    adjust_heap(a, 0, i);
  }
}


#include <random>

int main() {
  random_device rd;  // 用于获取随机种子
  mt19937 gen(rd()); // 使用 Mersenne Twister 19937 作为随机数引擎
  uniform_int_distribution<> dis(0, 100); // 生成 [0, 100] 之间的随机整数
  const int n = 100000;
  int a[n], b[n], c[n], t[n];
  for (int i = 0; i < n; ++i) {
    c[i] = a[i] = b[i] = dis(gen);
    // printf("%d ", a[i]);
  }
  printf("\nstart\n");
  double start = clock();
  quick_sort(a, 0, n - 1);
  double end = clock();
  printf("quick sort: %fms\n", (end - start) * 100. / CLOCKS_PER_SEC);

  start = clock();
  shell_sort(b, n);
  end = clock();
  printf("shell sort: %fms\n", (end - start) * 100. / CLOCKS_PER_SEC);

  start = clock();
  heap_sort(c, n);
  end = clock();
  printf("heap sort: %fms\n", (end - start) * 100. / CLOCKS_PER_SEC);

  // heap_sort(a, n);
  // quick_sort(b, 0, n - 1);
  // merge_sort(c, 0, n - 1, t);
  // for (int i = 0; i < n; ++i)  printf("%d ", a[i]);  printf("\n");
  // for (int i = 0; i < n; ++i)  printf("%d ", b[i]);  printf("\n");
  // for (int i = 0; i < n; ++i)  printf("%d ", c[i]);  printf("\n");
  for (int i = 0; i < n; ++i)  if (a[i] != b[i] || a[i] != c[i])  printf("%d\n", i);
  cout << "success\n";
  return 0;
}