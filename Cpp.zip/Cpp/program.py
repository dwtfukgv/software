#!/usr/bin/env python
# -*- coding: utf-8  -*-
import json
import time
import openpyxl
from datetime import date
import datetime
import sys
import random

fill = '*' * 10
error_fill = '#' * 15

def print_fill(msg):
	print(fill, msg, fill)

def print_error(msg):
	print(error_fill, msg, error_fill)

init_date = date.fromisoformat('1899-12-30')

remove_mark = (' ', ':', '.', '：', '。', '(', ')', '（', '）', ' ', '%', '-', '+', '*', '/', '\\', '!', '!', '@', '#','$', '^', '&', '|', '=', '_', '~', '<', '>', '?', ';', '；', "'", '"', '[', ']', '{', '}')
threshold = .69

def date_to_days(date_):
	return (date.fromisoformat(date_) - init_date).days

def days_to_date(days):
	return init_date + datetime.timedelta(days=days)

def remove_char(s):
	res = ''
	for c in s:
		if c not in remove_mark:
			res += c
	return res.lower()


def is_match(t1, t2):
	if t1 is None or t2 is None:
		return False
	s1, s2 = remove_char(t1), remove_char(t2)
	if s1 == s2:
		return 1.

	dp = [[0 for j in range(len(s2)+5)] for i in range(len(s1)+5)]
	for i in range(1, len(s1) + 1):
		for j in range(1, len(s2) + 1):
			dp[i][j] = (dp[i-1][j-1] + 1 if s1[i-1] == s2[j-1] else max(dp[i-1][j], dp[i][j-1]))
	# print(fill, s1, s2, dp[len(s1)][len(s2)], fill)
	res = dp[len(s1)][len(s2)] * 1.0 / max(len(s1), len(s2))
	if res > threshold:
		print(fill, s1, s2, dp[len(s1)][len(s2)], fill)
	return res



def insert_to_excel(wb, date_=1, tag_=1, value=1):
	data = (date_, tag_, value)
	wbs = wb.active
	row0, col0 = None, None
	for i in wbs.iter_rows():
		row0 = i
		break
	for i in wbs.iter_cols():
		col0 = i
		break
	# print(len(row0))
	# print(len(col0))
	delta = date_to_days(date_)
	row, col, score = 0, 0, threshold
	for i in range(1, len(col0) + 1):
		if wbs.cell(i, 1).value == delta:
			row = i
			break

	if not row:
		print(error_fill, data, "error: not found the row date", date_, error_fill)
		return None
	cols = []
	for i in range(1, len(row0) + 1):
		tmp_score = is_match(wbs.cell(1, i).value, tag_)
		if tmp_score > score:
			cols = [i]
			score = tmp_score
		elif tmp_score == score:
			cols.append(i)

	if not cols:
		print(error_fill, data, "warn: not found the col tag", tag_, error_fill) 
		return None
	if len(cols) > 1:
		print(error_fill, data, "error: found more than one col tags", tag_, [wbs.cell(1, i).value for i in cols])
		return None
	col = cols[0]
	print(fill, data, "found row:", (row, str(days_to_date(wbs.cell(row, 1).value))), "col:", (col, wbs.cell(1, col).value), fill)
	# print(fill, date_, tag_, row, col, "-----")
	wbs.cell(row, col, value)
	# wb.save(file_name)
	return tag_
	# print(rows[3][0].value == (date.fromisoformat('2021-04-02') - init_date).days)
	# _date = date.fromisoformat(row)
	# wb.save(file)



def resolve_email(file_name, json_file, out_f=None):
	wb = openpyxl.load_workbook(file_name)
	message, out = {}, {}
	with open(json_file, 'r') as f:
		message = json.load(f);
	for k, v in message.items():
		cur_date = k
		print(fill, cur_date, fill)
		content = v.replace('\r\n\r\n', '\n')
		print(content)
		for line in content.split("\n"):
			print_fill(line)
			line = remove_char(line)
			print_fill(line)
			i, pre = 0, None
			while i < len(line):
				tag, num = '', 0
				while i < len(line) and not line[i].isdigit():
					tag += line[i]
					i += 1
				while i < len(line) and line[i].isdigit():
					num = num * 10 + ord(line[i]) - ord('0')
					i += 1
				if num > 0:
					print(fill, cur_date, tag, num, fill)
					if '我审了' == tag and pre:
						insert_to_excel(wb, cur_date, pre, num)
						out[pre] = num
						pre = None
						print('\n')
					else:
						pre = insert_to_excel(wb, cur_date, tag, num)
						if pre:
							out[pre] = num
						print("\n")

	if out_f:
		json.dump(out, out_f)
	wb.save(file_name)
	# time.sleep(1)
	# return




if __name__ == '__main__':
	if len(sys.argv) == 3:
		resolve_email(sys.argv[1], sys.argv[2])
	# else if len(sys.argv) == 4:
	# 	with open(sys.argv[3], 'w') as f:
	# 		resolve_email(sys.argv[1], sys.argv[2], f)

