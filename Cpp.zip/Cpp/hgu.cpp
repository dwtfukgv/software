#include <cstdio>
#include <iostream>
#include <cstring>

using namespace std;
int a[10], dp[20000 * 6];
int v;


void zeroOne(int cost, int weight) {
  for (int i = v; i >= cost; --i)  dp[i] = max(dp[i], dp[i-cost] + weight);
}

void complete(int cost, int weight) {
  for (int i = cost; i <= v; ++i)  dp[i] = max(dp[i], dp[i-cost] + weight);
}

void group(int cost, int weight, int num) {
  if (cost * num >= v) {
    complete(cost, weight);
    return;
  }
  int p = 1;
  while (p <= num) {
    zeroOne(cost * p, weight * p);
    num -= p;
    p <<= 1;
  }
  zeroOne(cost * num, weight * num);
}


int main(){
    int cases = 0;
    while(scanf("%d", &a[1])){
        int sum = a[1];
        for(int i = 2; i <= 6; ++i)  scanf("%d", &a[i]), sum += a[i] * i;
        if(!sum)  break;
        printf("Collection #%d:\n", ++cases);
        if(sum & 1){ printf("Can't be divided.\n\n");  continue;   }
        v = sum >> 1;
        memset(dp, 0, sizeof dp);
        for(int i = 1; i <= 6; ++i)
            group(i, i, a[i]);
        if(dp[v] == v)  printf("Can be divided.\n\n");
        else  printf("Can't be divided.\n\n");
    }
    return 0;
}
