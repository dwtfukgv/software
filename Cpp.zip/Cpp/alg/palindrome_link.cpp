#include <iostream>
using namespace std;

struct Link {
	char val;
	Link *nxt;
	Link() : val(0), nxt(nullptr){

	}
};

bool dfs(Link *head){
	static Link *p = head;
	
}

bool is_palindrome(Link *head){
	if(head == nullptr || head->nxt == nullptr){
		return true;
	}

}