#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 
attr = """
    private Long id;
    private Long wm_product_spu_id;
    private Long wm_poi_id;
    private Long wm_product_sku_id;
    private Integer status;
    private Integer is_have_picture;
    private Integer shipping_time_x_status;
    private Integer is_multi_spec;
    private Float price;
    private Integer ctime;
    private String name;
    private String wm_product_sku_ids;
    private String upc_codes;
    private String shipping_time_x;
    private String product_info;
    private String tag_ids;
    private String category_ids;
    private Long brand_id;
    private String brand_name;
    private String dynamic_label_ids;
    private String category_attributes;
    private String category_attribute_values;
    private Float act_price;
    private Float act_discount_strength;
    private Float fresh_act_price;
    private Float fresh_act_discount_strength;
    private Float discount_threshold;
    private Long act_type;
    private Integer act_weight;
    private Integer fresh_act_weight;
    protected Long act_scope;
    private String act_types;
    private String act_uuids;
    private Integer month_purchase_cnt;
    private String statistic_label_ids;
    private Integer doc_status;
    private Long utime;
    private Long sync_time;
    private String coupon_uuids;
    private String coupon_extra;
    private Float sg_fresh_price;
    private Float sg_fresh_discount_strength;
    private Integer sg_fresh_act_weight;
    private Float medicine_fresh_price;
    private Float medicine_fresh_discount_strength;
    private Integer medicine_fresh_act_weight;
    private Integer act_order_limit;
    private Integer fresh_act_order_limit;
    private Integer sg_fresh_act_order_limit;
    private Integer medicine_fresh_act_order_limit;
    private String act_extra_info;
    private Long sg_spu_id;
    private Long poi_first_tag_id;
"""


def get_str(a, b):
    a = a.capitalize()
    if a == 'String':
        return 'rs.getString("' + b + '")'
    else:
        return 'rs.getString("' + b + '") == null ? null : ' + a + '.valueOf(rs.getString("' + b + '"))'



if __name__ == '__main__':
    for i in attr.split("\n"):
        if i.strip() == "":
            continue
        s = i.strip()[:-1].split(" ")
        # print(s)
        res = "tspProductSearchData.set" + s[-1].capitalize() + '(' + get_str(s[-2], s[-1]) + ');'
        print(res)


