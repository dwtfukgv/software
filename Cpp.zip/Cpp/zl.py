#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# a=1
# print(a)

###

# a=input()
# print("I love")
# print(a)

####

# b=input()
# print("I love",b)

 # a=input()
 # b=input()
 # print(a*b)

# a=input()
# b=input()
# # print(a*b)
# c=int(a)
# d=int(b)
# print(c*d)

a=input()
b=input()
c=float(a)
d=float(b)
print(c*d)
e=int(c*d)
print(1000*(c*d-e))
f=int(1000*(c*d-e))
print(f)
