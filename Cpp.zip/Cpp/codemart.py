#!/usr/bin/env python
# -*- coding: utf-8 -*- 
#########################################################################
# File Name: codemart.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-06 16:38
#########################################################################

import urllib2
import json
import os
import pandas as pd
from lxml import etree
import shutil

types=['WEB', 'APP', 'WECHAT', 'HTML5', 'WEAPP', 'OTHER']
roles = dict({"6": "Android", "4": "IOS", "5": "Front", "9": "Back", "3": "All", "1": "Application", "11": "Team"})

url = 'https://codemart.com/api/project'
detail_url = 'https://codemart.com/project/'


def get_response_data(url):
    request = urllib2.Request(url)
    request.add_header('Accept', 'application/json')
    response = urllib2.urlopen(request)
    return response.read()

def get_xpath_data(html, xpath):
    data_list = html.xpath(xpath)
    res = u''
    for data in data_list:
        res += data + '\n'
    return res


def scrapt_content():
    path = './demand'
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)
    for k,v in roles.items():
        headers = [u'描述', u'要求', u'工期', u'价格', u'议价', u'附件', u'链接', u'金额']
        df = pd.DataFrame()
        df.to_excel(path+'/'+v+'.xlsx')
        for type_ in types:
            data_dict = dict()
            for header in headers:
                data_dict[header] = []
            pager = json.loads(get_response_data(url+"?type="+type_+"&roleTypeId="+k))['pager']
            total_page = pager.get('totalPage', 0)
            print "=======", v, type_, "total page:", total_page, "start ======="
            for page in range(total_page):
                rewards = json.loads(get_response_data(url+"?page="+str(page+1)+"&type="+type_+"&roleTypeId="+k))['rewards']
                for reward in rewards:
                    print "======= doing reward:", reward['id'], "========"
                    data = dict()
                    data_dict[u'描述'].append(reward['description'])
                    data_dict[u'价格'].append(reward['price'])
                    data_dict[u'工期'].append(reward.get('duration', u'待定'))
                    data_dict[u'议价'].append(u'是' if reward.get('bargain', False) else u'否')
                    content_url = detail_url + str(reward['id'])
                    data_dict[u'链接'].append(content_url)
                    html =  etree.HTML(get_response_data(content_url))
                    demand = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[3]/div[2]/div/descendant::*/text()')
                    if not demand:
                        demand = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[4]/div[2]/div/descendant::*/text()')
                    data_dict[u'要求'].append(demand)
                    attachment = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[4]/descendant::*/input/@value')
                    if not attachment:
                        attachment = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[5]/descendant::*/input/@value')
                    data_dict[u'附件'].append(attachment)
                    money = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[3]/div[1]/div/p/span[2]/text()')
                    if not money:
                        money = get_xpath_data(html, '//*[@id="mart-reward-detail"]/div[1]/section[3]/div[4]/div[1]/div/p/span[2]/text()')
                    data_dict[u'金额'].append(money)
            with pd.ExcelWriter(path+"/"+v+".xlsx", mode='a') as writer:
                df = pd.DataFrame(data_dict)
                df.to_excel(writer, encoding='utf_8_sig', sheet_name=type_)
            print "=======", v, type_, "total page: ", total_page, "end ========"
#            exit(0)

def test_html():
    data = get_response_data('https://codemart.com/project/21505')
    html = etree.HTML(data)
    data = html.xpath('//*[@id="mart-reward-detail"]/div[1]/section[3]/div[4]/div[2]/div/descendant::*/text()')
    print data

if '__main__' == __name__:
    scrapt_content()
#    test_html()


