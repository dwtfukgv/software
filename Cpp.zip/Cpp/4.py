#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json

def f():
    all_lines = []
    with open ('b.txt', 'r') as f:
        all_lines = f.readlines()
    
    with open ('a.txt', 'r') as f:
        while True:
            input = f.readline()
            if not input:
                break
            attrs = input.split(":")
            for line in all_lines:
                all = True
                for attr in attrs:
                    if attr not in line:
                        all = False
                if all:
                    print(input)
                    break
            