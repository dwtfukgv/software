#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <cstring>
#include <set>
#include <queue>
#include <algorithm>
#include <vector>
#include <map>
#include <cctype>
#include <ctime>
#include <stack>
#include <sstream>
#include <list>
#include <assert.h>
#include <bitset>
#include <numeric>
#include <unordered_map>
#include <fstream>
#include <random>
#define debug() puts("++++")
#define print(x) cout<<"====== "<<(x)<<" ====="<<endl;
// #define gcd(a, b) __gcd(a, b)
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define fi first
#define se second
#define pb push_back
#define sqr(x) ((x)*(x))
#define ms(a,b) memset(a, b, sizeof a)
#define _mod(x) ((x) % mod + mod) % mod
#define sz size()
#define be begin()
#define ed end()
#define pu push_up
#define pd push_down
#define cl clear()
#define lowbit(x) -x&x
// #define all 1,n,1
#define FOR(i,n,x)  for(int i = (x); i < (n); ++i)
#define freopenr freopen("in.in", "r", stdin)
#define freopenw freopen("out.out", "w", stdout)
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<double, double> P;
const int INF = 0x3f3f3f3f;
const LL LNF = 1e17;
const double inf = 1e20;
const double PI = acos(-1.0);
const double eps = 1e-12;
const int maxn = 50 + 7;
const int maxm = 3000 + 7;
const LL mod = 1e9 + 7;
const int dr[] = {-1, 1, 0, 0, 1, 1, -1, -1};
const int dc[] = {0, 0, 1, -1, 1, -1, 1, -1};
const P null = P(-1, -1);
int n, m;

inline bool is_in(int r, int c) {
  return r >= 0 && r < n && c >= 0 && c < m;
}
inline int read_int(){
  int x;  scanf("%d", &x);  return x;
}


const int dimx = 10, dimy = 10, dimz = 10;
string file_name = "./tornado0.dat";
string out_file_name = "./output_result.dat";
string entropy_file_name = "./entropy_data.txt";

float raw_data_d[dimx * dimy * dimz * 3];
double data_d[dimz][dimx][dimy][3];
double union_data_d[dimz][dimx][dimy], entropy[dimz][dimx][dimy];
double r = 0;
double vmin = LNF, vmax = -LNF;
double a = 4, b = 3;
int total_fragement = 10;
int select_threshold = 10;
double entropy_threshold = 1;
double fragement_threshold = 2 * PI / total_fragement;


inline double get_dist(double x1, double y1, double x2, double y2){
  return sqr(x1 - x2) + sqr(y1 - y2);
}


void read_file(string file_name){
  FILE* fp;
  fp = fopen(file_name.c_str(), "rb");
  fread(raw_data_d, sizeof(float), dimx * dimy * dimz * 3, fp);

  int idx = 0;
  FOR(i, dimx, 0)  FOR(j, dimy, 0)  FOR(k, dimz, 0){
    for(int l = 0; l < 3; ++l)  data_d[k][i][j][l] = raw_data_d[idx++];
    union_data_d[k][i][j] = sqrt(get_dist(0, 0, data_d[k][i][j][0], data_d[k][i][j][1]));
    vmin = min(vmin, union_data_d[k][i][j]);
    vmax = max(vmax, union_data_d[k][i][j]);
  }
  fclose(fp);
}


inline double get_R(double v){
  return (v - vmin) * a / (vmax - vmin) + b;
}

inline double cal_entropy(vector<double> p){
  double res = 0;
  for(auto &d : p)  res += d * log2(d);
  return -res;
}

inline vector<P> gen_all_seed(double x, double y, double R, int which){
  vector<P> res;
  FOR(i, dimx, 0)  FOR(j, dimy, 0){
    double *p = data_d[which][i][j];
    double dist = get_dist(x, y, p[0], p[1]);
    if(dist >= sqr(r) && dist <= sqr(R) && (x != p[0] || y != p[1]))  res.pb(P(p[0], p[1]));
  }
  return res;
}

inline vector<P> get_rand_seed(double x, double y, int num, double R, int which){
  vector<P> res = move(gen_all_seed(x, y, R, which));
  if(res.sz <= num)  return res;
  srand(time(0));
  random_shuffle(res.be, res.ed);
  res.resize(num);
  return res;
}

inline double cal_angle(P &p1, P &p2){
  double len1 = sqrt(get_dist(0, 0, p1.fi, p1.se));
  double len2 = sqrt(get_dist(0, 0, p2.fi, p2.se));
  return acos((p1.fi * p2.fi + p1.se * p2.se) / (len1 * len2));
}

inline vector<double> gen_p(unordered_map<int, int> &mp, int n){
  vector<double> res;
  for(auto &p : mp)  res.pb(p.se * 1. / n);
  return res;
}


double cal_rate(double x, double y, int num, double R, int which){
  vector<P> data_d = move(get_rand_seed(x, y, num, R, which));
  unordered_map<int, int> mp;
  P cur = P(x, y);
  for(auto &p : data_d){
    int seed = (int)(cal_angle(cur, p) / fragement_threshold);
    if(mp.count(seed))  ++mp[seed];
    else mp[seed] = 1;
  }
  return cal_entropy(gen_p(mp, data_d.sz));
}


int main(){
  read_file(file_name);

  FOR(i, dimz, 0)  FOR(j, dimx, 0)  FOR(k, dimy, 0){
    double *p = data_d[i][j][k];
    double entropy_val = cal_rate(p[0], p[1], select_threshold, get_R(union_data_d[i][j][k]), i);
    entropy[i][j][k] = entropy_val;

    printf("%d %d %d %f\n", i, j, k, entropy_val);
    if(entropy_val >= entropy_threshold){
      int idx = i + k * dimz + j * dimz * dimy;
      for(int l = 0; l < 3; ++l)  raw_data_d[idx+l] = 0;
    }
  }

  ofstream ofile;
  ofile.open(entropy_file_name);
  printf("write entropy to file: %s\n", entropy_file_name.c_str());
  FOR(i, dimz, 0)  FOR(j, dimx, 0)  FOR(k, dimy, 0){
    ofile << j << "," << k << "," << i << ": " << entropy[i][j][k] << endl;
  }
  ofile.close();
  printf("write filter data_d to file: %s\n", out_file_name.c_str());
  FILE *fp = fopen(out_file_name.c_str(), "w");
  fwrite(raw_data_d, sizeof(float), dimx * dimy * dimz * 3, fp);
  fclose(fp);
  return 0;
}
