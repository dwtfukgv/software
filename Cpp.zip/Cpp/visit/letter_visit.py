#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
# File Name: letter_visit.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-05-18 10:50

import sys, os
import requests
import json
from urllib import parse
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ocr.v20181119 import ocr_client, models
import base64
import time
import random

visit_url = 'http://wsxf.xfj.shandong.gov.cn/web/complaintapi/saveTsjyxx'
verify_rul = 'http://wsxf.xfj.shandong.gov.cn/web/userapi/verifyImage'
login_url = 'http://wsxf.xfj.shandong.gov.cn/web/userapi/login'
logout_url = 'http://wsxf.xfj.shandong.gov.cn/web/userapi/loginout'

headers = {
	"Accept": "*/*",
	"Accept-Encoding": "gzip, deflate",
	"Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
	"Connection": "keep-alive",
	"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
	"Host": "wsxf.xfj.shandong.gov.cn",
	"Origin": "http://wsxf.xfj.shandong.gov.cn",
	"Referer": "http://wsxf.xfj.shandong.gov.cn/web/complaint",
	"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
	"X-Requested-With": "XMLHttpRequest",
	"Cookie": 'route=dbbc5fa3124129e498567dbc7bdcc20b; _gscu_1781981928=64805581yek41811; _gscbrs_1781981928=1; WSXFSESSION=94911B5DF29BF20C1FDF78677A24F8D3; _gscs_1781981928=t64935228jx8h2m19|pv:32'
}


current_path = os.path.dirname(__file__)

def get_real_path(path):
	return os.path.join(current_path, path)

def get_verify_code(img):
	try:

	    cred = credential.Credential("AKIDqVt0rSlnX1EAoBG4brra2D7k6D8nBI8h", "JL6ZOxFG0TgcHekZ7OO6YicFckbCXcPv")
	    httpProfile = HttpProfile()
	    httpProfile.endpoint = "ocr.tencentcloudapi.com"

	    clientProfile = ClientProfile()
	    clientProfile.httpProfile = httpProfile
	    client = ocr_client.OcrClient(cred, "ap-beijing", clientProfile)

	    req = models.EnglishOCRRequest()
	    params = {
	        "ImageBase64": img
	    }
	    req.from_json_string(json.dumps(params))
	    resp = client.EnglishOCR(req)
	    return json.loads(resp.to_json_string())['TextDetections'][0]['DetectedText']

	except TencentCloudSDKException as err:
	    print(err)

name = 'dwtfukgv'



def set_name(x):
	global name
	name = x

def log(content):
	content = json.loads(content)
	print("=" * 5, name, content['msg'], "=" * 5)
	if content['code'] != '200':
		raise Exception("fail")

def submit_req(data):
	response = requests.post(visit_url, headers=headers, data=parse.urlencode(data))
	content = response.content
	log(content.decode(encoding='utf-8'))


def login(username, password):
	response = requests.get(verify_rul, headers=headers)
	with open(get_real_path	('verify.png'), 'wb') as f:
		f.write(response.content)

	code = get_verify_code(base64.b64encode(response.content).decode())
	print("code:", code)
	if len(code) != 4:
		raise Exception("验证码未验证成功")

	time.sleep(random.randint(1, 5))
	data = {}
	data['zjhm'] = username
	data['mm'] = password
	data['codeImg'] = code
	
	response = requests.post(login_url, headers=headers, data=parse.urlencode(data))
	content = response.content.decode('utf-8')
	log(content)


def logout():
	data = {}
	data['redirect_uri'] = 'http://wsxf.xfj.shandong.gov.cn/'
	response = requests.post(logout_url, headers=headers, data=parse.urlencode(data))
	content = response.content
	log(content.decode(encoding='utf-8'))


def get_content_info(uid):
	with open(get_real_path('letter.json'), 'r') as f:
		data = json.load(f)
		lmr = data['lmrjson']
		for i in range(len(lmr)):
			if lmr[i]['sfzh'] == uid:
				lmr.pop(i)
				break
		return data


if __name__ == '__main__':
	logout()
	with open(get_real_path('user.json'), 'r') as f:
		data = json.load(f)
		for user in data:
			set_name(user['name'])
			cnt = 3
			while cnt > 0:
				try:
					print(name, "start")
					login(user['phone'], user['password'])
					time.sleep(random.randint(10, 60))
					submit_req(get_content_info(user['id']))
					break
				except Exception as e:
					print(e)
					cnt -= 1
				finally:
					time.sleep(random.randint(3, 20))
					logout()
					print(name, "end")
					time.sleep(random.randint(10, 100))













