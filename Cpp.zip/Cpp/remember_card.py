#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# File Name: 1.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
from __future__ import print_function
import copy

cards = "3456789SJQKA2VW"
a, b = None, None

def idx(ch):
	return cards.find(ch.upper()) + 1


def sub(d):
	if 0 in d.keys():
		return
	b = copy.deepcopy(a)
	for k, v in d.items():
		a[k] -= v
	print('=' * 10, 'change', '='*10)

def sub_(l, num):
	sub(dict(zip(l, [num for i in range(len(l))])))

def pair(s, num=1):
	low, upp = idx(s[0]), idx(s[2])
	for i in range(low, upp+1):
		a[i] -= num


def print_(a):
	for i in cards:
		print(i, end=' ')
	print()
	for i in a[1:]:
		print(i, end=' ')
	print()


def play(n):
	global a, b
	a = [n for i in range(len(cards) + 1)]
	a[-1] = a[-2] = n>>2
	b = copy.deepcopy(a)
	while True:
		try:
			s = raw_input()
			if s == 'r':
				print_(a)
				return
			if s == 'c':
				a = copy.deepcopy(b)
				print_(a)
				continue
			
			if len(s) == 1:
				sub_([idx(s[0])], 1)
			elif len(s) == 2:
				sub_([idx(s[0])], int(s[1]))
			elif len(s) == 3:
				if s[1] == '-':
					sub_([i for i in range(idx(s[0]), idx(s[2])+1)], 1)
				elif s[1] == 'd':
					sub({idx(s[0]): 3, idx(s[2]): 1, })
				elif s[1] == 'D':
					sub({idx(s[0]): 3, idx(s[2]): 2, })
			elif len(s) == 4:
				if s[1] == '-':
					sub_([i for i in range(idx(s[0]), idx(s[2])+1)], int(s[3]))
				elif s[1] == 'd':
					sub({idx(s[0]): 4, idx(s[2]): 1, idx(s[3]): 1})
				elif s[1] == 'D':
					sub({idx(s[0]): 4, idx(s[2]): 2, idx(s[3]): 2})
		except Exception as e:
			pass
		print_(a)



if '__main__' == __name__:
	while True:
		n = input()
		play(n<<2)


