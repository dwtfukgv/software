#!/usr/bin/env python
# -*- coding: utf-8  -*-
# 


name_pre = '品牌ID：'

def is_digit(s):
	try:
		i = int(s)
		return True
	except Exception as e:
		return False

if __name__ == '__main__':
	cnt = 0
	# f = open ('./boss_id.txt', 'w')
	# g = open('./brand_id.txt', 'w')
	# cnt1, cnt2 = 0, 0
	# for line in open('./1.txt', 'r'):
	# 	# if line.startswith(name_pre) and line.strip() != name_pre:
	# 	# 	f.write(line)
	# 	# 	cnt += 1
	# 	# if line.strip() == "【企查查】":
	# 	# 	f.write(pre)
	# 	# 	cnt += 1
	# 	# pre = line
	# 	s = line.strip().split(" ")
	# 	if len(s) == 1 and is_digit(s[0]):
	# 		f.write(s[0] + "\n")
	# 		cnt1 += 1
	# 	elif len(s) >= 3 and is_digit(s[0]) and is_digit(s[1]) and not is_digit(s[2]):
	# 		g.write(s[1] + "\n")
	# 		cnt2 += 1
	# f.close()
	# g.close()
	# print(cnt1)
	# print(cnt2)

	# 
	# 
	f = f"""12
	"""