/*
#include <cstdio>
#include <algorithm>
using namespace std;
const int maxn = 1000 + 7;
int a[maxn], dp[maxn];


int main(){
  int n;  scanf("%d", &n);
  int mmax_i = 0;
  for(int i = 0; i < n; ++i){
    scanf("%d", a + i);
    if(a[i] > a[mmax_i])  mmax_i = i;
  }
  int m, k;  scanf("%d %d", &m, &k);
  if(m < k){
    printf("%d\n", m);
    return 0;
  }
  m -= k;
  for(int i = 0; i < n; ++i) if(i != mmax_i){
    for(int j = m; j >= a[i]; --j)
      dp[j] = max(dp[j], dp[j - a[i]] + a[i]);
  }

  printf("%d\n", m - dp[m] - a[mmax_i] + k);
  return 0;
}
 
 */


/*
#include <cstdio>
#include <algorithm>
#include <unordered_map>
using namespace std;
const int INF = 0x3f3f3f3f;
const int maxn = 100007;

int dp[maxn];

int main(){
  int n;  scanf("%d", &n);
  unordered_map<int, int> mp;
  int x, y;
  for(int i = 1; i <= n; ++i){
    scanf("%d", &x);
    mp[x] = i;
  }
  scanf("%d", &n);
  memset(dp, INF, sizeof dp);
  for(int i = 1; i <= n; ++i){
    scanf("%d", &x);
    y = mp[x];
    if(y == 0)  continue;
    *lower_bound(dp, dp + i, y) = y;
  }
  printf("%d\n", lower_bound(dp, dp + n, INF) - dp);
  return 0;
}

*/


/*
#include <cstdio>
using namespace std;
const int maxn = 1007;
const int mod = 1e9 + 7;
long long dp[maxn][maxn];
 
int main(){
  int n, k;  scanf("%d %d", &n, &k);
  dp[0][0] = 1;
  for(int i = 1; i <= n; ++i)
    for(int j = 0; j < i; ++j)
      dp[i][j] = (dp[i-1][j] * (j+1) + dp[i-1][j-1] * (i-j)) % mod;
  printf("%lld\n", dp[n][k]);
  return 0;
}

*/


/*
#include <cstdio>
#include <cmath>
using namespace std;
const int maxn = 100000;

int main(){
  int n, m;  scanf("%d %d", &n, &m);
  double ans = 0;
  for(int i = 1; i < n; ++i){
    double pos = i * 1. / n * (m + n);
    ans += fabs(pos - floor(pos + 0.5)) / (m + n);
  }

  printf("%.2f\n", ans * maxn);
  return 0;
}
*/


/*
#include <cstdio>
#include <algorithm>
using namespace std;
const int maxn = 100000 + 7;

pair<int, int> a[maxn];

int main(){
  int n, m;  scanf("%d %d", &m, &n);
  for(int i = 0; i < n; ++i)  scanf("%d %d", &a[i].first, &a[i].second);
  sort(a, a + n, [&](const pair<int, int> &lhs, const pair<int, int> &rhs){
    return lhs.first + rhs.second < lhs.second + rhs.first;
  });
  bool ok = true;
  for(int i = 0; i < n && ok; ++i){
    if(m >= a[i].second)  m -= a[i].first;
    else ok = false;
  }
  printf("%d\n", ok);
  return 0;
}
*/

/*
#include <cstdio>
using namespace std;

int main(){
  int n;  scanf("%d", &n);
  int bit = 1;
  long long magic = 9;
  while(n > bit * magic){
    n -= bit * magic;
    magic *= 10;
    ++bit;
  }

  --n;
  int num = n / bit + magic / 9;
  int cnt = bit - n % bit - 1;
  while(cnt--)  num /= 10;
  printf("%d\n", num % 10);
  return 0;
}

*/

// [2,1,5,6,2,3] 10   6 2 1 5 6 2 3 
// [2,4] 4 // 4

/*
#include <cstdio>
#include <stack>
using namespace std;

int main(){
  int n;  scanf("%d", &n);
  stack<pair<int, int>> st;
  int ans = 0, h, w;
  for(int i = 0; i <= n; ++i){
    if(i < n)  scanf("%d %d", &w, &h);
    else h = w = 0;
    if(st.empty() || st.top().first < h)  st.push(pair<int, int>(h, w));
    else {
      int cnt = 0;
      while(!st.empty() && st.top().first >= h){ 
        cnt += st.top().second;
        ans = max(ans, st.top().first * cnt);
        st.pop();
      }
      cnt += w;
      ans = max(ans, h * cnt);
      st.push(pair<int, int>(h, cnt));
    }
  }
  printf("%d\n", ans);
  return 0;
}

*/

/*
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn = 100007;

int a[26];
char s[maxn];

int main() {
  scanf("%s", s);
  for(char *c = s; *c; ++c)  ++a[*c - 'a'];
  int cnt = 0;
  for(int i = 0; i < 26; ++i)  cnt += a[i] != 0;

  scanf("%s", s);
  int other = 0;
  char *l = s, *r = s;
  while(*r){
    while(*r && cnt){
      int x = *r - 'a';
      --a[x];
      if(!a[x])  --cnt;
      else if(a[x] == -1)  ++other;
      ++r;
    }
    if(cnt)  break;
    if(!cnt && !other)  break;
    while(*l && other){
      int x = *l - 'a';
      ++a[x];
      if(!a[x])  --other;
      else if(a[x] == 1)  ++cnt;
      ++l;
    }
  }
  printf("%d\n", !cnt && !other);
  return 0;
}
*/
#include <iostream>
#include <vector>

using namespace std;

int solve(vector<int> &h) {
  const int n = h.size();
  if (n <= 1)  return 0;
  int lh = h[0], rh = h.back(), ans = 0; 
  int l = 1, r = n - 2;

  while (l <= r) {
    if (lh <= rh)  ans += max(0, min(lh, rh) - h[l]), lh = max(lh, h[l++]);
    else ans += max(0, min(lh, rh) - h[r]), rh = max(rh, h[r--]);
  }
  return ans;
}

#include <stack>
typedef pair<int, int> P;


int solve2(vector<int> &h) {
  stack<int> st;
  
  int ans = 0;
  for (int i = 0; i < h.size(); ++i) {
    if (st.empty() || h[st.top()] > h[i])  st.push(i);
    else if (h[st.top()] == h[i])  st.pop(), st.push(i);
    else {
      int hh = 0;
      while (!st.empty() && h[st.top()] <= h[i]) {
        ans += max(0, (i-st.top()-1)*(h[st.top()]-hh));
        hh = h[st.top()];
        st.pop();
      }
      if (!st.empty()) ans += max(0, (i-st.top()-1)*(h[i]-hh));
      st.push(i);
    }
    cout << i << " " << ans << endl;
  }
  return ans;

}


int main() {
  int n;  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; ++i) cin >> a[i];
  cout << solve(a) << endl;
  cout << solve2(a) << endl;
  return 0;
}



