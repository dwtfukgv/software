#!/usr/bin/env bash
curl -X POST -F "file=@$1" 'http://39.106.62.223:8004/img/s_uploadImg_p'
