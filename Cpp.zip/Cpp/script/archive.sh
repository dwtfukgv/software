#!/bin/sh

echo "$1"
var=$1
t_path=${var%/*}/
echo $t_path
# unzip -P 123 $var -d $t_path
# echo "============="
# echo $?

num_set="0123456789"
lower_set="abcdefghijklmnopqrstuvwxyz"
upper_set="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
all_set="${num_set}${lower_set}${upper_set}."
echo $all_set

function solve(){
	echo $1
	unzip -P $1 $var -d $t_path
}

function dfs(){
	str=$2
	echo "$1, $2"
	if [ ${#str} -eq $1 ]
	then 
		solve $str
		return 0
		echo "-=----"
	fi
	set=$3
	for i in `seq ${#set}`
	do
		str=$2
		dfs $1 "${str}${set:i-1:1}" $3
	done
}

# for i in `seq ${#num_set}`
# do
# 	echo "${num_set:i-1:1},"
# done

for i in {1..10}
do
	dfs $i "" $all_set
done
# str="123"
# "${str}${str}"
# echo $str

# for i in {1000..10000}
# do
# 	echo $i
# 	unzip -P $i $var -d $t_path
# 	sleep 1
# done