#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
# File Name: host_filter.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-21 18:55

import json
import sys
import requests
import os
import sqlite3

import keyring
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
import browsercookie

def get_cookie():
    cookies = browsercookie.chrome()
    mws_cookies = ''
    for cookie in cookies:
        if '.mws.sankuai.com' == cookie.domain:
            # print(cookie)
            mws_cookies += cookie.name + '=' + cookie.value + ';'
    return mws_cookies
    # with open('/Users/dwtfukgv/script/Cpp/script/cookie/avatar.ck', 'r') as f:
    #     return f.readline()
        

def gen_cookie():
    my_pass = keyring.get_password('Chrome Safe Storage', 'Chrome')
    my_pass = my_pass.encode('utf8')
    iterations = 1003
    cookie_file = os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies')
    salt = b'saltysalt'
    length = 16
    iv = b' ' * length

    with sqlite3.connect(cookie_file) as conn:
        result = conn.execute("select encrypted_value from cookies where host_key = '.mws.sankuai.com' and name = 'yun_portal_ssoid'").fetchall()
    token = result[0][0][3:]
    key = PBKDF2(my_pass, salt, length, iterations)
    cipher = AES.new(key, AES.MODE_CBC, IV=iv)
    dec_token = cipher.decrypt(token)
    ck = dec_token.decode()
    i = len(ck) - 1
    while i and ord(ck[i]) <= 32:
        i -= 1
        continue
    ck = ck[:i+1]
    with open('/Users/dwtfukgv/script/Cpp/script/cookie/avatar.ck', 'w') as f:
        f.write('yun_portal_ssoid=' + ck)


def gen_items(arg):
    result = []
    msg = 'Please modify input'
    if len(arg) > 8:
        for i in range(0, 5):
            try:
                headers = {'Cookie': get_cookie(), 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Content-Type': 'application/json;charset=utf-8'}
                headers['Referer'] = 'https://avatar.mws.sankuai.com/'
                response = requests.get(f'https://avatar.mws.sankuai.com/api/v2/avatar/appkey/query?query={arg}', headers=headers)
                # print(response)
                data = json.loads(response.content)['data']
                # print(data)
                app_key = data[0]['appkey']
                host_response = requests.get(f'https://avatar.mws.sankuai.com/api/v1/avatar/srv/{app_key}/hosts?q={arg}&page=1&pageSize=1&sortby=ctime&sort=desc', headers=headers)
                host = json.loads(host_response.content)['data']['items'][0]
                host_info = f'{host["env"]} {host["idc"]} {host["cell"] if host["cell"] else "-"} {host["swimlane"] if host["swimlane"] else "-"} {host["cpu_count"]}c{host["mem_size"]}g{host["disk_size"]}g {host["_manage_plat"]} {host["name"]} {host["ip_lan"]} {host["parent"]} {app_key}'
                result.append({
                    "title": app_key,
                    "subtitle": host_info,
                    "autocomplete": app_key,
                    "arg": host_info
                })
                break
            except Exception as e:
                # print(e)
                gen_cookie()
                msg = 'cookie expire'

    if len(result) == 0:
        data = {
            "title": "No app key match",
            "subtitle": msg
        }
        return [data]
    return result

if __name__ == '__main__':
    arg = sys.argv[1]
    # arg = '10.178.157.134'

    data = json.dumps({
        "items": gen_items(arg)
    }, indent=2)
    sys.stdout.write(data)
