#!/usr/bin/env bash
scp $1 dwtfukgv@119.23.43.211:/home/dwtfukgv/scp_file
