#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import zipfile, sys, os


def unzip_file(file_name, s):
	zfile = zipfile.ZipFile(file_name)
	zfile.extractall(path=os.path.join(*file_name.split('/')[:-1]), pwd=s)


def dfs(cur, n, s, t, file_name):
	if cur == n:
		try:
			print n, s
			unzip_file(file_name, s)
			exit(0)
		except Exception as e:
			print e
		return;
	for i in t:
		dfs(cur+1, n, s + i, t, file_name)



num_set = "0123456789"
lower_set = "abcdefghijklmnopqrstuvwxyz"
upper_set = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


if '__main__' == __name__:

	test = lower_set + num_set
	print sys.argv[1]
	exit(0)
	for i in range(3):
		dfs(0, i, "", test, sys.argv[1])
