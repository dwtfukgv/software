#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import os
import sqlite3

import keyring
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2


# https://www.cnblogs.com/lrysjtu/p/4713250.html

#for mac
my_pass = keyring.get_password('Chrome Safe Storage', 'Chrome')
my_pass = my_pass.encode('utf8')
iterations = 1003
cookie_file = os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies')

salt = b'saltysalt'
length = 16
iv = b' ' * length


def expand_str(token):
    token_len = len(token)
    expand_len = (token_len // length + 1) * length - token_len
    return token.encode('ascii') + b'\x0c' * expand_len


def aes_encrypt(token):
    key = PBKDF2(my_pass, salt, length, iterations)
    cipher = AES.new(key, AES.MODE_CBC, IV=iv)
    enc_token = cipher.encrypt(token)
    return b'v10' + enc_token


def aes_decrypt(token):
    token = token[3:]
    key = PBKDF2(my_pass, salt, length, iterations)
    cipher = AES.new(key, AES.MODE_CBC, IV=iv)
    dec_token = cipher.decrypt(token)
    return dec_token


def query_cookies():
    with sqlite3.connect(cookie_file) as conn:
        result = conn.execute("select host_key, name, encrypted_value from cookies").fetchall()
        return result


def write_cookies(enc_token):
    print(enc_token)
    print(aes_decrypt(enc_token))
    with sqlite3.connect(cookie_file) as conn:
        b = sqlite3.Binary(enc_token)
        sql = """update cookies set encrypted_value = ? where name = 'remember_token'"""
        conn.execute(sql, (b, ))

def change_user(token):
    write_cookies(aes_encrypt(expand_str(token)))

if __name__ == '__main__':
    result = query_cookies()
    for x in result:
        print(x[0], x[1], aes_decrypt(x[2]))
