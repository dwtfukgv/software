#!/usr/bin/python
# -*- coding: utf-8 -*-
# File Name: app_filter.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-21 18:55

import time
import sys
import json
import re

def handle_time_format(ts):
    time_local = time.localtime(ts if ts < 999999999999 else ts / 1000)
    dt = time.strftime("%Y-%m-%d %H:%M:%S %A", time_local)
    data = {
        "title": dt,
        "subtitle": ts,
        "arg": dt
    }
    return [data]

def handle_calc_rate(cur, last):
    res = (float(cur) - float(last)) / float(last) * 100.
    data = {
        "title": "({0} - {1}) / {2} * 100".format(cur, last, last),
        "subtitle": res,
        "arg": int(res + 0.5)
    }

    return [data]

def handle_ip_address(text):
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    ips = re.findall(ip_pattern, text)
    res = ips[0] if len(ips) > 0 else "no ip recgnize";
    data = {
        "title": "extract ip address",
        "subtitle": res,
        "arg": res
    }
    return [data]

if __name__ == '__main__':
    op = sys.argv[1]
    items = []
    
    args = sys.argv[2].split(" ")
    # print(args)
    if op == 'tft':
        items = handle_time_format(int(sys.argv[2]))
    elif op == 'rate' and len(args) >= 2:
        items = handle_calc_rate(args[0], args[1])
    elif op == 'ip':
        items = handle_ip_address(sys.argv[2])

    data = json.dumps({
        "items": items
    }, indent=2)
    sys.stdout.write(data)
