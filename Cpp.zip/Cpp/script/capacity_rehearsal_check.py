# -*- coding: utf-8 -*-
'''
容量演练期间服务维度统计qps、tp999、qps限流
'''
import importlib.util,subprocess
if importlib.util.find_spec('browsercookie') is None:
	subprocess.check_call(['pip', 'install', 'browsercookie'])

import browsercookie

cookies = browsercookie.chrome()
site_cookies = []
mws_cookies=''
for cookie in cookies:
	if '.mws.sankuai.com' == cookie.domain or 'rhino.sankuai.com' == cookie.domain:
		site_cookies.append(cookie)
		mws_cookies+=cookie.name+'='+cookie.value+';'


import sys,json,datetime,time

def get_hosts_active(domain, cell, swimlane=None):
	curl_octo_cmd="curl -s 'https://octo.mws.sankuai.com/api/octo/v2/provider/"+domain+"/providers?env=prod&appkey="+domain+"&type=1&status=2&set={}&swimlane={}&currentPage=1&limit=50000&sort=desc&sortby=lastUpdateTime' \
  -H 'authority: octo.mws.sankuai.com' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'accept-language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7' \
  -H 'cookie: "+mws_cookies+"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --compressed"

	curl_octo_cmd_resp=subprocess.check_output(curl_octo_cmd.format(cell,swimlane if swimlane else ''), shell=True)
	curl_octo_cmd_resp_json=json.loads(curl_octo_cmd_resp)
	items=curl_octo_cmd_resp_json['data']['items']
	ip_arr=[]
	for item in items:
		if not swimlane and item['swimlane']:
			continue
		if item['ip'] not in ip_arr:
			ip_arr.append(item['ip'])

	return ip_arr

def get_hosts(domain, cell, swimlane=None):
	
	if not cell and not swimlane:
		return []

	curl_avatar_cmd="curl -s 'https://avatar.mws.sankuai.com/api/v2/avatar/host?q=&set={}&swimlane={}&_manage_plat=&_idc_name=&_origin_type=&net_type=&grouptags=&appkey="+domain+"&env=prod&page=1&pageSize=10000&sortby=ctime&sort=desc' \
  -H 'authority: avatar.mws.sankuai.com' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'accept-language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7' \
  -H 'access-token: eAGFjy1LQ1EchzkqMhRElow3GLYFOe_n_E1ubmL0DQSLnHPPOQZhC1ewLLiBwQWDYNCijgsKA8WkySBWv4MguhsEP4DFiZjtP57n-eXQ5OtHG0X7nbteSmhOYqBEC5iNJDhiJI65NooHzMFhUQIcK62NNxYqXyhfXPd2NfZ136zKii5zXJZ6oSYExoAJU1VeY1QLLQiPsv7T4xUpDNF_wfonaG588bP70krJ0vHh88MZaaPS2OjyynzD-Xz-Lb3Mbi_eD3r981Z2nWY3ramRaO_-pFj4HR-h3F_YKZoxxjsmgw4xWKsBgog5Zk4y5oMiwW8SCRQrAE4V0V00vett01lHOEhphTAcYqaddHrwxQJxJEjYiIJhUjBqpCsZ7jUBS4ELNfCogIOCNprY8jvlOPZJstbY9vUOGk6SxjdqAXfF**eAEFwYEBwAAEA7CXRhnOoeb_E5YU3OoyoGOElemuoL1ockTtvkxCnNP3sZM6CFp3aEo9PzDPEbc**eE7fuatcs_wXC3iRPRMsxzoYPdEynyTuwaycVU2fBrEYvU4SPu0dvRPOV_5Hn1eL27snlb0lzjjsUcTtZfD53g**MjE0Mzg0MyxqaW5qdW5qaWUs6YeR5ZCb5p2wLGppbmp1bmppZUBtZWl0dWFuLmNvbSwxLDAzMDQwMzEyLDE2OTMzODE5MzYzODk' \
  -H 'cookie: "+mws_cookies+"' \
  -H 'referer: https://avatar.mws.sankuai.com/' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --compressed"

	curl_avatar_cmd_resp=subprocess.check_output(curl_avatar_cmd.format(cell,swimlane if swimlane else ''), shell=True)
	curl_avatar_cmd_resp_json=json.loads(curl_avatar_cmd_resp)

	items=curl_avatar_cmd_resp_json['data']['items']
	ip_arr=[]
	for i in items:
		if not swimlane and i['swimlane']:
			continue
		ip_arr.append(i['ip_lan'])

	return ip_arr


def get_metric_by_ip(domain, ip_arr=None,target_YmdHM=None,last_n_min=1, metric='qps'):
	target_YmdHMS=target_YmdHM+'00' if target_YmdHM else datetime.datetime.now().strftime('%Y%m%d%H%M')+'00'
	target_datetime=datetime.datetime.strptime(target_YmdHMS,'%Y%m%d%H%M%S')

	end_timestamp = int(time.mktime(target_datetime.timetuple()))*1000
	start_time=target_datetime-datetime.timedelta(minutes=(last_n_min if last_n_min>=1 else 1)-1)
	start_timestamp=int(time.mktime(start_time.utctimetuple()))*1000
	
	req_data={
	    "category": 1,
	    "daycmp": False,
	    "domain": domain,
	    "end": end_timestamp,  # 13位
	    "groupby": "",
	    "ip": ip_arr if ip_arr else ["All"],
	    "ipType": "ip",
	    "isSecond": False,
	    "metric": metric,
	    "monthcmp": False,
	    "name": [
	        "All"
	    ],
	    "start": start_timestamp,
	    "type": [
	        "OctoService"
	    ],
	    "weekcmp": False
	}

	cmd="curl -s 'https://raptor.mws.sankuai.com/cat/r/chart/queryChartData' \
	  -H 'authority: raptor.mws.sankuai.com' \
	  -H 'accept: application/json, text/plain, */*' \
	  -H 'accept-language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7' \
	  -H 'content-type: application/json' \
	  -H 'cookie: "+mws_cookies+"' \
	  -H 'm-appkey: fe_cat-fe-static' \
	  -H 'm-traceid: 7290556161946523816' \
	  -H 'origin: https://raptor.mws.sankuai.com' \
	  -H 'sec-ch-ua-mobile: ?0' \
	  -H 'sec-fetch-dest: empty' \
	  -H 'sec-fetch-mode: cors' \
	  -H 'sec-fetch-site: same-origin' \
	  -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36' \
	  -H 'x-requested-with: XMLHttpRequest' \
	  --data-raw '"+json.dumps(req_data)+"' \
	  --compressed"

	curl_raptor_cmd_resp=subprocess.check_output(cmd, shell=True)
	curl_raptor_cmd_resp_json=json.loads(curl_raptor_cmd_resp)
	detail=curl_raptor_cmd_resp_json['data']['detail']
	# print(detail)
	detail=detail[0]
	return int(round(detail['avg']))	

def get_qps_limit(domain, cell):
	if not domain or not cell:
		return 0

	curl_rhino_cmd="curl -s 'https://rhino.sankuai.com/service/onelimiter/main/get?appKey="+domain+"&rhinoKey=rhino-one-limiter&set="+cell+"&grouptags=La:default' \
  -H 'Accept: application/json, text/plain, */*' \
  -H 'Accept-Language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7' \
  -H 'Connection: keep-alive' \
  -H 'Cookie: "+mws_cookies+"' \
  -H 'Referer: https://rhino.sankuai.com/' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36' \
  -H 'sec-ch-ua-mobile: ?0' \
  --compressed"

	curl_rhino_cmd_resp=subprocess.check_output(curl_rhino_cmd, shell=True)
	# print(curl_rhino_cmd)
	# print(curl_rhino_cmd_resp)
	curl_rhino_cmd_resp_json=json.loads(curl_rhino_cmd_resp)
	confJsonString=curl_rhino_cmd_resp_json['result']['configJson']
	return json.loads(confJsonString)['singleVmQps']['threshold']

def main():
	target_YmdHM=sys.argv[1] if len(sys.argv)>1 else datetime.datetime.now().strftime('%Y%m%d%H%M')
	try:
		# print(target_YmdHM)
		datetime.datetime.strptime(target_YmdHM, '%Y%m%d%H%M')
	except ValueError:
		print('Invalid datetime, format=%Y%m%d%H%M')
		return
	cell_name_map = {'waimai-huadong': '华东', 'waimai-huazhong': '华中'}
	# cell='waimai-huadong'
	# cell='waimai-huazhong'

	domains=["com.sankuai.product.query.trade"]
	# domains=["com.sankuai.product.retrieve"]
	# domains = ["com.sankuai.waimai.productquery"]
	# domains=["com.sankuai.product.customer.price"]
	# domains=["com.sankuai.product.query.basedata"]
	# domains=["com.sankuai.product.query.trade","com.sankuai.product.query.basedata","com.sankuai.product.customer.price","com.sankuai.product.retrieve","com.sankuai.waimai.productquery"]

	def format_qps_str(qps):
		return str(round(qps/10000,2))+'万' if qps>10000 else qps

	for domain in domains:
		print('\n\n=========== {} =========== 统计时间{} '.format(domain, target_YmdHM+'00'))
		total_qps=get_metric_by_ip(domain, target_YmdHM=target_YmdHM)
		total_tp999=get_metric_by_ip(domain,target_YmdHM=target_YmdHM ,metric='tp999')
		print('服务整体 QPS = {}'.format(format_qps_str(total_qps)))
		print('服务整体 TP999 = {}'.format(format_qps_str(total_tp999)))
		
		for cell, cell_name in cell_name_map.items():
			print("\n" + "=" * 40 + cell_name + "=" * 40)
			ip_arr_main=get_hosts(domain, cell)
			ip_arr_phf=get_hosts(domain, cell, 'group-pinhaofan')
			
			ip_arr_main_active=get_hosts_active(domain, cell)
			ip_arr_phf_active=get_hosts_active(domain, cell, 'group-pinhaofan')

			target_cell_qps=get_metric_by_ip(domain,ip_arr_main_active, target_YmdHM)
			if ip_arr_phf_active:
				target_cell_swimlane_qps=get_metric_by_ip(domain,ip_arr_phf_active, target_YmdHM)
				target_cell_all_swimlane_qps=get_metric_by_ip(domain,ip_arr_main_active+ip_arr_phf_active, target_YmdHM)
				print('{} 整体 QPS = {}'.format(cell_name,format_qps_str(target_cell_all_swimlane_qps)))
			print('{} {} QPS = {}'.format(cell_name,'主干道' if ip_arr_phf_active else '',format_qps_str(target_cell_qps)))
			if ip_arr_phf_active:
				print('{} 拼好饭 QPS = {}'.format(cell_name,format_qps_str(target_cell_swimlane_qps)))
			print()
			
			target_cell_tp999=get_metric_by_ip(domain,ip_arr_main_active, target_YmdHM ,metric='tp999')
			if ip_arr_phf_active:
				target_cell_swimlane_tp999=get_metric_by_ip(domain,ip_arr_phf_active, target_YmdHM ,metric='tp999')
				target_cell_all_swimlane_tp999=get_metric_by_ip(domain,ip_arr_main_active+ip_arr_phf_active, target_YmdHM ,metric='tp999')
				print('{} 整体 TP999 = {}'.format(cell_name,format_qps_str(target_cell_all_swimlane_tp999)))
			print('{} {} TP999 = {}'.format(cell_name,'主干道' if ip_arr_phf_active else '',target_cell_tp999))
			if ip_arr_phf_active:
				print('{} 拼好饭 TP999 = {}'.format(cell_name,format_qps_str(target_cell_swimlane_tp999)))
			print()

			single_vm_qps_limit=get_qps_limit(domain, cell)
			target_cell_single_vm_qps=round(target_cell_qps/len(ip_arr_main_active))
			print('{} {} 单机QPS = {}, 单机/限流 = {}/{} = {}%'.format(cell_name,'主干道' if ip_arr_phf_active else '',target_cell_single_vm_qps, target_cell_single_vm_qps, single_vm_qps_limit, str(round(target_cell_single_vm_qps/single_vm_qps_limit*100,2))))
			if ip_arr_phf_active:
				target_cell_swimlane_single_vm_qps=round(target_cell_swimlane_qps/len(ip_arr_phf_active))
				print('{} 拼好饭 单机QPS = {}, 单机/限流 = {}/{} = {}%'.format(cell_name,target_cell_swimlane_single_vm_qps, target_cell_swimlane_single_vm_qps, single_vm_qps_limit, str(round(target_cell_swimlane_single_vm_qps/single_vm_qps_limit,2))))
			

if __name__ == '__main__':
	main()
