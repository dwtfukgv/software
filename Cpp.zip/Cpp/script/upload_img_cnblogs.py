#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
# 


import requests
import json
from sys import argv

uploadUrl = 'https://upload.cnblogs.com/imageuploader/processupload?host=www.cnblogs.com'

headers = {
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "cookie": "_ga_4CQQXWHK3C=GS1.1.1622471792.1.0.1622472538.0; Hm_lvt_7a41cb9dd1d636656563500edd2ddba8=1635689876; sc_is_visitor_unique=rx12176449.1635776907.30AB032C866A4FDB917B7C9D9800FE10.1.1.1.1.1.1.1.1.1-12123033.1627897454.1.1.1.1.1.1.1.1.1; Hm_lvt_32247700466dcd5fcde2763a97d5c0e3=1638515715; Hm_lvt_0796772d2f6c0092d893025a82a53c88=1642593864; Hm_lvt_d63b8784bb79994299b3dd2563c1cd31=1646298838; __gads=ID=3955410a413c1301:T=1653292969:S=ALNI_MYI_TNMOaFZ_0PGyfP_e5f_C6m4kA; _gid=GA1.2.399453572.1661148198; Hm_lvt_866c9be12d4a814454792b1fd0fed295=1659360434,1659925031,1661148198; .Cnblogs.AspNetCore.Cookies=CfDJ8EOBBtWq0dNFoDS-ZHPSe53Ks-lEweRCilHDKKz7tuCD_WrIsGrIl3g5Vy498qZqEIBIlr88NguuburNiTEzcbZyUnVMk0OtnkFEal_UL5jxSDnx0fSaFlNpkIs503TCcu1tkzVa_QrnF9uHYXpIq7-9nEzfqpfHPdrBlhY_FJ3nEdHVu1qSm20HsPyaWUt1WqLF_AuiJfWqvcUvQv1_LdZnW4Ke18Cw9NM8l4lcnYDtkvtL12rUSeHYApN8KlmHEd6PcFkPpDa4qTQYAH8Zzi8Ls3jN_qspZtbCLTijWLDBtwB7GNWecHkdP6-5haAr2VZ8g6Z5XLEGE0fYakgb6lf7gJpUlodLRcd9dfgjC_Wejmn-Nexi3_FKTR_oWd1Wn8WYPZeFIo9cRJhChiopedJ-BI7VH7rrJzh-hgctT6l27HuAvcETPfu9-cAQX7Vg1zelRFY7CU2mS1mzMCBT9DH6Emss5Z5i8XwHzolslIDgjQ2FkP6m8Xig2udgQ7N7N-RhPh2oxNtNK2mzuwwlWq4MWlRQIC65-wIJCowCuSg1; .CNBlogsCookie=6E2F0E696DE69E9720726CB8817FEBFE481F2E6FB9CF84C3824892EF61F77ECC594E7E534F8E51DA6386D6B4227872C6FB8E80133B8A946289CF6B28FE6001D5CDDAFC1A3D9CA155C3207172DA34F4B7AB6A7680; __gpi=UID=0000047bc36f3cc6:T=1649094749:RT=1661327129:S=ALNI_MZ1jt84tVkcsFr3P78ETAvEMsS51A; _ga_3Q0DVSGN10=GS1.1.1661326342.1.1.1661328253.60.0.0; _ga=GA1.2.1845308819.1619576052; Hm_lpvt_866c9be12d4a814454792b1fd0fed295=1661330360; _gat_gtag_UA_476124_1=1; _gat_gtag_UA_48445196_1=1"}
# 类型映射
mimeMapping = {".png": 'image/png', '.gif': 'image/gif',
               '.jpg': 'image/jpeg','.JPG': 'image/jpeg', '.jpeg': 'image/jpeg'}

imgPath = "/Users/dwtfukgv/Downloads/brower/EPP餐箱正面.png"

# 对应的mime
mime = imgPath[imgPath.rindex("."):]

file = [
    ("", ("fileName", open(imgPath, "rb"), mimeMapping[mime]))
]

response = requests.post(uploadUrl, headers=headers, files=file)

data = json.loads(response.text)
print("![](%s)"%data['message'])
