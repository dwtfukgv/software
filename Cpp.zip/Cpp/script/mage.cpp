#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <cstring>
#include <set>
#include <queue>
#include <algorithm>
#include <vector>
#include <map>
#include <cctype>
#include <ctime>
#include <stack>
#include <sstream>
#include <list>
#include <assert.h>
#include <bitset>
#include <numeric>
#include <unordered_map>
#include <unordered_set>
#define debug() puts("++++")
#define print(x) cout<<"====== "<<(x)<<" ====="<<endl;
// #define gcd(a, b) __gcd(a, b)
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define fi first
#define se second
#define pb push_back
#define sqr(x) ((x)*(x))
#define ms(a,b) memset(a, b, sizeof a)
#define _mod(x) ((x) % mod + mod) % mod
#define ls(t, v) t[t.size()-1] = (v)
#define gls(t) t[t.size()-1]
#define es(it) erase(it)
#define rs(n) resize(n)
#define sz size()
#define be begin()
#define ed end()
#define rbe rbegin()
#define red rend()
#define bk back()
#define et empty()
#define ft front()
#define tp top()
#define pp pop()
#define ps push
#define uset unordered_set
#define umap unordered_map
#define pu push_up
#define pd push_down
#define cl clear()
#define lowbit(x) -x&x
// #define all 1,n,1
#define FOR(i,n,x)  for(int i = (x); i < (n); ++i)
#define freopenr freopen("in.in", "r", stdin)
#define freopenw freopen("out.out", "w", stdout)
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> P;
const int INF = 0x3f3f3f3f;
const LL LNF = 1e17;
const double inf = 1e20;
const double PI = acos(-1.0);
const double eps = 1e-12;
const int maxn = 100000 + 7;
const int maxm = 3000 + 7;
const LL mod = 1e9 + 7;
const int dr[] = {-1, 1, 0, 0, 1, 1, -1, -1};
const int dc[] = {0, 0, 1, -1, 1, -1, 1, -1};
int n, m;

inline bool is_in(int r, int c) {
  return r >= 0 && r < n && c >= 0 && c < m;
}
inline int read_int(){
  int x;  scanf("%d", &x);  return x;
}


inline char get_char(int c){
  return 'A' + c;
}

inline int get_int(char c){
  return 0;
}


umap<string, int> ID;
inline int get_idx(const string &s){
  return ID.count(s) ? ID[s] : ID[s] = ID.sz;
}

inline int get_pos(int x, int y){
  return x * n + y;
}

inline bool is_tool(const string &s, int pos){
  return islower(s[pos]);
}

inline void set_tool(string &s, int x, int y){
  int pos = get_pos(x, y);
  if(s[pos] >= 'a')  s[pos] -= 32;
  else  s[pos] += 32;
}

inline bool can_move(const string &s, int x1, int y1, int x2, int y2){
  if(!is_in(x2, y2))  return false;
  return abs(toupper(s[get_pos(x1, y1)]) - toupper(s[get_pos(x2, y2)])) == 1;
}

inline int get_row_nxt(int row, int x, int ordered){
  x += ordered;
  int t;
  return x < (t = row * n) ? x + n : (x >= t + n ? x - n : x);
}


inline int get_col_nxt(int col, int x, int ordered){
  x += ordered;
  int t;
  return x < 0 ? x + sqr(n) : (x >= (t = sqr(n)) ? x - t : x);
}

inline string move_row(string s, int row, int ordered){
  int start, nxt;
  char c = s[start = row * n];
  int cnt = n;
  while(cnt--){
    char cc = s[nxt = get_row_nxt(row, start, ordered)];
    s[start = nxt] = c;
    c = cc;
  }
  return s;
}

inline string move_col(string s, int col, int ordered){
  ordered *= n;
  int start, nxt;
  char c = s[start = col];
  int cnt = n;
  while(cnt--){
    char cc = s[nxt = get_col_nxt(col, start, ordered)];
    s[start = nxt] = c;
    c = cc;
  }
  return s;
}


int d[4][4][10][10000];
const int BIT = (1<<4) - 1;
const int X_BIT = 4;
const int Y_BIT = 8;
const int EX_BIT = 12;
const int EY_BIT = 16;

inline int make_data(int sx, int sy, int ex, int ey, int last){
  return sx | sy << X_BIT | ex << Y_BIT | ey << EX_BIT | last << EY_BIT;
}

inline int get_data_x(int st){
  return st & BIT;
}

inline int get_data_y(int st){
  return st >> X_BIT & BIT;
}

inline int get_data_ex(int st){
  return st >> Y_BIT & BIT;
}

inline int get_data_ey(int st){
  return st >> EX_BIT & BIT;
}

inline int get_data_last(int st){
  return st >> EY_BIT;
}


struct Magic {
  int data, p;
  string s;
  Magic(){}
  Magic(int dt, int ppp, string &ss): data(dt), p(ppp), s(ss) {
  }
};

vector<Magic> magics;
int step = 0;
void print_result(int u, int totalStep){
  if(u == -1)  return;
  Magic &now = magics[u];
  if(now.p == -1)  return;
  Magic &pre = magics[now.p];
  print_result(now.p, totalStep);
  int now_last = get_data_last(now.data);
  int pre_last = get_data_last(pre.data);
  totalStep < 10 ? printf("step %d: ", ++step) : printf("step %02d: ", ++step);
  if(now_last != pre_last){
    for(int i = -1; i <= 1; ++i){
      if(!i)  continue;
      for(int j = 0; j < n; ++j){
        if(move_row(pre.s, j, i) == now.s){
          printf("move the %d row %s.\n", j + 1, i == -1 ? "left" : "right");
          return;
        }
        if(move_col(pre.s, j, i) == now.s){
          printf("move the %d col %s.\n", j + 1, i == -1 ? "up" : "down");
          return;
        }
      }
    }
  }
  printf("jump from (%d, %d) to (%d, %d).\n", get_data_x(pre.data) + 1, get_data_y(pre.data) + 1, get_data_x(now.data) + 1, get_data_y(now.data) + 1);
}


void print___(string &s){
  for(int i = 0; i < n; ++i, printf("\n"))
    for(int j = 0; j < n; ++j)
      printf("%d ", toupper(s[i * n + j]) - 'A');
}

void bfs(int startX, int startY, int endX, int endY, string &s){
  ms(d, INF);
  bool tool = is_tool(s, get_pos(startX, startY));
  if(tool)  set_tool(s, startX, startY);
  d[startX][startY][tool][get_idx(s)] = 0;
  queue<int> q;
  magics.pb(Magic(make_data(startX, startY, endX, endY, tool), -1, s));
  q.ps(magics.sz - 1);

  while(!q.et){
    int current = q.ft;  q.pp;
    Magic g = magics[current];
    int oid = get_idx(g.s);
    int X = get_data_x(g.data);
    int Y = get_data_y(g.data);
    int EX = get_data_ex(g.data);
    int EY = get_data_ey(g.data);
    int LAST = get_data_last(g.data);
    int pre = d[X][Y][LAST][oid];

    for(int i = 0; i < 4; ++i){
      int x = X + dr[i];
      int y = Y + dc[i];
      if(!can_move(g.s, X, Y, x, y))  continue;
      int ll = LAST;
      string nxt = g.s;
      if(is_tool(nxt, get_pos(x, y))){
        ++ll;
        set_tool(nxt, x, y);
      }
      int &ans = d[x][y][ll][get_idx(nxt)];
      if(ans > pre + 1){
        ans = pre + 1;
        magics.pb(Magic(make_data(x, y, EX, EY, ll), current, nxt));
        q.ps(magics.sz - 1);
      }
      if(x == EX && y == EY){
        printf("need %d steps to move to end position.\n", ans);
        print_result(magics.sz - 1, ans);
        return;
      }
    }

    if(LAST){
      for(int i = -1; i <= 1; ++i){
        if(!i)  continue;
        for(int j = 0; j < n; ++j){
          string ss = move_row(g.s, j, i);
          int nxt_x = X, nxt_y = Y, nxt_ex = EX, nxt_ey = EY;
          if(j == X){  // row
              int index = get_row_nxt(j, X * n + Y, i);
              nxt_x = index / n;
              nxt_y = index % n;
          }
          if(j == EX){
              int index = get_row_nxt(j, EX * n + EY, i);
              nxt_ex = index / n;
              nxt_ey = index % n;
          }
          int &ans = d[nxt_x][nxt_y][LAST-1][get_idx(ss)];
          if(ans > pre + 1){
            ans = pre + 1;
            magics.pb(Magic(make_data(nxt_x, nxt_y, nxt_ex, nxt_ey, LAST - 1), current, ss));
            q.ps(magics.sz - 1);
          }
          nxt_x = X, nxt_y = Y, nxt_ex = EX, nxt_ey = EY;
          if(j == Y){  // col
              int index = get_col_nxt(j, X * n + Y, i * n);
              nxt_x = index / n;
              nxt_y = index % n;
          }
          if(j == EY){
              int index = get_col_nxt(j, EX * n + EY, i * n);
              nxt_ex = index / n;
              nxt_ey = index % n;
          }
          string sss = move_col(g.s, j, i);
          int &res = d[nxt_x][nxt_y][LAST-1][get_idx(sss)];
          if(res > pre + 1){
            res = pre + 1;
            magics.pb(Magic(make_data(nxt_x, nxt_y, nxt_ex, nxt_ey, LAST - 1), current, sss));
            q.ps(magics.sz - 1);
          }
        }
      }
    }
  }
}



int main(){
  printf("please input the length of magic: \n");
  scanf("%d", &n);  m = n; 
  printf("please input the content of %d x %d migic: \n", n, n);
  string s = "";
  for(int i = 0; i < n; ++i)
    for(int j = 0; j < n; ++j)
      s.pb(get_char(read_int()));
  printf("please input init position: \n");
  int startX, startY; scanf("%d %d", &startX, &startY);  --startX, --startY;
  printf("please input end position: \n");
  int endX, endY; scanf("%d %d", &endX, &endY);  --endX, --endY;
  printf("please input the number of tool: \n");
  int k;  scanf("%d", &k);
  printf("please input %d tool position: \n", k);
  while(k--){
    int x, y;  scanf("%d %d", &x, &y);  --x; --y;
    set_tool(s, x, y);
  }
  printf("\nthe answer of this mage: \n");
  bfs(startX, startY, endX, endY, s);
  return 0;
}