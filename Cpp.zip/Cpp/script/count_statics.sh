#!/usr/bin bash

target_path="/Users/dwtfukgv/Downloads/brower"
count_field=`echo $target_path | awk -F'/' '{print NF+1}'`
echo "========== PDF分组数量: ========="
find $target_path -name "*.pdf" | awk -F'/' '{s[$'"$count_field"']+=1} END{for(i in s){print i,":",s[i]}}'

pdf_total=`find $target_path -name "*.pdf" | wc -l | xargs`
echo "PDF总数量: $pdf_total"
echo ""


# ls $target_path | awk '{print $0"$"}'
current_files=`ls $target_path | awk '{print $0"###"}'`
echo $current_files
OLD_IFS="$IFS"
export IFS="### "
file_array=($current_files)
export IFS="$OLD_IFS"


for var in ${file_array[@]} 
do
	echo $var
done