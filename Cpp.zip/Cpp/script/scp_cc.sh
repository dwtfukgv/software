#!/usr/bin/env bash
scp $1 dwtfukgv@81.70.203.63:/home/dwtfukgv/scp_file
