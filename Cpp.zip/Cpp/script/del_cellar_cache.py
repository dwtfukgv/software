#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

import json, requests

url = 'https://cellar.sankuai.com/operation/client/request'
cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; moa_deviceId=578770F794795F8291CADC0A81F79E66; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; _ga=GA1.2.423863992.1692353451; uu=911473a0-55f1-11ee-998e-15626fb52c1f; cid=1; ai=1; _ga_YQ7GRE77BE=GS1.2.1696843965.1.0.1696843965.0.0.0; _lx_utm=utm_source%3Dxm; _gid=GA1.2.1007573511.1698207964; _ga_9JGDVD6E56=GS1.2.1698207964.6.1.1698207984.0.0.0; _lxsdk_s=18b656fc374-2c2-0f7-a52%7C%7C1000; moaDeviceId=578770F794795F8291CADC0A81F79E66; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALFWhuPgGUdeJlviYEaYvaZ18AqNuPFZvqLuB5bc66tL/tnEFzPdldcBpqBMEAAAAI8zMTN5mzBd4u5eO/hXFqHteVZnDHaoh+45S5Zd7IBmXNgJX; kvcms_ssoid=eAHjYBSYu-Akk8KqtqW3thkasWaXJecWWykkGlommpkkm1hamKWZmKcYJBpZmmmlpZmYGBtampqkpjhdYRTSDE9NCk5OzUutMTW3MDc3cDO3NDG3NHWzMLI0dHZ0cTZwtDAEirmamSlc33zvwy5DDWYjggZbgFzjwOaxqPfX-m2GAZtbpt6cZdjEqMXFFhjknJ-SKiT0dMnyFxsXPutc_XxB44t1S16sb5RgUWjYMVNTA6J4EiMHzGGzGPWM0kwsLBJNjYxNDFKME1PMDBJTjA2MzVPMzY2NTSwTE-MNzSwNzC2NTSwMzI0NoxQMkk2MDSyMDRMNtNJMUsyTLc0MU8yBKtMMDUySgRJNjHzpqSWOycmpxcUh-dmpeV2MzMXF-QCGcmqD**eAEFwYEBACAEBMCVyhONQ8_-I3RHTeRVtOj4SkFBbcIkTm0KWzw2z3sLxPFrt8GaCF8aVP8tahEF**SKykf3Lg-JBbowZyioQ-UTpfJPOyVLCG_jY2rgKNMI5_bGvew0C85-SkM7eBbWAKiENrQMWiGs5DH6Af1dXulQ**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjk4MzEyMDQ1MzU0'

productquery_cluster_id = 1026


def get_combo_spu_key(id):
    return "tsp:combogroup:" + str(id) 

def get_combo_sku_key(id):
    return "tsp:sku:combogroup:" + str(id)



def del_cellar(cluster_id, area, key_func, id):
    data = {}
    data['requestType'] = 'delete'
    data['pkey'] = key_func(id)
    data['area'] = area
    data['dsClusterId'] = cluster_id
    headers = {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Cookie": cookie,
        "Authority": "cellar.sankuai.com",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    }
    resp = requests.post(url=url, headers=headers, data=data)
    res = json.loads(resp.content)['success']
    print(id, res)


def del_combo_spu(ids):
    for i in ids:
        del_cellar(productquery_cluster_id, 2, get_combo_spu_key, i)

def del_combo_sku(ids):
    for i in ids:
        del_cellar(productquery_cluster_id, 2, get_combo_sku_key, i)

if __name__ == '__main__':
    ids = [17969163332,17969163333,17969163334,17969163335,18024717203,18024717204,18024717205,18024717206,18024717207,18024717209,18024795802,18024795803,18024795804,18024795805,18024795806,18026683873,18026683874,18026683875,18026683876,18026683881,18026683882]
    for i in ids:
        del_cellar(productquery_cluster_id, 2, i)