#!/usr/bin/env bash
scp $1 dwtfukgv@81.70.254.48:/home/dwtfukgv/scp_file
