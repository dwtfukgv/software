#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import os

start = ['#include', '# include']
end = ['.hpp', '.cpp']


rep = {
	'../interpreterGenerator_x86.hpp': 'interpreterGenerator_x86.hpp',
}

old = '"../'
new = '"'
path = '/Users/dwtfukgv/ClionProjects/jdk8u/jdk'

def deal_all_file(path, func):
	for rt, _, files in os.walk(path):
		for f in files:
			file = os.path.join(rt, f)
			if not file.endswith('.cpp') and not file.endswith('.hpp'):
				continue
			func(file)


def is_in(line):
	for s in start:
		if line.strip().startswith(s):
			return True
	return False

def del_file(file):
	print(file)
	with open(file, 'r') as f:
		with open(file + 'a', 'w') as g:
			for line in f.readlines():
				if not is_in(line):
					g.write(line)
				else:
					# if '_x86' in line:
					# 	g.write(line.replace('"../', '"'))

					# else:
					# 	g.write(line)
					g.write(line.replace(old, new, 1))
	os.rename(file + 'a', file)


if __name__ == '__main__':
	# del_file('../4.cpp')
	deal_all_file(path, del_file)

