# -*- coding: utf-8 -*-

'''
octo异常节点状态统计
'''

import importlib.util,subprocess
if importlib.util.find_spec('browsercookie') is None:
	subprocess.check_call(['pip', 'install', 'browsercookie'])

import browsercookie

cookies = browsercookie.chrome()
site_cookies = []
mws_cookies=''
for cookie in cookies:
	if '.mws.sankuai.com' == cookie.domain:
		site_cookies.append(cookie)
		mws_cookies+=cookie.name+'='+cookie.value+';'

import sys,subprocess,json		

def fetch_all_nodes(domain):
	# dms_cond=("set={}" if d == Dms_type.SET else "idc={}").format(dms_val)
	curl_octo_cmd_pattern="curl -s 'https://octo.mws.sankuai.com/api/octo/v2/provider/{}/providers?env=prod&appkey={}&type=1&currentPage=1&limit=50000&sort=desc&sortby=lastUpdateTime' \
  -H 'authority: octo.mws.sankuai.com' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'accept-language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7' \
  -H 'cookie: "+mws_cookies+"' \
  -H 'm-appkey: fe_com.sankuai.octomesh.web.fe' \
  -H 'm-traceid: -6837560296908145478' \
  -H 'referer: https://octo.mws.sankuai.com/service-provider-info?appkey=com.sankuai.product.query.trade&type=thrift&env=prod' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-fetch-dest: empty' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-site: same-origin' \
  -H 'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36' \
  -H 'x-requested-with: XMLHttpRequest' \
  --compressed"  
	# curl_octo_cmd=curl_octo_cmd_pattern.format(domain,domain,s.value,dms_cond)
	curl_octo_cmd=curl_octo_cmd_pattern.format(domain,domain)
	curl_octo_cmd_resp=subprocess.check_output(curl_octo_cmd, shell=True)
	curl_octo_cmd_resp_json=json.loads(curl_octo_cmd_resp)
	items=curl_octo_cmd_resp_json['data']['items']

	return items

def pretty_print_octo_nodes(nodes):
	d={"default": {"default": [0, 0, 0, 0, 0 ], "waimai-east": [0, 0, 0, 0, 0 ], "waimai-first-gray": [0, 0, 0, 0, 0 ], "waimai-huadong": [0, 0, 0, 0, 0 ], "waimai-huazhong": [0, 0, 0, 0, 0 ], "waimai-north": [0, 0, 0, 0, 0 ], "waimai-north-experiment": [0, 0, 0, 0, 0 ], "waimai-second-gray": [0, 0, 0, 0, 0 ], "waimai-south": [0, 0, 0, 0, 0 ], "waimai-west": [0, 0, 0, 0, 0 ] }, "group-pinhaofan": {"default": [0, 0, 0, 0, 0 ], "waimai-east": [0, 0, 0, 0, 0 ], "waimai-first-gray": [0, 0, 0, 0, 0 ], "waimai-huadong": [0, 0, 0, 0, 0 ], "waimai-huazhong": [0, 0, 0, 0, 0 ], "waimai-north": [0, 0, 0, 0, 0 ], "waimai-north-experiment": [0, 0, 0, 0, 0 ], "waimai-second-gray": [0, 0, 0, 0, 0 ], "waimai-south": [0, 0, 0, 0, 0 ], "waimai-west": [0, 0, 0, 0, 0 ] }, "group-tuanhaohuo": {"default": [0, 0, 0, 0, 0 ] } }
	err_nodes=[]
	for n in nodes:
		n['swimlane']=n['swimlane'] if n['swimlane'] else 'default'
		n['cell']=n['cell'] if n['cell'] else 'default'
		d[n['swimlane']][n['cell']][n['status']]=d[n['swimlane']][n['cell']][n['status']]+1
		if n['status'] != 2 or n['weight'] != 10:
			err_nodes.append(n)

	status_desc=['未启动','启动中','正常','','禁用']
	if not err_nodes:
		return

	print('# 异常节点数统计（仅节点状态异常）')
	for s in d:
		for c in d[s]:
			for i in range(5):
				if status_desc[i] and i != 2 and d[s][c][i]:
					print('泳道: {}, SET: {}, {}节点数: {}'.format(s, c, status_desc[i],str(d[s][c][i])))
	print('\n# 异常节点（含权重异常）')
	for e in err_nodes:
		print('泳道: {}, SET: {}, {}@{}:{} , {}, 权重 {}'.format(e['swimlane'],e['cell'],e['name'],e['ip'],e['port'],e['statusDesc'], e['weight']))
	
def main():
	appkey=sys.argv[1] if len(sys.argv)>1 else 'com.sankuai.waimai.productquery'
	nodes=fetch_all_nodes(appkey)
	if not nodes:
		print('appkey: {}下无节点'.format(appkey))
		return
	print('appkey: {} 节点状态统计结果如下。'.format(appkey))
	pretty_print_octo_nodes(nodes)
	

if __name__ == '__main__':
	main()
