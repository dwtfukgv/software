#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# File Name: convert_cpp_tab.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-21 18:55

import sys

def convert_cpp_file(file_name = "./1.cpp"):
    with open(file_name, 'r') as fin:
        data = fin.read()
        data = data.replace('\t', '  ')
        print data

if '__main__' == __name__:
    if len(sys.argv) >= 2:
        convert_cpp_file(sys.argv[1])
    else:
        convert_cpp_file()


