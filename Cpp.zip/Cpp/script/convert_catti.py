#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# File Name: convert_cpp_tab.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-21 18:55


import json

def remove_all_next_line(s):
	return s.replace("\n", "").replace("'", "\\'")


def insert_vocabulary(sentence, type_, A, B, C, D, answer, expain):
	sentence = remove_all_next_line(sentence)
	A = remove_all_next_line(A)
	B = remove_all_next_line(B)
	C = remove_all_next_line(C)
	D = remove_all_next_line(D)
	answer = remove_all_next_line(answer)
	expain = remove_all_next_line(expain)
	s = f"INSERT INTO `tb_vocabulary` (`sentence`, `vocabulary_type`, `A`, `B`, `C`, `D`, `answer`, `explain`, `ctime`, `utime`)VALUES('{sentence}', {type_}, '{A}', '{B}', '{C}', '{D}', '{answer}', '{expain}', unix_timestamp(), unix_timestamp());"
	print(s)

# 3 7 8 9 10 11 12 13 14 16
def read_vocabulary_selection_file(file):
	c = 1
	res = []
	with open(file) as f:
		while True:
			data = {}
			sentence = f.readline()
			if sentence is None or len(sentence) == 0:
				break
			if c > 8:
				# num = int(sentence.split(".")[0].strip()) - 1
				# print(num)
				expain = sentence.replace('【答案】', '')
				# print(c, expain)
				while expain[0] == ' ':
					expain = expain[1:]
				answer = expain[0]
				expain = expain[1:]
				while expain[0] == ' ' or expain[0] == '.':
					expain = expain[1:]
				data = res[c - 9]
				data['answer'] = answer
				data['expain'] = expain.strip()
				c += 1

			else:
				A = f.readline().strip()
				B = f.readline().strip()
				C = f.readline().strip()
				D = f.readline().strip()
				sentence = sentence.strip()
				if sentence[-1] != '.':
					sentence += "."
				data['sentence'] = sentence
				data['A'] = A
				data['B'] = B
				data['C'] = C
				data['D'] = D
				res.append(data)
				c += 1
			
	for data in res:
		insert_vocabulary(data['sentence'], 1, data['A'], data['B'], data['C'], data['D'], data['answer'], data['expain'])

# 27
def read_vocabulary_replacement_file(file, word_file):

	underline_words = []
	with open(word_file) as f:
		while True:
			line = f.readline()
			if line is None or len(line.strip()) == 0:
				break
			underline_words.append(line.strip())

	cnt = 0
	res = []
	with open(file) as f:
		while True:
			data = {}
			sentence = f.readline()
			if sentence is None or len(sentence) == 0:
				break

			if cnt >= 8:
				expain = sentence.replace('【答案】', '')
				# print(c, expain)
				while expain[0] == ' ':
					expain = expain[1:]
				answer = expain[0]
				expain = expain[1:]
				while expain[0] == ' ' or expain[0] == '.':
					expain = expain[1:]
				data = res[cnt - 8]
				data['answer'] = answer
				data['expain'] = expain.strip()
				cnt += 1

			else:
				A = f.readline().strip()
				B = f.readline().strip()
				C = f.readline().strip()
				D = f.readline().strip()
				word = underline_words[cnt]
				sentence = sentence.replace(word, "<u>" + word + "</u>").strip()
				if sentence[-1] != '.':
					sentence += "."
				data['sentence'] = sentence
				data['A'] = A
				data['B'] = B
				data['C'] = C
				data['D'] = D
				res.append(data)
				cnt += 1

	for data in res:
		insert_vocabulary(data['sentence'], 2, data['A'], data['B'], data['C'], data['D'], data['answer'], data['expain'])


# 52
underline_parses = [["Scarcely"], ["then"], ["involving in"], ["from"], ["from"], ["lubricate"], ["weaken"], ["framework"]]
def read_vocabulary_correction_file(file):

	underline_words = []
	with open(word_file) as f:
		while True:
			line = f.readline()
			if line is None or len(line.strip()) == 0:
				break
			underline_words.append(line.strip())

	cnt = 0
	res = []
	with open(file) as f:
		while True:
			data = {}
			sentence = f.readline()
			if sentence is None or len(sentence) == 0:
				break

			if cnt >= 8:
				expain = sentence.replace('【答案】', '')
				# print(c, expain)
				while expain[0] == ' ':
					expain = expain[1:]
				answer = expain[0]
				expain = expain[1:]
				while expain[0] == ' ' or expain[0] == '.':
					expain = expain[1:]
				data = res[cnt - 8]
				data['answer'] = answer
				data['expain'] = expain.strip()
				cnt += 1

			else:
				A = f.readline().strip()
				B = f.readline().strip()
				C = f.readline().strip()
				D = f.readline().strip()
				words = underline_words[cnt]
				for word in words:
					sentence = sentence.replace(word, "<u>" + word + "</u>").strip()
				if sentence[-1] != '.':
					sentence += "."
				data['sentence'] = sentence
				data['A'] = A
				data['B'] = B
				data['C'] = C
				data['D'] = D
				res.append(data)
				cnt += 1

	for data in res:
		insert_vocabulary(data['sentence'], 3, data['A'], data['B'], data['C'], data['D'], data['answer'], data['expain'])




	# cnt = 0
	# with open(file) as f:
	# 	while True:
	# 		sentence = f.readline()
	# 		if sentence is None or len(sentence) == 0:
	# 			break
	# 		A = f.readline()
	# 		B = f.readline()
	# 		C = f.readline()
	# 		D = f.readline()
	# 		parses = underline_parses[cnt]
	# 		for parse in parses:
	# 			sentence = sentence.replace(parse, "<u>" + parse + "</u>")
	# 		cnt += 1
	# 		insert_vocabulary(sentence, 3, A, B, C, D, '', '')



def handle_error_pos():
	with open("./data/1.json") as f:
		data_list = json.load(f)['data']
		res = []
		a = []
		i = 0

		for data in data_list:
			a.append(data)

			i += 1
			if i % 8 == 0:
				explain = a[-1]['explain']
				answer = a[-1]['answer']

				for j in range(7, 0, -1):
					a[j]['explain'] = remove_all_next_line(a[j-1]['explain'])
					a[j]['answer'] = a[j-1]['answer']
					# print(i)
				a[0]['explain'] = remove_all_next_line(explain)
				a[0]['answer'] = answer
				
				for x in a:
					s = f"UPDATE `tb_vocabulary` SET `answer` = '{x['answer']}', `explain` = '{x['explain']}' WHERE `id` = {x['id']};"
					# s = remove_all_next_line(s)
					print(s)
				# break
				a = []

if __name__ == '__main__':
	# read_vocabulary_selection_file('./data/catti.data')
	# read_vocabulary_replacement_file("./data/catti.data", "./data/replacement.data")
	# handle_error_pos()
	read_vocabulary_correction_file("./data/catti.data", "./data/replacement.data")




