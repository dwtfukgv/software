#!/usr/bin/env bash
scp dwtfukgv@81.70.254.48:$1 $2
