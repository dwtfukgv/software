#!/usr/bin/python3
# -*- coding: utf-8 -*-
# File Name: app_filter.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-04-21 18:55

import json
import sys
import requests
import os
import sqlite3
import re

import keyring
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2

import browsercookie

cookies = browsercookie.chrome()

simple_to_app_key = {
    "pq": "com.sankuai.waimai.productquery",
    "trade": "com.sankuai.product.query.trade",
    "retrieve": "com.sankuai.product.retrieve",
    "qa": "com.sankuai.product.queryasync",
    "queryasync": "com.sankuai.product.queryasync",
    "ta": "com.sankuai.product.tradeasync",
    "tradeasync": "com.sankuai.product.tradeasync",
    "basedata": "com.sankuai.product.query.basedata",
    "bd": "com.sankuai.product.query.basedata",
    "rtstock": "com.sankuai.waimai.productrtstock",
    "price": "com.sankuai.product.customer.price",
    "queryasyncmq": "com.sankuai.product.queryasync.mq",
    "qamq": "com.sankuai.product.queryasync.mq",
    "queryasyncpeer": "com.sankuai.product.queryasync.peer",
    "qap": "com.sankuai.product.queryasync.peer",
    "wmproxy": "com.sankuai.product.waimai.maiseproxy",
    "wmbs": "com.sankuai.product.waimai.maisebs",
    "ridermallproxy": "com.sankuai.product.query.bsproxy",
    "rmproxy": "com.sankuai.product.query.bsproxy",
    "ridermallbs": "com.sankuai.product.query.bs",
    "rmbs": "com.sankuai.product.query.bs",
    "wmspproxy": "com.sankuai.retrievebs.wmsp.maiseproxy",
    "wmspbs": "com.sankuai.retrievebs.wmsp.maisebs",
    "querymanager": "com.sankuai.product.querymanager",
    "qm": "com.sankuai.product.querymanager",
    "joiner": "com.sankuai.productsearchbs.index.joiner",
    "groupcache": "com.sankuai.waimaieapp.maven.oupproductcache",
    "groupstore": "com.sankuai.waimaieapp.maven.oupproductstore",
    "common": "com.sankuai.product.query.common",
    "dal": "com.sankuai.product.query.dal",
    "tradeclient": "com.sankuai.product.query.tradeclient",
    "tc": "com.sankuai.product.query.tradeclient",
    "retrieveclient": "com.sankuai.product.c.retrieve",
    "rc": "com.sankuai.product.c.retrieve",
    "banma": "com.sankuai.banma.api.mall",
    "router": "com.sankuai.waimai.c.setrouter",
    "priceclient": "com.sankuai.product.customer.priceclientapi",
    "pc": "com.sankuai.product.customer.priceclientapi",
    "instore": "com.sankuai.product.query.instore",
    "basedataclient": "com.sankuai.product.query.basedataclient",
    "bdc": "com.sankuai.product.query.basedataclient",
    "sa": "com.sankuai.product.stockasync",
    "stockasync": "com.sankuai.product.stockasync"
}

def get_cookie():
    cookies = browsercookie.chrome()
    mws_cookies = ''
    for cookie in cookies:
        if '.mws.sankuai.com' == cookie.domain:
            # print(cookie)
            # print(cookie.value)
            mws_cookies += cookie.name + '=' + cookie.value + ';'
    # print(mws_cookies)
    return mws_cookies
    # with open('/Users/dwtfukgv/script/Cpp/script/cookie/avatar.ck', 'r') as f:
    #     return f.readline()
        

def gen_cookie():
    my_pass = keyring.get_password('Chrome Safe Storage', 'Chrome')
    my_pass = my_pass.encode('utf8')
    iterations = 1003
    cookie_file = os.path.expanduser('~/Library/Application Support/Google/Chrome/Default/Cookies')
    salt = b'saltysalt'
    length = 16
    iv = b' ' * length

    with sqlite3.connect(cookie_file) as conn:
        result = conn.execute("select encrypted_value from cookies where host_key = '.mws.sankuai.com' and name = 'yun_portal_ssoid'").fetchall()
    token = result[0][0][3:]
    key = PBKDF2(my_pass, salt, length, iterations)
    cipher = AES.new(key, AES.MODE_CBC, IV=iv)
    dec_token = cipher.decrypt(token)
    ck = dec_token.decode()
    i = len(ck) - 1
    while i and ord(ck[i]) <= 32:
        i -= 1
        continue
    ck = ck[:i+1]
    with open('/Users/dwtfukgv/script/Cpp/script/cookie/avatar.ck', 'w') as f:
        f.write('yun_portal_ssoid=' + ck)


def default_subtitle(app_key, *args):
    return "open " + app_key


def gen_items(arg, op, func, *args):
    result = []
    for k,v in simple_to_app_key.items():
        if k.startswith(arg):
            data = {
                "title": k,
                "subtitle": default_subtitle(v),
                "autocomplete": k,
                "variables": {
                    "arg1": args[0] if not args[0].endswith("$") else args[0][:-1]
                },
                "arg": v
            }
            result.append(data)
    if op is not None and len(result) > 0 and args[0].endswith("$"):
        result[0]['subtitle'] = func(result[0]['arg'], op, *args)
        # print(func('com.sankuai.product.query.trade', op, args[0]))

    # print(get_cookie())
    msg = 'Please modify input'
    if len(result) == 0 and len(arg) > 10:
        for i in range(0, 5):
            try:
                headers = {'Cookie': get_cookie(), 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'Content-Type': 'application/json;charset=utf-8'}
                headers['Referer'] = 'https://avatar.mws.sankuai.com/'
                # print(headers)
                response = requests.get(f'https://avatar.mws.sankuai.com/api/v2/avatar/appkey/query?query={arg}', headers=headers)
                # print(response)
                data = json.loads(response.content)['data']
                # print(data)
                app_key = data[0]['appkey']
                result.append({
                    "title": app_key,
                    "subtitle": default_subtitle(app_key),
                    "autocomplete": app_key,
                    "variables": {
                        "arg1": args[0] if len(args[0]) == 0 else args[0][:-1]
                    },
                    "arg": app_key
                })
                break
            except Exception as e:
                # print(e)
                # gen_cookie()
                msg = 'cookie expire'

    if len(result) == 0:
        data = {
            "title": "No app key match",
            "subtitle": msg
        }
        return [data]
    return result


def rt_subtitle(app_key, op, *args):
    return default_subtitle(app_key, op)


def lion_subtitle(app_key, op, *args):
    url = ''
    if op == 'lion':
        url = f'https://lion.mws.sankuai.com/mwsapi/v1/env/prod/appKey/{app_key}/group/default/defaultConfigInstance/type/key/get'
    elif op == 'lionst':
        url = f'https://lion.mws.sankuai.com/mwsapi/v1/env/staging/appKey/{app_key}/group/default/defaultConfigInstance/type/key/get'
    elif op == 'liontest':
        url = f'https://lion.mws-test.sankuai.com/mwsapi/v1/env/test/appKey/{app_key}/group/default/defaultConfigInstance/type/key/get'
    if len(url) == 0:
        return default_subtitle(app_key, op)
    # print(app_key, op, args)
    for i in range(3):
        try:
            # cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; moa_deviceId=578770F794795F8291CADC0A81F79E66; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; u=2008143655; ssoid=eAGFjrtKA0EUQFmRsFjJVpZbJlvInZk7c-daGVeDpY9CsJHZnd1Sf8DCiI2WgoUJYgKBFIIiNvoJdhY2dhJRt7QWxAdibXs4HE4YTJ70bsfim4-Du66QoQGWwmqeiZ1gZzBHtqZE8uAkm6QsEZVgjYWfuw-ixlqRrebFZrGtyRJBixiJdctKFmlzPoWmFd9swZj4_e1pdCrqgfw3bH-GZmuLo8fPflcsXe0dPXTEbpBM1JZX0i1fRNHzYFhd9l_2z1577ep8UF20p8bjnevjRv1XPgzCv7FOMC1LtNZpqRC8ct6A8woUeSKlkJ3bEIaBWKEFUmI9ZqkzXebaUCLRorFgpRJZlhFKAwBfm-1imA**eAEFwQEBwDAIAzBLsELP7FCGfwlPaMj2ZZ2p4RNArRBLy15Fb-N-dfZeN5NHRjZDDxhy_Ac49RFa**FetGvd7m4YFSj6970Y7pN2cPtv8LXsuqdCD-HFWMB6EqjI8IpxY3-8Z_vijldfNWral6tApys9hbn8wxBNEF5Q**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjkxMDQyODg5NDAx; yun_portal_ssoid=eAGFjrtKA0EUQFmRsFjJVpZbJlvInZk7c-daGVeDpY9CsJHZnd1Sf8DCiI2WgoUJYgKBFIIiNvoJdhY2dhJRt7QWxAdibXs4HE4YTJ70bsfim4-Du66QoQGWwmqeiZ1gZzBHtqZE8uAkm6QsEZVgjYWfuw-ixlqRrebFZrGtyRJBixiJdctKFmlzPoWmFd9swZj4_e1pdCrqgfw3bH-GZmuLo8fPflcsXe0dPXTEbpBM1JZX0i1fRNHzYFhd9l_2z1577ep8UF20p8bjnevjRv1XPgzCv7FOMC1LtNZpqRC8ct6A8woUeSKlkJ3bEIaBWKEFUmI9ZqkzXebaUCLRorFgpRJZlhFKAwBfm-1imA**eAEFwQEBwDAIAzBLsELP7FCGfwlPaMj2ZZ2p4RNArRBLy15Fb-N-dfZeN5NHRjZDDxhy_Ac49RFa**FetGvd7m4YFSj6970Y7pN2cPtv8LXsuqdCD-HFWMB6EqjI8IpxY3-8Z_vijldfNWral6tApys9hbn8wxBNEF5Q**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjkxMDQyODg5NDAx; com.sankuai.lion.portal_strategy=; com.sankuai.lion.portal_random=; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALL/VulVhtG9DBw2EJA37QPCD99XQnMGpOXxIwlFXrB/PBTd7hwRWl99zZ5GhAAAAIxcL/ko9RJRaWLPASys7sBTKdE2GsByw7qXAm5HTbeYpIR1s; logan_session_token=gm0w73wdle5nx18kc2bb; _lxsdk_s=189b9026815-dd2-3ff-cf0%7C%7C222'
            headers = {'Cookie': get_cookie(), 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json;charset=utf-8', 'x-requested-with': 'XMLHttpRequest'}
            data = {}
            data['key'] = args[0][:-1]
            response = requests.post(url, data=json.dumps(data), headers=headers)
            # print(response.content)
            res = json.loads(response.content)['data']['list']
            if len(res) > 0:
                return data['key'] + ": " + res[0]['value']
            elif len(res) == 0:
                return "no config"
        except Exception as e:
            print(e)
            gen_cookie()
    return default_subtitle(app_key, op)

if __name__ == '__main__':
    arg = sys.argv[1]
    # arg = '10.178.157.134'
    # write_cookie()

    args = arg.split("\\")
    op = sys.argv[2] if len(sys.argv) > 2 else None
    func = default_subtitle
    # print(args, op)
    if op is None:
        pass
    elif op.startswith("lion") and len(args) > 1:
        func = lion_subtitle
    elif op.startswith("rt") and re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$').match(args[0]):
        func = rt_subtitle
        args.append(args[0] + "$")

    

    data = json.dumps({
        "items": gen_items(args[0].strip(), op, func, args[1].strip() if len(args) > 1 else "")
    }, indent=2)
    sys.stdout.write(data)


