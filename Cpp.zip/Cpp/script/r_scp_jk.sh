#!/usr/bin/env bash
scp dwtfukgv@119.23.43.211:$1 $2
