#!/usr/bin/env bash
scp dwtfukgv@81.70.203.63:$1 $2
