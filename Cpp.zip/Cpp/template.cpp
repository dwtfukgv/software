#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <string>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <cstring>
#include <set>
#include <queue>
#include <algorithm>
#include <vector>
#include <map>
#include <cctype>
#include <ctime>
#include <stack>
#include <sstream>
#include <list>
#include <assert.h>
#include <bitset>
#include <numeric>
#include <unordered_map>
#define debug() puts("++++")
#define print(x) cout<<(x)<<endl
// #define gcd(a, b) __gcd(a, b)
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define fi first
#define se second
#define pb push_back
#define sqr(x) ((x)*(x))
#define ms(a,b) memset(a, b, sizeof a)
#define sz size()
#define be begin()
#define ed end()
#define pu push_up
#define pd push_down
#define cl clear()
#define lowbit(x) -x&x
// #define all 1,n,1
#define FOR(i,n,x)  for(int i = (x); i < (n); ++i)
#define freopenr freopen("in.in", "r", stdin)
#define freopenw freopen("out.out", "w", stdout)
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> P;
const int INF = 0x3f3f3f3f;
const LL LNF = 1e17;
const double inf = 1e20;
const double PI = acos(-1.0);
const double eps = 1e-8;
const int maxn = 1000 + 7;
const int maxm = 2000000 + 7;
const LL mod = 1e9 + 7;
const int dr[] = {-1, 1, 0, 0, 1, 1, -1, -1};
const int dc[] = {0, 0, 1, -1, 1, -1, 1, -1};
int n, m;
inline bool is_in(int r, int c) {
	return r >= 0 && r < n && c >= 0 && c < m;
}

/* ======================================================================== */

// set
namespace SET{
  void set_operaotion(){
    set<int> a, b;
    std::vector<int> c;
    set_union(a.be, a.ed, b.be, b.ed, back_inserter(c));
    set_intersection(a.be, a.ed, b.be, b.ed, back_inserter(c));
    set_difference(a.be, a.ed, b.be, b.ed, back_inserter(c));
    copy(istream_iterator<string>(cin),istream_iterator<string>(),back_inserter(a));// 输入
    std::copy_n(std::begin(a), a.size()-1,std::ostream_iterator<int>(std::cout, " "));  // 输出
    std::copy_n(rbegin(a)+1, 3, std::inserter(b, std::begin(b)));
    auto it = find_if(a.begin(), a.end(), [&](int x){x%2});
    it = find_if_not(a.begin(), a.end(), [&](int x){x%2});
    auto cmp =  [](ListNode *a, ListNode *b){
        return a->val > b->val;
    };
    priority_queue<ListNode*, vector<ListNode*>, decltype(cmp)> pq(cmp);
    /**
    //查找序列 [first1, last1) 中最后一个子序列 [first2, last2)
    ForwardIterator find_end (ForwardIterator first1, ForwardIterator last1,
                              ForwardIterator first2, ForwardIterator last2);
    //查找序列 [first2, last2) 中，和 [first2, last2) 序列满足 pred 规则的最后一个子序列
    ForwardIterator find_end (ForwardIterator first1, ForwardIterator last1,
                              ForwardIterator first2, ForwardIterator last2,
                              BinaryPredicate pred);


  //在 [first, last] 中查找 count 个 val 第一次连续出现的位置
  ForwardIterator search_n (ForwardIterator first, ForwardIterator last,
                          Size count, const T& val);
  //在 [first, last] 中查找第一个序列，该序列和 count 个 val 满足 pred 匹配规则
  ForwardIterator search_n ( ForwardIterator first, ForwardIterator last,
                           Size count, const T& val, BinaryPredicate pred );


 BidirectionalIterator stable_partition (BidirectionalIterator first,
              BidirectionalIterator last,
              UnaryPredicate pred);
    **/


    for_each(a.be, a.ed, [](int x){cout << x <<endl;})
  }
};


// KMP
void getFail(char *s, int *f){
  f[0] = f[1] = 0;
  for(int i = 1; s[i]; ++i){
    int j = f[i];
    while(j && s[i] != s[j])  j = f[j];
    f[i+1] = s[i] == s[j] ? j+1 : 0;
  }
}

int match(char *s, char *t, int *f){
  int ans = 0;
  int m = strlen(s);
  int n = strlen(t);
  int j = 0;
  for(int i = 0; i < n; ++i){
    while(j && s[j] != t[i])  j = f[j];
    if(s[j] == t[i])  ++j;
    if(j == m)  ++ans;
  }
  return ans;
}

// inverse
void getInverse(int *inv){
  inv[1] = 1;
  for(int i = 2; i < n; ++i){
    inv[i] = (mod - mod/i) * inv[mod%i] % mod;
  }
}

// exgcd
void exgcd(int a, int b, int &d, int &x, int &y){
  if(!b){ d = a;  x = 1; y = 0; }
  else{ exgcd(b, a%b, d, y, x);  y -= x * (a/b); }
}


// dijkstra
namespace Dijkstra{
  struct Edge{
    int from, to, dist;
  };

  struct HeapNode{
    int d, u;

    bool operator < (const HeapNode &rhs) const{
      return d > rhs.d;
    }
  };

  struct Dijkstra {
    int n, m;
    std::vector<int> G[maxn];
    std::vector<Edge> edges;
    int d[maxn];
    bool done[maxn];
    int p[maxn];

    void dijkstra(int s){
      ms(d, INF);  d[s] = 0; ms(done, 0);
      priority_queue<HeapNode> pq;
      pq.push((HeapNode){0, s});

      while(!pq.empty()){
        HeapNode x = pq.top();  pq.pop();
        if(done[x.u])  continue;
        done[x.u] = true;
 
        for(auto &i: G[x.u]){
          Edge &e = edges[i];
          if(d[e.to] > d[x.u] + e.dist){
            d[e.to] = d[x.u] + e.dist;
            p[e.to] = i;
            pq.push((HeapNode){d[e.to], e.to});
          }
        }
      }
    }
  };
};


// binary match
namespace BinaryMatch{
  std::vector<int> G[maxn];
  bool vis[maxn];
  int match[maxn];

  bool dfs(int u){
    vis[u] = true;
    for(auto &v: G[u]){
      int w = match[w];
      if(w == -1 || !vis[w] && dfs(w)){
        match[w] = v;
        match[v] = w;
        return true;
      }
    }
    return false;
  }

  int solve(){
    int ans = 0;
    ms(match, -1);
    for(int i = 1; i <= n; ++i)  if(match[i] == -1){
      ms(vis, 0);
      if(dfs(i))  ++ans;
    }
    return ans;
  }
};


// max flow - dinic
namespace Dinic{
  struct Edge{
    int from, to, cap, flow;
  };

  struct Dinic{
    int n, m, s, t;
    std::vector<Edge> edges;
    std::vector<int> G[maxn];
    bool vis[maxn];
    int d[maxn];
    int cur[maxn];

    void add_edge(int from, int to, int cap){
      edges.pb((Edge){from, to, cap, 0});
      edges.pb((Edge){to, from, 0, 0});
      m =  edges.sz;
      G[from].pb(m - 2);
      G[to].pb(m - 1);  
    }

    bool bfs(){
      ms(vis, 0);  vis[s] = true;
      queue<int> q;  q.push(s);

      while(!q.empty()){
        int u = q.front();  q.pop();
        for(auto &v: G[u]){
          Edge &e = edges[v];
          if(!vis[e.to] && e.cap > e.flow){
            vis[e.to] = true;
            d[e.to] = d[u] + 1;
            q.push(e.to);
          }
        }
      }
      return vis[t];
    }


    int dfs(int u, int a){
      if(u == t || a == 0)  return a;
      int flow = 0, f;
      for(int &i = cur[u]; i < G[u].sz; ++i){
        Edge &e = edges[G[u][i]];
        if(d[e.to] == d[u] + 1 && (f = dfs(e.to, min(a, e.cap-e.flow))) > 0){
          flow += f;
          a -= f;
          edges[G[u][i]].flow += f;
          edges[G[u][i]^1].flow -= f;
          if(a == 0)  break;
        }
      }
      return flow;
    }

    int max_flow(int s, int t){
      this->s = s;
      this->t = t;
      int flow = 0;
      while(bfs()){ ms(cur, 0);  flow += dfs(s, INF); }
    }
  };
};


// min cost max flow - bellmanford
namespace MinCostMaxFlow{

  struct Edge{
    int from, to, cap, flow, cost;
  };

  struct MinCostMaxFlow{
    int n, m, s, t;

    std::vector<Edge> edges;
    std::vector<int> G[maxn];
    bool inq[maxn];
    int d[maxn];
    int p[maxn];
    int a[maxn];

    void add_edge(int from, int to, int cap, int cost){
      edges.pb((Edge){from ,to, cap, 0, cost});
      edges.pb((Edge){to, from, 0, 0, -cost});
      m = edges.sz;
      G[from].pb(m - 2);
      G[to].pb(m - 1);
    }

    bool bellmanford(int &flow, int &cost){
      ms(inq, 0);  ms(d, INF);  p[s] = 0;  a[s] = INF;
      queue<int> q;  q.push(s);  inq[s] = true;

      while(!q.empty()){
        int u = q.front();  q.pop();
        inq[u] = false;

        for(int &v: G[u]){
          Edge &e = edges[v];
          if(e.cap > e.flow && d[e.to] > d[u] + e.cost){
            p[e.to] = v;
            a[e.to] = min(a[u], e.cap - e.flow);
            d[e.to] = d[u] + e.cost;
            if(!inq[e.to])  q.push(e.to);
          }
        }
      }

      if(d[t] == INF)  return false;
      flow += a[t];
      cost += a[t] * a[t];

      int u = t;
      while(p[u]){
        edges[p[u]].flow += a[t];
        edges[p[u]^1].flow -= a[t];
        u = edges[p[u]].from;
      }
      return true;
    }

  };

};


// binary index tree
namespace FreeTree{
  int sum[maxn];

  void add(int x, int val){
    while(x <= n){
      sum[x] += val;
      x += lowbit(x);
    }
  }

  int query(int x){
    int ans = 0;
    while(x){
      ans += sum[x];
      x -= lowbit(x);
    }
    return ans;
  }
};


//  bellman ford
namespace BellmanFord{
  struct Edge{
    int from, to, dist;
  };

  struct BellmanFord{
    int n, m;
    std::vector<Edge> edges;
    std::vector<int> G[maxn];
    bool inq[maxn];
    int cnt[maxn];
    int d[maxn];

    bool bellmanford(int s){
      queue<int> q;  q.push(s);  inq[s] = true;
      ms(d, INF);  d[s] = 0;  ms(cnt, 0);
      while(!q.empty()){
        int u = q.front();  q.pop();
        inq[u] = false;

        for(auto &v: G[u]){
          Edge &e = edges[v];
          if(d[e.to] > d[u] + e.dist){
            d[e.to] = d[u] + e.dist;
            if(!inq[e.to]){
              q.push(e.to);
              inq[e.to] = true;
              if(++cnt[e.to] > n)  return true;
            }
          }
        }
      }
      return false;
    }
  };
};


namespace ToplologySort{
  struct TopologySort{
    std::vector<int> G[maxn];
    int in[maxn];

    void topoloty_sort(){
      queue<int> q;
      for(int i = 1; i <= n; ++i)
        if(in[i] == 0)  q.push(i);

      while(!q.empty()){
        int u = q.front();  q.pop();
        for(int &v: G[u]){
          --in[v];
          if(!in[v])  q.push(v);
        }
      }
    }
  };
};


namespace SegmentTree{
  int sum[maxn<<2];
  int minv[maxn<<2];
  int maxv[maxn<<2];
  int setv[maxn<<2];
  int addv[maxn<<2];

  void push_up(int rt){
    sum[rt] = sum[rt<<1] + sum[rt<<1|1];
    minv[rt] = min(minv[rt<<1], minv[rt<<1|1]);
    maxv[rt] = max(maxv[rt<<1], maxv[rt<<1|1]);
  }


  void push_down(int rt, int len){
    int l = rt<<1, r = rt<<1|1;
    if(setv[rt] != -1){
      minv[l] = minv[r] = maxv[l] = maxv[r] = setv[rt];
      setv[l] = setv[r] = setv[rt];
      sum[l] = (len - len/2) * setv[rt];
      sum[r] = len/2 * setv[rt];
      setv[rt] = -1;
      addv[l] = addv[r] = 0;
    }

    if(addv[rt]){
      minv[l] += addv[rt];  maxv[r] += addv[rt];
      maxv[l] += addv[rt];  maxv[r] += addv[rt];
      sum[l] += addv[rt] * (len - len/2);
      sum[r] +=  len / 2 * addv[rt];
      addv[l] += addv[rt];  addv[r] += addv[rt];
      addv[rt] = 0;
    }

  }

  void build(int l, int r, int rt){
    if(l == r){
      sum[rt] = minv[rt] = maxv[rt] = 1;
      return;
    }
    int m = l + r >> 1;
    build(lson);
    build(rson);
    pu(rt);
  }

  void update_set(int L, int R, int val, int l, int r, int rt){
    if(L <= l && r <= R){
      minv[rt] = maxv[rt] = val;
      sum[rt] = (r-l+1) * val;
      addv[rt] = 0;
      setv[rt] = val;
      return;
    }

    pd(rt, r-l+1);
    int m = l + r >> 1;
    if(L <= m)  update_set(L, R, val, lson);
    if(R > m)  update_set(L, R, val, rson);
    pu(rt);

  }

  void update_add(int L, int R, int val, int l, int r, int rt){
    if(L <= l && r <= R){
      maxv[rt] += val;
      minv[rt] += val;
      sum[rt] += (r-l+1) * val;
      addv[rt] += val;
    }
    pd(rt, r-l+1);
    int m = l + r >> 1;
    if(L <= m)  update_add(L, R, val, lson);
    if(R > m)  update_add(L, R, val, rson);
    pu(rt);
  }

  int query(int L, int R, int l, int r, int rt){
    if(L <= l && r <= R)  return sum[rt];
    pd(rt, r-l+1);
    int m = l + r >> 1;
    int ans = 0;
    if(L <= m)  ans = query(L, R, lson);
    if(R > m)  ans += query(L, R, rson);
    return ans;
  }
};

// tree center
namespace TreeCenter{
  std::vector<int> G[maxn];
  int num[maxn];
  int root = -1, mmax = INF;

  void dfs(int u, int fa){
    num[u] = 1;
    int tmp = 0;
    for(auto &v: G[u]){
      if(v == fa)  continue;
      dfs(v, u);
      num[u] += num[v];
      tmp = max(tmp, num[v]);
    }
    tmp = max(tmp, n - num[u]);
    if(tmp < mmax){
      mmax = tmp;
      root = u;
    }
  }
};


// Trie Tree
namespace Trie{
  const int maxnode = 1000;
  const int sigma = 26;
  struct Trie{
    int ch[maxnode][sigma];
    int val[maxnode];
    int index;

    void init(){
      ms(ch[0], 0);
      index = 1;
    }

    inline int idx(char ch){
      return ch - 'a';
    }

    void insert(char *s){
      int u = 0;
      for(int i = 0; s[i]; ++i){
        int c = idx(s[i]);
        if(!ch[u][c]){
          ms(ch[index], 0);
          val[index] = 0;
          ch[u][c] = index++;
        }
        u = ch[u][c];
      }
      val[u] = 1;
    }
  };

};



// 有一个不递减的序列，现在要把这些数分成若干个部分，每部分不能少于m个数。每部分的权值为所有数减去该部分最小的数的和。求最小的总权值。
namespace GradientDP{
LL dp[maxn], sum[maxn];
int a[maxn], q[maxn];
 
LL getUP(int i, int j){
  return dp[i] - sum[i] + (LL)i*a[i+1] - (dp[j] - sum[j] + (LL)j*a[j+1]);
}
 
LL getDOWN(int i, int j){
  return a[i+1] - a[j+1];
}
 
LL getDP(int i, int j){
  return dp[j] + sum[i] - sum[j] - (LL)(i-j)*a[j+1];
}
 
int main(){
  int T;  cin >> T;
  while(T--){
    scanf("%d %d", &n, &m);
    for(int i = 1; i <= n; ++i){
      scanf("%d", a+i);
      sum[i] = sum[i-1] + a[i];
    }
    int fro = 0, rear = 0;
    q[++rear] = m;
    ms(dp, 0);
    for(int i = m; i < 2*m; ++i)  dp[i] = sum[i] - i * a[1];
    for(int i = m * 2; i <= n; ++i){  // notice
      while(fro+1 < rear && getUP(q[fro+2], q[fro+1]) <= i*getDOWN(q[fro+2], q[fro+1]))  ++fro;
      dp[i] = getDP(i, q[fro+1]);
      int k = i - m + 1;
      while(fro+1 < rear && getUP(k, q[rear])*getDOWN(k, q[rear-1]) <= getUP(k, q[rear-1])*getDOWN(k, q[rear]))  --rear;
      q[++rear] = k;
    }
    printf("%I64d\n", dp[n]);
  }
  return 0;
};
};


namespace Gradient{
int q[maxn];
char s[maxn];
int sum[maxn];
 
bool judge(int i, int j, int k){
  return (LL)(sum[i]-sum[j])*(i-k) >= (LL)(sum[i]-sum[k])*(i-j);
}
 
int main(){
  int T;  cin >> T;
  while(T--){
    scanf("%d %d", &n, &m);
    scanf("%s", s+1);
    for(int i = 1; i <= n; ++i)  sum[i] = sum[i-1] + s[i] - '0';
    int fro = 0, rear = 0;
    int ansL = 1, ansR = m;
    double ans = 0.0;
    for(int i = m; i <= n; ++i){
      while(fro + 1 < rear && judge(i-m, q[rear-1], q[rear]))  --rear;
      q[++rear] = i - m;
      while(fro + 1 < rear && judge(i, q[fro+2], q[fro+1]))  ++fro;
      double c = (double)(sum[i]-sum[q[fro+1]])/(i-q[fro+1]);
      if(ans < c || ans == c && ansR - ansL + 1> i - q[fro+1]){
        ans = c;
        ansL = q[fro+1] + 1;  ansR = i;
      }
    }
    printf("%d %d\n", ansL, ansR);
  }
  return 0;
}
};



// LCA
namespace LCA{
struct Edge{
  int to, next;
};
Edge edge[maxn<<1];
int head[maxn], cnt;
 
void addEdge(int u, int v){
  edge[cnt].to = v;
  edge[cnt].next = head[u];
  head[u] = cnt++;
}
 
int a[maxn];
int dp[3][maxn];
int dep[maxn], p[20][maxn];
void dfs(int u, int fa, int d){
  dep[u] = d;
  p[0][u] = fa;
  for(int i = head[u]; ~i; i = edge[i].next){
    int v = edge[i].to;
    if(v == fa)  continue;
    dfs(v, u, d + 1);
  }
}
 
void init(){
  ms(p, -1);
  dfs(1, -1, 1);
  FOR(k, 0, 19)  for(int v = 1; v <= n; ++v){
    if(p[k][v] < 0)  p[k+1][v] = -1;
    else p[k+1][v] = p[k][p[k][v]];
  }
}
 
int LCA(int u, int v){
  if(dep[u] > dep[v])  swap(u, v);
  for(int k = 0; k < 20; ++k)
    if(dep[v] - dep[u] >> k & 1)  v = p[k][v];
  if(u == v)  return u;
  for(int k = 19; k >= 0; --k)
    if(p[k][u] != p[k][v]){
      u = p[k][u];
      v = p[k][v];
    }
  return p[0][u];
}
};




// AHO
namespace AHO{
char t[maxn];
char s[510][510];
const int maxnode = 510 * 510 + 10;
struct Aho{
  int ch[maxnode][26];
  int f[maxnode];
  int val[maxnode];
  int last[maxnode];
  int cnt[510];
  int sz;
 
  void init(){
    sz = 1;
    memset(ch[0], 0, sizeof ch[0]);
    memset(cnt, 0, sizeof cnt);
  }
 
  int idx(char c){ return c - 'a'; }
 
  void insert(char *s, int v){
    int u = 0;
    while(*s){
      int c = idx(*s);
      if(!ch[u][c]){
        memset(ch[sz], 0, sizeof ch[sz]);
        val[sz] = 0;
        ch[u][c] = sz++;
      }
      u = ch[u][c];
      ++s;
    }
    val[u] = v;
  }
 
  void getFail(){
    queue<int> q;
    f[0] = 0;
    for(int c = 0; c < 26; ++c){
      int u = ch[0][c];
      if(u){ f[u] = 0; q.push(u); last[u] = 0; }
    }
    while(!q.empty()){
      int r = q.front();  q.pop();
      for(int c = 0; c < 26; ++c){
        int u = ch[r][c];
        if(!u)  continue;
        q.push(u);
        int v = f[r];
 
        while(v && !ch[v][c]) v = f[v];
        f[u] = ch[v][c];
        last[u] = val[f[u]] ? f[u] : last[f[u]];
      }
    }
  }
 
  void find(char *s){
    int j = 0;
    while(*s){
      int c = idx(*s);
      while(j && !ch[j][c])  j = f[j];
      j = ch[j][c];
      if(val[j])  print(j);
      else if(last[j])  print(last[j]);
      ++s;
    }
  }
 
  void print_(int j){
    if(j){
      ++cnt[val[j]];
      print(last[j]);
    }
  }
 
};
};

// 树的直径的长度一定会是某个点的最长距离f[i]与次长距离g[i]之和。最后求出max{f[i]+g[i]}就可以了，用到方法1中的第一个dfs就行了
namespace TreeDiameter{
int f[maxn], g[maxn], longest[maxn];
vector<int> son[maxn], w[maxn];
int dfs(int root, int pre){
    int i, j;
    int est = 0, esti=-1, er=0;
    if(f[root]!=-1) return f[root];
    if(son[root].empty()) return f[root] = 0;
    for(i=0;i<son[root].size();i++){
        if(pre!=son[root][i]){
            if(dfs(son[root][i],root)+w[root][i]>est){
                est = f[son[root][i]]+w[root][i];
                esti = i;
            }
        }
    }
    longest[root] = esti;
    for(i=0;i<son[root].size();i++){
        if(pre!=son[root][i]){
            if(f[son[root][i]]+w[root][i]>er&&son[root][i]!=longest[root]){
                er = f[son[root][i]]+w[root][i];
            }
        }
    }
    g[root] = er;
    return f[root] = est;
}
 
void Init(int n){
    int i;
    for(i=0;i<=n;i++){
        f[i] = g[i] = longest[i] = -1;
        son[i].clear();
        w[i].clear();
    }
}
int main(){
    int i, j, k, n, m, ans;
    int x1, x2, l;
    char opt;
    while(~scanf("%d%d",&n,&m)){
        Init(n);
        for(i=0;i<m;i++){
            scanf("%d%d%d",&x1,&x2,&l);
            scanf(" %c",&opt);
            son[x1].push_back(x2);w[x1].push_back(l);
            son[x2].push_back(x1);w[x2].push_back(l);
        }
        for(i=1;i<=n;i++){
            if(f[i]==-1){
                f[i] = dfs(i,-1);
            }
        }
        ans = 0;
        for(i=1;i<=n;i++){
            ans = max(ans,f[i]+g[i]);
        }
        printf("%d\n",ans);
    }
    return 0;
}
};

// 主席树
namespace KthTree{
 
int a[maxn], b[maxn];
int ls[maxn*20], rs[maxn*20], tot, c[maxn*20];
int root[maxn];
 
void build(int l, int r, int &rt){
  rt = tot++;
  c[rt] = 0;
  if(l == r)  return ;
  int m = l+r >> 1;
  build(l, m, ls[rt]);
  build(m+1, r, rs[rt]);
}
 
void update(int o, int p, int v, int l, int r, int &rt){
  rt = tot++;
  c[rt] = c[o] + v;
  ls[rt] = ls[o];
  rs[rt] = rs[o];
  if(l == r)  return ;
  int m = l+r >> 1;
  if(p <= m)  update(ls[o], p, v, l, m, ls[rt]);
  else  update(rs[o], p, v, m+1, r, rs[rt]);
}
 
int query(int o, int k, int l, int r, int rt){
  if(l == r)  return l;
  int m = l+r >> 1;
  int res = c[ls[rt]] - c[ls[o]];
  if(res >= k)  return query(ls[o], k, l, m, ls[rt]);
  return query(rs[o], k-res, m+1, r, rs[rt]);
}
 
int main(){
  int T;  cin >> T;
  while(T--){
    scanf("%d %d", &n, &m);
    tot = 0;
    for(int i = 0; i < n; ++i){
      scanf("%d", a+i);
      b[i] = a[i];
    }
    sort(b, b + n);
    int sz = unique(b, b + n) - b;
    build(1, sz, root[0]);
    for(int i = 0; i < n; ++i){
      int j = lower_bound(b, b + sz, a[i]) - b + 1;
      update(root[i], j, 1, 1, sz, root[i+1]);
    }
    while(m--){
      int l, r, v;
      scanf("%d %d %d", &l, &r, &v);
      printf("%d\n", b[query(root[l-1], v, 1, sz, root[r])-1]);
    }
  }
  return 0;
}
};

// Tarjan 求树上任意两个点的之间的距离
namespace Tarjan{
vector<int> G[maxn], w[maxn], q[maxn], id[maxn];
int d[maxn], p[maxn], ans[205];
bool vis[maxn];
int Find(int x){  return x == p[x] ? x : p[x] = Find(p[x]); }
 
void Tarjan(int u){
    vis[u] = true;
    for(int i = 0; i < G[u].size(); ++i){
        int v = G[u][i];
        if(!vis[v]){
            d[v] = d[u] + w[u][i];
            Tarjan(v);
            p[v] = u;
        }
    }
 
    for(int i = 0; i < q[u].size(); ++i){
        int v = q[u][i];
        if(vis[v])  ans[id[u][i]] = d[u] + d[v] - 2*d[Find(v)];
    }
}
 
int main(){
    int T;;  cin >> T;
    while(T--){
        scanf("%d %d", &n, &m);
        for(int i = 1; i <= n; ++i) G[i].clear(), w[i].clear(), q[i].clear(), id[i].clear(), p[i] = i;
 
        int u, v, val;
        for(int i = 1; i < n; ++i){
            scanf("%d %d %d", &u, &v, &val);
            G[u].push_back(v);
            G[v].push_back(u);
            w[u].push_back(val);
            w[v].push_back(val);
        }
        for(int i = 0; i < m; ++i){
            scanf("%d %d", &u, &v);
            q[u].push_back(v);
            q[v].push_back(u);
            id[u].push_back(i);
            id[v].push_back(i);
        }
        memset(vis, false, sizeof vis);
        d[1] = 0;
        Tarjan(1);
 
        for(int i = 0; i < m; ++i)
            printf("%d\n", ans[i]);
    }
    return 0;
}
};

// 莫比乌斯函数
namespace Moblus{
bool vis[maxn];
int mu[maxn], prime[maxn];
 
void moblus(){
  mu[1] = 1;  int tot = 0;
  for(int i = 2; i <= n; ++i){
    if(!vis[i])  prime[tot++] = i, mu[i] = -1;
    for(int j = 0; j < tot; ++j){
      int t = i * prime[j];
      if(t > n)  break;
      vis[t] = 1;
      if(i % prime[j] == 0)  break;
      mu[t] = -mu[i];
    }
  }
}
};

// 单调栈
namespace SingleStack{
typedef pair<int, int> P;
#define fi first
#define se second

class Solution {
public:
    int largestRectangleArea(vector<int>& heights) {
        if(heights.size() == 0)  return 0;
        stack<P> st;
        int ans = 0;
        for(auto & x : heights){
            if(st.empty() || x > st.top().fi){
                st.push(P(x, 1));
            }
            else{
                int sum = 0;
                while(!st.empty() && x <= st.top().fi){
                    P p = st.top();  st.pop();
                    sum += p.se;
                    ans = max(ans, sum * p.fi);
                }
                st.push(P(x, sum + 1));
            }
        }
        int sum = 0;
        while(!st.empty()){
            P p = st.top();  st.pop();
            sum += p.se;
            ans = max(ans, sum * p.fi);
        }
        return ans;
    }
};
};


// 欧拉函数
namespace PhiTable{
int phi[maxn+5];
 
void phi_table(int n){
    memset(phi, 0, sizeof(phi));
    phi[1] = 1;
    for(int i = 2; i <= n; ++i)  if(!phi[i])
        for(int j = i; j <= n; j += i){
            if(!phi[j])  phi[j] = j;
            phi[j] = phi[j] / i * (i-1);
        }
}
};






























