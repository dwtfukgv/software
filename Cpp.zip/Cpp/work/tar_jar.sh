#!/bin/bash
#

tar -xvf trade.tar
sleep 5s
tar -xvf target.tar

WORKDIR=/opt/meituan/apps/tsp_service_productquery_trade_server/work
JARNAME=tsp_service_productquery_trade_server-1.0.0-SNAPSHOT.jar

if [ -d classes ]; then
    rm -rf classes
fi
mkdir classes
cd classes
/usr/local/java/bin/jar -xvf  $WORKDIR/$JARNAME