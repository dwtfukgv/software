#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
# 

from urllib import request, parse
from http.cookiejar import CookieJar, MozillaCookieJar

Header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36'
}


# 初始化
def Start_Request():
    cookiejar = MozillaCookieJar("cookie.txt")
    jier = request.HTTPCookieProcessor(cookiejar)
    opener = request.build_opener(jier)
    return opener, cookiejar


# 登录博客园
def Login_Adress(opener):
    data = {'input1': 'dwtfukgv', 'input2': 'apgypgy123***', 'remember': True}
    data = parse.urlencode(data).encode('utf-8')
    Login_Url = 'https://passport.cnblogs.com/user/signin'
    Reqs = request.Request(Login_Url, headers=Header, data=data)
    opener.open(Reqs)


# 测试获取博客园信息
def Test_Message(opener):
    Ceshi_Url = 'https://i.cnblogs.com/settings'
    Reqs_2 = request.Request(Ceshi_Url, headers=Header)
    Reqs_3 = opener.open(Reqs_2)
    with open('yunweijia.html', 'w', encoding='utf-8') as yunweijia:
        yunweijia.write(Reqs_3.read().decode('utf-8'))


if __name__ == '__main__':
    opener, cookiejar = Start_Request()
    Login_Adress(opener)
    Test_Message(opener)
    cookiejar.save(ignore_discard=True, ignore_expires=True)
    # ignore_discard：即使cookies将被丢弃也将它保存下来
    # ignore_expires：即使cookies已经过期，也将它保存并且文件已存在时将覆盖