#!/usr/bin/python3
# -*- coding: utf-8 -*-
import json

def line_to_json(in_file, out_file):
    poi_ids = []
    with open(in_file, "r") as in_f:
        lines = in_f.readlines()
        for i in range(1, len(lines)):
            poi_ids.append(int(lines[i]))
    print(len(poi_ids))
    with open(out_file, "w") as out_f:
        json.dump(poi_ids, out_f)


if __name__ == '__main__':
    line_to_json("../data/package_poi_ids-1083539449-1732177870441.txt", "../data/package_poi_ids.txt")
