#!/usr/bin/expect -f

log_user 0
##要在服务器上执行的命令，命令包含生成文件的步骤
set timeout -1

set mis qinhaiyu02
set password  ${}
set logname  com.sankuai.waimai.product.log

set logRetName  findproducterror
#set ip 10.186.153.200

spawn ssh $mis@jumper.sankuai.com
expect "*assword:*"
send "$password\r"
expect "*$mis@Jumper*"

foreach ip {10.46.94.104 10.46.94.104} {
    send "ssh $ip\r"
    expect {
        "*Creating directory '/home/$mis'.*" {
            
        }
        "Last login*" {
            
        }
    }
    ## 文件生成命令
    send "tac /var/sankuai/logs/$logname | grep -E 'metaJsonData=|handleTransaction error' > ~/$logRetName-$ip.txt \r"
    ##send "tac /var/sankuai/logs/$logname | grep -E 'Exception' > ~/$logRetName-$ip.txt \r"


    expect "\[$mis@*"

    send "wc -l ~/$logRetName-$ip.txt | awk -vz=0 '{print \$1||z}' \r"

    expect {
        ##找到了日志
        "1" {
            send "sftp $mis@jumper.sankuai.com \r"
            expect "*assword:*"
            send "$password\r"
            expect "sftp>"
            ##生成后文件上传指令
            send "put $logRetName-$ip.txt \r"
            expect "sftp>"
            send "exit \r"
            expect "\[$mis@*"
            send "rm ~/$logRetName-$ip.txt \r"
            expect "\[$mis@*"
        }
        "0" {     
        }
    }
    send "exit \r"

    expect "*$mis@Jumper*"
}
send "exit \r"

spawn sftp $mis@jumper.sankuai.com
expect "*assword:*"
send "$password\r"
expect "sftp>" 
send "get $logRetName-* \r"
expect "sftp>" 
#send "rm $logRetName-* \r"
#expect "sftp>" 
#send "exit \r"
interact
expect eof
