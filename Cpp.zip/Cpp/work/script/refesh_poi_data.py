#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import browsercookie
import requests
from datetime import datetime, timedelta
import json
import sys

cookies = browsercookie.chrome()
site_cookies = []
mws_cookies=''
for cookie in cookies:
    if '.mws.sankuai.com' == cookie.domain or 'rhino.sankuai.com' == cookie.domain:
        site_cookies.append(cookie)
        mws_cookies += cookie.name + '=' + cookie.value + ';'
        
headers = {
    "Authority": "das.mws.sankuai.com",
    "Accept": "application/json, text/plain, */*",
    "Accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Content-type": "application/json",
    "Cookie": mws_cookies
}

params = '{"paramTypes":["java.lang.String","java.lang.String"],"params":["invokeBeanMethod","["poiProductService","computePoiPackageProductShippingTime","["long"]",[8363361],null]"],"oneStepContext":{},"env":"prod","appkey":"com.sankuai.product.queryasync","host":"10.169.106.181","node":"set-hh-product-queryasync10 (5080)","isTest":false,"port":5080,"serviceName":"com.sankuai.tsp.product.thrift.service.TspProductAsyncThriftService","method":"debugApi(java.lang.String,java.lang.String):String","invokeType":"NEW"}'

def gen_info():
	data = {}
	data['paramTypes'] = ["java.lang.String","java.lang.String"]
	params = []
	params.append("invokeBeanMethod")
	params.append('["poiProductService","computePoiPackageProductShippingTime","["long"]",[8363361],null]')
	data['params'] = params
	data['env'] = 'prod'
	data['oneStepContext'] = {}
	data['foreverContext'] = {}
	data['appkey'] = 'com.sankuai.product.queryasync'
	data['host'] = '10.169.106.181'
	data['isTest'] = False
	data['port'] = str(5080)
	data['node'] = 'set-hh-product-queryasync10' + '(' + str(5080) + ')'
	data['serviceName'] = 'commonConsumer.dependency.thrift.DataBusEventServiceV2'
	data['method'] = 'handleDelete(java.util.Map,java.lang.String):String'
	data['invokeType'] = 'NEW'
	# print(json.dumps(data))
	return data


def refresh_poi_combine(poi_id):
    data = gen_info()
    response = requests.post(url='https://octo.mws.sankuai.com/api/v2/thriftcheck/genericInvoke', data=json.dumps(data), headers=headers)
    print(json.loads(response.content))

if __name__ == '__main__':
    refresh_poi_combine(8363361)



