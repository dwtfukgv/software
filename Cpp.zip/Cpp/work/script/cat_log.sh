#!/usr/bin/expect -f

set timeout -1
set mis_id qinpeifa

set retrieve_log com.sankuai.product.retrieve/com.sankuai.product.retrieve.log
set async_log com.sankuai.product.queryasync.log
set query_log com.sankuai.waimai.productquery.log

set log_name $async_log

# 0
set ip 10.22.31.250
spawn ssh $mis_id@jumper.sankuai.com
expect "*password:*"
send "apgypgy123****\r"
expect "*$mis_id@Jumper*"
send "ssh $ip\r"
expect {
	"*Creating directory '/home/$mis_id'.*" {
            
    }
    "Last login*" {
        
    }
}

# send "tailf /var/sankuai/logs/$log_name\r"
send "tailf /var/sankuai/logs/com.sankuai.product.queryasync.log | grep -iv stock | grep -v TspOpenCityService | grep -v CategoryLocalCache | grep -v HeartBeatResponse | grep -v Mafka | grep -v java.net.SocketTimeoutException | grep -v WmProductEveryDayStockMessageListener | grep -v TspOrderBizResourceMangerService \r"
interact
# expect eof