#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json


cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; moa_deviceId=578770F794795F8291CADC0A81F79E66; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; _ga=GA1.2.423863992.1692353451; _ga_9JGDVD6E56=GS1.2.1694587132.4.1.1694587150.0.0.0; al=ixfwnrkumpqtyoyexxzfvuwtbgkwcwdy; u=2008143655; uu=911473a0-55f1-11ee-998e-15626fb52c1f; cid=1; ai=1; _lx_utm=utm_source%3Dxm; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALCRGrfj4aHCPZaw7/uxf4iGxocOU8i3vbuw3E7H8Ri14bRfONPu3t+qEC9wMAAAAI4VLHi0THb2SPjbiGEQcr7sSUOE62TjLCLJLMifUBLPk+jRE; _lxsdk_s=18ad97a8403-ff9-938-87e%7C%7C144'
def check_spu_status(file_name):
    headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
    with open(file_name) as f:
        while True:
            line = f.readline();
            if line is None:
                break
            spu_id, spu_status = line.split(',')
            try:
                response = requests.get(f'https://waimai-openapi.apigw.st.sankuai.com/api/queryasync/rider_mall/spu?id={spu_id}', headers=headers)
                content = response.content
                data = json.loads(content)
                if int(data['status']) != int(spu_status):
                    print(spu_id)
            except Exception as e:
                print(spu_id, "error")
            
            # break

if __name__ == '__main__':
    check_spu_status("../data/rm_spu_status.txt")

