#!/usr/bin/env python3
# -*- coding: utf-8 -*- 


import csv


with open('./download.txt', 'r') as fin:
	distinct = set()
	res = []
	while True:
		s = fin.readline()
		if not s:
			break
		s = s.replace(" ", "").strip()
		distinct.add(s)
	
	data = []
	for s in distinct:
		res.append([s])
		data.append(int(s))
	print(res)
	print(len(distinct), len(res))
	print(tuple(data))


	with open('manghe.csv', 'w', encoding='utf-8', newline='') as f:
		writer = csv.writer(f)
		writer.writerows(res)