#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# File Name: 1.py
# Author: dwtfukgv
# Mail: dwtfukgv@163.com
# Created Time: 2020-05-18 10:50
# 
import json
import sys

ignore_field = set()

def init_igore(file_name):
	global ignore_field
	with open(file_name, 'r') as f:
		while True:
			line = f.readline()
			if not line:
				break
			ignore_field.add(line.strip())

def list_diff(a, b, pre):
	if len(a) != len(b):
		print(pre[:-1], "length is not equal.", len(a), len(b))
		return False
	for i in range(len(a)):
		k = i
		v, s_v = a[i], b[i]
		if type(v) != type(s_v):
			print("index", pre + str(i), "type is not same ", type(v), type(s_v))
			return False
		if type(v) == list:
			if not list_diff(v, s_v, pre + str(i) + "."):
				return False
		elif type(v) == dict:
			if not json_file_diff(v, s_v, pre + str(k) + "."):
				return False
		elif type(v) == str and v.replace(" ", "") != s_v.replace(" ", ""):
			print("field", pre + str(k), "is not equal. ori:", v, "new:", s_v)
			return False
		elif type(v) != str and v != s_v:
			print("field", pre + str(k), "is not equal. ori:", v, "new:", s_v)
			return False
	return True


def json_file_diff(a, b, pre=""):
	if len(a) != len(b):
		print(pre[:-1], "length is not equal.", len(a), len(b))
		if len(a) < len(b):
			a, b = b, a

		for k in a.keys():
			if k not in b.keys():
				print(pre + str(k))
		return False

	for k, v in a.items():
		if k not in b.keys():
			print("field", pre + str(k), "is not in second")
			return False
		if pre + str(k) in ignore_field:
			continue
		s_v = b[k]
		if type(v) != type(s_v):
			print("field", pre + str(k), "type is not same", type(v), type(s_v))
			return False
		if type(v) == list:
			if not list_diff(v, s_v, pre + str(k) + "."):
				return False
		elif type(v) == dict:
			if not json_file_diff(v, s_v, pre + str(k) + "."):
				return False
		elif type(v) == str and v.replace(" ", "") != s_v.replace(" ", ""):
			print("field", pre + str(k), "is not equal. ori:", v, "new:", s_v)
			return False
		elif type(v) != str and v != s_v:
			print("field", pre + str(k), "is not equal. ori:", v, "new:", s_v)
			return False

	return True

if '__main__' == __name__:
	init_igore('./exclude.in')
	file1, file2 = "./ori.json", "./new.json"
	if len(sys.argv) < 3:
		print("will use default file")
	else:
		file1, file2 = sys.argv[1], sys.argv[2]

	try :
		print(file1)
		print(file2)
		a, b = None, None
		with open(file1, 'r') as f:
			a = json.load(f)
		with open(file2, 'r') as f:
			b = json.load(f)
		if type(a) == dict and json_file_diff(a, b, "_.") or type(a) == list and list_diff(a, b, "_."):
			print("two json file is ideal")
		else:
			print("resolve json wrong")
	except Exception as e:
		print("resolve json fail")
		print(e)