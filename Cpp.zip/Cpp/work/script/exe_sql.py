#!/usr/bin/env python3
# -*- coding: utf-8 -*- 
# 

import requests
import json
import sys
import time

sys.path.append("./")
from gen_update_table import *


test_query_url = 'https://rds.mws-test.sankuai.com/api/v2/autosql/execute-dql'
test_update_url = 'https://rds.mws-test.sankuai.com/api/v2/autosql/execute-dml'
# prod_url = 'https://rds.mws.sankuai.com/api/v2/autosql/execute-dql'
url = None
cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _ga=GA1.2.826890099.1621563183; uu=cfb71b50-2b4e-11ec-bd2b-a5fd86896aec; cid=1; ai=1; al=izvbonixwdkusbroupwjcmemkghuujew; _lx_utm=utm_source=xm; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; ssoid=eAGFji1LBEEYgNlDZDHJJuNGb4M3887H-47Jc_WyH0GwyMzOTNQ_YPA0CSabgnDCguFEsRkMVhGMChoEQd3iL7CoiNn68PDwpMn40eCmlX_uvdRPHUg1M8BJmekcmTSRLJEXKLUHV6EpjHUIFph2ZvY2ydorwS1XYT1sKiRE1kMj0agegeFld65kXeLfbF7r_GPn9Oq5A_9m6WdnprVwff9499DZToqx0cWlcsOHLHutT5qL47fd4fug35zVzXl_YiTfujxoT_7K-0n693OYTAGRqzxaW3GQHEFHF7l3hpyNqCta41qQBK2BFPDVPBhlo-MmykJIZa2VCiAA405wKbz4Aj17YRI**eAEFwYEBwCAIA7CXKgXBc4aW_09Y0kbd8st-GlhWaKW9LoHY7icIT-QEbDNKUxOKr2hLfdYPLcwQyg; yun_portal_ssoid=eAGFji1LBEEYgNlDZDHJJuNGb4M3887H-47Jc_WyH0GwyMzOTNQ_YPA0CSabgnDCguFEsRkMVhGMChoEQd3iL7CoiNn68PDwpMn40eCmlX_uvdRPHUg1M8BJmekcmTSRLJEXKLUHV6EpjHUIFph2ZvY2ydorwS1XYT1sKiRE1kMj0agegeFld65kXeLfbF7r_GPn9Oq5A_9m6WdnprVwff9499DZToqx0cWlcsOHLHutT5qL47fd4fug35zVzXl_YiTfujxoT_7K-0n693OYTAGRqzxaW3GQHEFHF7l3hpyNqCta41qQBK2BFPDVPBhlo-MmykJIZa2VCiAA405wKbz4Aj17YRI**eAEFwYEBwCAIA7CXKgXBc4aW_09Y0kbd8st-GlhWaKW9LoHY7icIT-QEbDNKUxOKr2hLfdYPLcwQyg; logan_session_token=vfzdsm3so4e5jafre2fp; s_m_id_3299326472=AwMAAAA5AgAAAAEAAAE9AAAALA+l2tnldArVTWVgpm9VwCDYfSQCrVMYqyPG7jdwZG82o7Id6KRQe9KYTiygAAAAIz9w/5mlX5ReeTq2JbTt7yGzd/rAg+8tpxcY+8pJsODcYx06; _lxsdk_s=17db266123e-068-3c7-185||312'


class SqlUtils:
	def exe_sql(database_id, sql, is_update=False):
		url = test_update_url if is_update else test_query_url
		data = {'sql': sql, 'databaseId': database_id, 'clusterId': 12916}
		headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
		retry_time = 3
		while retry_time:
			try:
				response = requests.post(url=url, data=json.dumps(data), headers=headers)
				res = json.loads(response.content)
				print("success execute sql:", sql)
				return res
			except Exception as e:
				print(str(response))
				print(e)
				retry_time -= 1
				time.sleep(3)
		return {}


