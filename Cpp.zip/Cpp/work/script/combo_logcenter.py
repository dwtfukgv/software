#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import time
from datetime import datetime, timedelta


import browsercookie
import importlib.util,subprocess


cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; _ga=GA1.2.1205143981.1714111927; u=2008143655; _ga_YQ7GRE77BE=GS1.2.1715866477.1.0.1715866477.0.0.0; _ga_9JGDVD6E56=GS1.2.1716261165.3.1.1716261185.0.0.0; csrf=8azmkBWDntEcQCmZinGaBZMnjKJSXria; ssoid=eAGFkMsrRHEcxfuhSbPSrGR1FxZmyszvd-_397LCmGHpVcpGv2dKuYtLNhaGUiztKHmkLJRHWSg7SuNfYCmMlZ2FWXAla9tzTqfPOe2oY3f_viWoPz3WmyTMghSRxzoC2RdIYjxQjZmWDBTB0pioYCKJuRIAwg82US4_5fSEcfNumXLBOa5yCVzSqgglKQ8MlfGAIKlWYSxYP39Y-yI9KPy3WPwg9WdG3vc-bj7J6PXd5e0bWUWFbGZsvBxbl8s9Hx03Lg5eNk5e92uN06PGWa2zLVi52s73_Ia3UPsf2A4qEqq9jKhiJqSca0Utd9JH2ivPODEwQzghkkLIMQAcou4lp5fB2vQJcJjbCHzI0nVUcMu8txpjyacDaqKQKi-ZKQjgDKQllKQ2VcSK9KJV1FWK1eLCbFjEJWWMS5LehXjOzReHK5ObqDVJ4m_Ain0s**eAEFwQkBwDAIA0BLgVEeOekA_xJ6tz2SBm8WIBl6WenlDtUkR6V0jUt-kB3f6AM9axdSEv8DKuYRGQ**nXjP0GecwtjJWlUNBZSivBrdlFuGxCVzvL3qAfR9VXPJ9dn9s2ikhzw79AqbCApNiGFLsptlkidR6f2cl5wd7g**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE2Nzk3MjM5NzUy; sid=eAGFkMsrRHEcxfuhSbPSrGR1FxZmyszvd-_397LCmGHpVcpGv2dKuYtLNhaGUiztKHmkLJRHWSg7SuNfYCmMlZ2FWXAla9tzTqfPOe2oY3f_viWoPz3WmyTMghSRxzoC2RdIYjxQjZmWDBTB0pioYCKJuRIAwg82US4_5fSEcfNumXLBOa5yCVzSqgglKQ8MlfGAIKlWYSxYP39Y-yI9KPy3WPwg9WdG3vc-bj7J6PXd5e0bWUWFbGZsvBxbl8s9Hx03Lg5eNk5e92uN06PGWa2zLVi52s73_Ia3UPsf2A4qEqq9jKhiJqSca0Utd9JH2ivPODEwQzghkkLIMQAcou4lp5fB2vQJcJjbCHzI0nVUcMu8txpjyacDaqKQKi-ZKQjgDKQllKQ2VcSK9KJV1FWK1eLCbFjEJWWMS5LehXjOzReHK5ObqDVJ4m_Ain0s**eAEFwQkBwDAIA0BLgVEeOekA_xJ6tz2SBm8WIBl6WenlDtUkR6V0jUt-kB3f6AM9axdSEv8DKuYRGQ**nXjP0GecwtjJWlUNBZSivBrdlFuGxCVzvL3qAfR9VXPJ9dn9s2ikhzw79AqbCApNiGFLsptlkidR6f2cl5wd7g**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE2Nzk3MjM5NzUy; sessionid=k6zk1yvx5ihh953lsgczit8a5xbxsmdu; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALOA7jdlJCdmhA9bKrH5D59YR1/NSZEmzLb5A3mmFwesumahsRmC9UjTmLEgOAAAAI5XMXpEbxzcpfaa3UclXA/mGc2Ugh9UlLqRtvLnOzsIaUXbj; _lxsdk_s=18fa92fcfba-6df-fe6-5fb%7C%7C756; csrftoken=f8dB9CtosObrSmy3JLow6vMakP5EdcUV'

headers = {
    "Authorization": "Token cHJvZHVjdC1wbGF0Zm9ybTowOjE2NTQ0NzhiNzM5YzhmMjMwOTEyZmU2Y2Y4YzhjMGMw",
    "Accept": "application/json, text/plain, */*",
    # "Accept-Encoding": "gzip, deflate",
    # "Accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    # "Referrer Policy": "strict-origin-when-cross-origin",
    # "Content-type": "application/json;charset=UTF-8",
    # "X-Csrftoken": "f8dB9CtosObrSmy3JLow6vMakP5EdcUV",
    # "Host": "logcenter.data.sankuai.com",
    # "Origin": "http://logcenter.data.sankuai.com",
    # "Connection": "keep-alive",
    # "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    # "Referer": "http://logcenter.data.sankuai.com/search/waimai_productquery_bizlog_customize/query",
    "Cookie": cookie
}


cmd = "curl 'http://logcenter.data.sankuai.com/logcenter/search' \
  -H 'Accept: application/json, text/plain, */*' \
  -H 'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8' \
  -H 'Connection: keep-alive' \
  -H 'Content-Type: application/json;charset=UTF-8' \
  -H 'Cookie: _lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; _ga=GA1.2.1205143981.1714111927; u=2008143655; _ga_YQ7GRE77BE=GS1.2.1715866477.1.0.1715866477.0.0.0; _ga_9JGDVD6E56=GS1.2.1716261165.3.1.1716261185.0.0.0; csrf=8azmkBWDntEcQCmZinGaBZMnjKJSXria; ssoid=eAGFkMsrRHEcxfuhSbPSrGR1FxZmyszvd-_397LCmGHpVcpGv2dKuYtLNhaGUiztKHmkLJRHWSg7SuNfYCmMlZ2FWXAla9tzTqfPOe2oY3f_viWoPz3WmyTMghSRxzoC2RdIYjxQjZmWDBTB0pioYCKJuRIAwg82US4_5fSEcfNumXLBOa5yCVzSqgglKQ8MlfGAIKlWYSxYP39Y-yI9KPy3WPwg9WdG3vc-bj7J6PXd5e0bWUWFbGZsvBxbl8s9Hx03Lg5eNk5e92uN06PGWa2zLVi52s73_Ia3UPsf2A4qEqq9jKhiJqSca0Utd9JH2ivPODEwQzghkkLIMQAcou4lp5fB2vQJcJjbCHzI0nVUcMu8txpjyacDaqKQKi-ZKQjgDKQllKQ2VcSK9KJV1FWK1eLCbFjEJWWMS5LehXjOzReHK5ObqDVJ4m_Ain0s**eAEFwQkBwDAIA0BLgVEeOekA_xJ6tz2SBm8WIBl6WenlDtUkR6V0jUt-kB3f6AM9axdSEv8DKuYRGQ**nXjP0GecwtjJWlUNBZSivBrdlFuGxCVzvL3qAfR9VXPJ9dn9s2ikhzw79AqbCApNiGFLsptlkidR6f2cl5wd7g**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE2Nzk3MjM5NzUy; sid=eAGFkMsrRHEcxfuhSbPSrGR1FxZmyszvd-_397LCmGHpVcpGv2dKuYtLNhaGUiztKHmkLJRHWSg7SuNfYCmMlZ2FWXAla9tzTqfPOe2oY3f_viWoPz3WmyTMghSRxzoC2RdIYjxQjZmWDBTB0pioYCKJuRIAwg82US4_5fSEcfNumXLBOa5yCVzSqgglKQ8MlfGAIKlWYSxYP39Y-yI9KPy3WPwg9WdG3vc-bj7J6PXd5e0bWUWFbGZsvBxbl8s9Hx03Lg5eNk5e92uN06PGWa2zLVi52s73_Ia3UPsf2A4qEqq9jKhiJqSca0Utd9JH2ivPODEwQzghkkLIMQAcou4lp5fB2vQJcJjbCHzI0nVUcMu8txpjyacDaqKQKi-ZKQjgDKQllKQ2VcSK9KJV1FWK1eLCbFjEJWWMS5LehXjOzReHK5ObqDVJ4m_Ain0s**eAEFwQkBwDAIA0BLgVEeOekA_xJ6tz2SBm8WIBl6WenlDtUkR6V0jUt-kB3f6AM9axdSEv8DKuYRGQ**nXjP0GecwtjJWlUNBZSivBrdlFuGxCVzvL3qAfR9VXPJ9dn9s2ikhzw79AqbCApNiGFLsptlkidR6f2cl5wd7g**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE2Nzk3MjM5NzUy; sessionid=k6zk1yvx5ihh953lsgczit8a5xbxsmdu; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALOA7jdlJCdmhA9bKrH5D59YR1/NSZEmzLb5A3mmFwesumahsRmC9UjTmLEgOAAAAI5XMXpEbxzcpfaa3UclXA/mGc2Ugh9UlLqRtvLnOzsIaUXbj; csrftoken=1lT3dsC2sEsCh2IdeXiYSZi6wzTOkJqC; _lxsdk_s=18faa1850d7-74c-b7-108%7C%7C5' \
  -H 'Origin: http://logcenter.data.sankuai.com' \
  -H 'Referer: http://logcenter.data.sankuai.com/search/com.sankuai.data.rt.logcenter.esp5roxy/query/%7B%22start_time%22:%22now-7d%22,%22end_time%22:%22now%22,%22keyword%22:%22index:log.com.sankuai.data.rt.logcenter.esp5roxy_all%20AND%20type:start%20AND%20token:false%22,%22model%22:%22quick%22,%22from%22:0,%22sortInfo%22:%5B%7B%22es_datetime%22:%22desc%22%7D%5D%7D' \
  -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36' \
  -H 'X-CSRFToken: 1lT3dsC2sEsCh2IdeXiYSZi6wzTOkJqC' \
--data-raw $'{\"queryInfo\":{\"index_name\":\"log.waimai_productquery_bizlog_customize_all\",\"log_name\":\"waimai_productquery_bizlog_customize\",\"query\":{\"bool\":{\"filter\":[{\"range\":{\"es_datetime\":{\"gte\":\"2024-05-24 18:30:13.000\",\"lte\":\"2024-05-24 18:31:13.000\"}}}],\"must\":[{\"query_string\":{\"query\":\"biz_log_id: \\\\\"combo_group_empty\\\\\"\"}}]}},\"highlight\":{\"type\":\"plain\",\"fields\":{\"*\":{}},\"fragment_size\":2147483647,\"require_field_match\":false,\"pre_tags\":[\"<span class=\\'hl-search\\'>\"],\"post_tags\":[\"</span>\"]},\"from\":0,\"size\":500,\"sort\":[{\"es_datetime\":\"desc\"}],\"aggs\":{\"count\":{\"date_histogram\":{\"field\":\"es_timestamp\",\"interval\":\"1m\",\"format\":\"HH:mm:ss\",\"time_zone\":\"+08:00\"}}},\"interval\":\"分钟\"},\"download\":false}' \
"



# param = '{"queryInfo":{"index_name":"log.waimai_productquery_bizlog_customize_all","log_name":"waimai_productquery_bizlog_customize","query":{"bool":{"filter":[{"range":{"es_datetime":{"gte":"2024-05-24 17:54:03.000","lte":"2024-05-24 18:09:03.999"}}}],"must":[{"query_string":{"query":"biz_log_id: \"combo_group_empty\""}}]}},"highlight":{"type":"plain","fields":{"*":{}},"fragment_size":2147483647,"require_field_match":false,"pre_tags":["<span class='hl-search'>"],"post_tags":["</span>"]},"from":0,"size":50,"sort":[{"es_datetime":"desc"}],"aggs":{"count":{"date_histogram":{"field":"es_timestamp","interval":"1m","format":"HH:mm:ss","time_zone":"+08:00"}}},"interval":"分钟"},"download":false}'
param = "{\"queryInfo\":{\"index_name\":\"log.waimai_productquery_bizlog_customize_all\",\"log_name\":\"waimai_productquery_bizlog_customize\",\"query\":{\"bool\":{\"filter\":[{\"range\":{\"es_datetime\":{\"gte\":\"2024-05-24 17:54:03.000\",\"lte\":\"2024-05-24 18:09:03.999\"}}}],\"must\":[{\"query_string\":{\"query\":\"biz_log_id: \\\"combo_group_empty\\\"\"}}]}},\"highlight\":{\"type\":\"plain\",\"fields\":{\"*\":{}},\"fragment_size\":2147483647,\"require_field_match\":false,\"pre_tags\":[\"<span class='hl-search'>\"],\"post_tags\":[\"</span>\"]},\"from\":0,\"size\":5,\"sort\":[{\"es_datetime\":\"desc\"}],\"aggs\":{\"count\":{\"date_histogram\":{\"field\":\"es_timestamp\",\"interval\":\"1m\",\"format\":\"HH:mm:ss\",\"time_zone\":\"+08:00\"}}},\"interval\":\"mm\"},\"download\":false}"


def get_logs(start_time, end_time):
    data = json.loads(param)
    data['queryInfo']['query']['bool']['filter'][0]['range']['es_datetime']['gte'] = start_time
    data['queryInfo']['query']['bool']['filter'][0]['range']['es_datetime']['lte'] = end_time
    response = requests.post("http://es.data.sankuai.com/log.waimai_productquery_bizlog_customize_all/_search", data=param, headers=headers)
    response = requests.post("http://logcenter.data.sankuai.com/logcenter/search", data=param, headers=headers)
    res = response.content
    print(res)
    # if res['error_code'] == 0:
    #     for row in res['data']['rows']:
    #         print(row['spu_id'])


def handle_log(cmd, f):
    resp = subprocess.check_output(cmd, shell=True)
    res = json.loads(resp)
    if res['error_code'] == 0:
        for row in res['data']['rows']:
            f.write(row['spu_id'])

def format(date):
    return "{:%Y-%m-%d %H:%M:%S.000}".format(date)

if __name__ == '__main__':
    date = datetime(2024, 5, 21, 0, 0, 0)
    print(format(date))
    with open('../data/combo_spu_id.txt', 'w') as f:
        for i in (1, 2, 3):
            start_time = format(date)
            date = date + timedelta(seconds=10)
            end_time = format(date)
            new_cmd = cmd.replace("2024-05-24 18:30:13.000", start_time).replace("2024-05-24 18:31:13.000", end_time)
            print(new_cmd)
            handle_log(cmd, f)
