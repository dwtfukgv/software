#!/bin/bash

#在远程机器上执行部署的jar包

set -e

WORKDIR=/opt/meituan/apps/waimai_service_productquery_server/work
JARNAME=waimai_service_productquery_server-1.0.0-SNAPSHOT.jar
LOGFILE=waimai_service_productquery_server.boot.log.`date "+%Y%m%d"`
source $WORKDIR/deploy.conf

echo "#开始部署#"
HOST_NAME=`hostname`
echo $HOST_NAME
HOST_IP=`hostname -i | awk -F ' ' '{if(NF==1) print $1;else print $2 end}'`
cd $WORKDIR
if [ -f $JARNAME ]; then
    if [ -d classes ]; then
        rm -rf classes
    fi
    mkdir classes
    cd classes
    /usr/local/java8/bin/jar -xvf  $WORKDIR/$JARNAME
fi
VM_PARAM=''
if [ $ENVIRONMENT == "production" ]
then
#	VM_PARAM='-server -Xmx6g -Xms6g -XX:SurvivorRatio=8 -XX:NewRatio=2 -XX:MetaspaceSize=500m -XX:MaxMetaspaceSize=500m -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintCommandLineFlags -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:ParallelCMSThreads=4 -XX:+CMSClassUnloadingEnabled -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=1 -XX:CMSInitiatingOccupancyFraction=50 -XX:-UseAdaptiveSizePolicy -XX:+PrintHeapAtGC -XX:+ParallelRefProcEnabled -Xdebug -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=8444'
	VM_PARAM='-server -Xmx12g -Xms12g -XX:SurvivorRatio=8 -XX:MaxDirectMemorySize=256m -XX:NewRatio=2 -XX:MetaspaceSize=500m -XX:MaxMetaspaceSize=500m -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintCommandLineFlags -Xdebug -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:8444'
else
	VM_PARAM=''
	if [ ! -d $WORKDIR/conf/ ]; then
		mkdir $WORKDIR/conf/
	fi
	VM_PARAM='-XX:MetaspaceSize=700m -XX:MaxMetaspaceSize=700m -XX:MaxDirectMemorySize=256m -Xdebug -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:8444'
fi
exec /usr/local/java8/bin/java $VM_PARAM -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/sankuai/logs/waimai_service_productquery_server.heaperr.log.`date "+%Y%m%d%H%M%S"` -Denvironment=$ENVIRONMENT -Xloggc:/var/sankuai/logs/waimai_service_productquery_server.gc.log.`date "+%Y%m%d%H%M%S"` -Dapp.key=com.sankuai.waimai.productquery -Dapp.host=$HOST_NAME -Dapp.ip=$HOST_IP -Dapp.port=9000 -Dfile.encoding=utf8 -Dworkdir=$WORKDIR -cp $WORKDIR/classes:`find $WORKDIR/lib -name "*.jar" -printf "%p:"` com.sankuai.meituan.waimai.productquery.boot.Boot >> /var/sankuai/logs/$LOGFILE 2>&1
#disown
echo "#结束部署#"
