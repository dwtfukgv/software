#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import requests
import json

cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _ga=GA1.2.826890099.1621563183; s_u_745896="fFRke2aoZ6Ya61iFqEwFiA=="; u=2008143655; s_m_id_3299326472="AwMAAAA5AgAAAAEAAAE9AAAALATAU6bD2Y2IaH9ZCqq2mpa3vMsObIj7nog8SOLIGcdiLDq4jUweWCeJ1zuIAAAAI159A4soaDniZJblTsFwKrzSlxfivTZBp03H88UdKPEiqTQ+"; com.sankuai.waimai.c.admin_ssoid=eAHjYBSYu-Akk8KehweundM3kkrOz9UrTszLLk3M1CtPzMwFUsl6iSm5mXlWCsZmFuYGJikm5mmppiZGyYkWRibGWhamiRaWKSlJKYnGTlcYhTTDU5OCk1PzUmtMzS3MzQ3czC1NzC1N3SyMLA2dHV2cDRwtDIFirmZmCh-aT769pK_BaETQYAuQEx2YPB5-frLmnH7A2t-Llx7Wb2LU4mILDHLOT0kVEnq6ZPmLjQufda5-vqDxxbolL9Y3SrAoNOyYqakBUTyJkQPmsFmMeinJSUAPGKQmGZkapySZGJiYpVqmpZoZmJqbmSUaGRjHG5oZG1maGxqYGhtbWkYpmJsZpKWZmBmaJmmZmyQZWSSmmZimWloYWySamJhZpqUBAJocbTs**eAEFwQcBACAIBMBK6DMkDrN_BO8Ojy1y5YBdn3qRDr8Q64TlkGZM7HX27uonFnQxAj1w1H44DhGW; _lxsdk_s=17ce576737e-e88-785-e87||64'
url = "https://cadmin.sankuai.com/diagnosticate/search"
file_name = "/Users/dwtfukgv/Downloads/elephant/sold_time";

def exe_request(data):
	headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
	response = requests.post(url=url, data=data, headers=headers)
	content = json.loads(response.content)
	print(content)
	return (int)(content['code']) == 0

with open(file_name, "r") as f:
	while True:
		line = f.readline()
		if not line:
			break
		traceId = line.strip().split(" ")[0].split("=")[1]
		print(file_name, traceId)
		if exe_request({"traceid": traceId, "startTime": '', "endTime": ''}):
			print(traceId)
			break
