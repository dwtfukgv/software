#!/usr/bin/env python
# -*- coding: utf-8 -*-
#

# /opt/meituan/search/bs/data/invt_data/tspproductares

import sys

def bytes_to_long(buf):
	ans = 0
	for i in range(8):
		ans |= ord(buf[i])<<i*8
	return str(ans)


def resolve_idx(in_path, out_path):
	with open(in_path, "rb") as in_f:
		with open(out_path, "a+") as out_f:
			while True:
				data = in_f.read(8)
				if data == b"" or data is None:
					break
				spu_id = bytes_to_long(data)
				out_f.write(spu_id)
				out_f.write("\n")
				# print spu_id
				in_f.read(12)

if __name__ == '__main__':
	out_path = "./attr_" + sys.argv[1] + ".txt"
	
	with open(out_path, "w") as f:
		pass

	# try:
	# 	in_path = "/Users/dwtfukgv/Downloads/jumper/attr.idx"
	# 	resolve_idx(in_path, out_path)
	# 	print("file: " + in_path + " done")
	# except Exception as e:
	# 	print e
	# 	raw_input()

	for i in range(1, 5):
		try:
			in_path = "./attr_" + str(i) + ".idx"
			resolve_idx(in_path, out_path)
			print("file: " + in_path + " done")
		except Exception as e:
			print e
			raw_input()
