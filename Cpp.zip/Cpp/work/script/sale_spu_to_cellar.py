#!/usr/bin/python3
# -*- coding: utf-8 -*-

import json
import requests

PREFIX = "waimai_c_cbase_product_spu_stat_"

def store_sale_to_qa_cellar(spu_id):
	data = {}
	value = {}
	sale_num = spu_id % 100
	value['spu_30days_filter_risk_sales'] = sale_num
	value['spu_30days_sales'] = sale_num
	value['spu_quarter_sales'] = sale_num
	value['spu_total_sales'] = sale_num
	data['dsClusterId'] = 154
	data['area'] = 538  # 202 tc 538 rm
	data['requestType'] = 'put'
	data['reviewers'] = 'songbin04'
	data['key'] = PREFIX + str(spu_id)
	data['pkey'] = PREFIX + str(spu_id)
	data['value'] = json.dumps(value)
	data['expireType'] = 'never'
	data['expireTime'] = 0
	url = 'https://cellar.mws-test.sankuai.com/api/v1/operation/client/request'
	cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _ga=GA1.2.826890099.1621563183; uu=cfb71b50-2b4e-11ec-bd2b-a5fd86896aec; cid=1; ai=1; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; _lxsdk=qinpeifa; moa_deviceId=578770F794795F8291CADC0A81F79E66; WEBDFPID=752133wuv8665uw216z56vuvu55z2u9881393z12z0z979588y9y3wuw-1990508950010-1675148949678AQIMKME75613c134b6a252faa6802015be905511114; ssoid=eAGFjq9LBEEYhhmRYzHJJuPGuw2y38y3M99n8lw9jP4IgkVmd2ei_gMG75InWmyKwgknBkERi8FosYug_XTzJaMrYra-vM_DE4jp88HzRHT5fnjWBxnohCVQynMRgEbjUSWkFRbW5K6E2KD3zpsECRdeRNjacPl64bbdbmrImKRjGA2nHZIMWXsxS9oE9bakdfT29Xp_BE0h_xXTT9B8Y_mpGo_3YWV08DjoQU_EU43VtWyndGE4Gl5Vdxcf_evPQbe6GVa33ZnJaO_hpNX8PR-L4C_sVMwWVmoGKhSBZQaQ1uZI0iOxl6pMt0ATSiVBgZa8GTnFyrKWmMeApS1tTfhUG5cXvobMN9WTY2c**eAEFwYEBwCAIA7CXpIDScyyT_09Ykhgwa8tCqxWEDVJnvFrPdOhvB9WjwpJHx73chGd8KfwwGRFV**pusJRILiQHCeS8DycVypK3_N4s0jB-OA9jjnRBtKkD1BwxtIQdzdaUjTNG8MDTQFE6BHEHkgOAjxCwxFQsaZpQ**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjg2MTAyMDI3NTU3; yun_portal_ssoid=eAGFjq9LBEEYhhmRYzHJJuPGuw2y38y3M99n8lw9jP4IgkVmd2ei_gMG75InWmyKwgknBkERi8FosYug_XTzJaMrYra-vM_DE4jp88HzRHT5fnjWBxnohCVQynMRgEbjUSWkFRbW5K6E2KD3zpsECRdeRNjacPl64bbdbmrImKRjGA2nHZIMWXsxS9oE9bakdfT29Xp_BE0h_xXTT9B8Y_mpGo_3YWV08DjoQU_EU43VtWyndGE4Gl5Vdxcf_evPQbe6GVa33ZnJaO_hpNX8PR-L4C_sVMwWVmoGKhSBZQaQ1uZI0iOxl6pMt0ATSiVBgZa8GTnFyrKWmMeApS1tTfhUG5cXvobMN9WTY2c**eAEFwYEBwCAIA7CXpIDScyyT_09Ykhgwa8tCqxWEDVJnvFrPdOhvB9WjwpJHx73chGd8KfwwGRFV**pusJRILiQHCeS8DycVypK3_N4s0jB-OA9jjnRBtKkD1BwxtIQdzdaUjTNG8MDTQFE6BHEHkgOAjxCwxFQsaZpQ**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjg2MTAyMDI3NTU3; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALIxznFXbn4dkd8hjVQRntKUiJbGh6bpDmD44h3jZXMigl++P8FuelJGE1zy3AAAAI5xEmf1I86mo4/8znMbE73KbMt7Pz9jUPszJRAsDoNE5cK96; _lx_utm=utm_source%3Dxm; com.sankuai.cloudfe.cellar_strategy=; com.sankuai.cloudfe.cellar_random=; logan_session_token=gi77vo6b0u5g9hxnfogw; _lxsdk_s=1888f4aed1b-0dd-de6-dc0%7C%7C866'
	headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded'}
	response = requests.post(url=url, data=data, headers=headers)
	print(str(spu_id) + ": " + str(response.content))

if __name__ == '__main__':
	store_sale_to_qa_cellar(2201646604)