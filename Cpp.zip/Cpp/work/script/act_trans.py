#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import requests
import time
import csv

cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _ga=GA1.2.826890099.1621563183; uu=cfb71b50-2b4e-11ec-bd2b-a5fd86896aec; cid=1; ai=1; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; _lxsdk=qinpeifa; ssoid=eAGFjq9LBEEYhplDZDHJJuPGuw3uzncz831j8lw9jP4IgkVmZmej_gMGT5PVpiCecGAQFMFgEawWLaeCUdRdsFpsrojZ9vLyPi9PwMYP-7eN6Ojr4aVMIFCpBk5ST0WYCl2QIcrbKFQO1qGOtbEIBlJl9cyQha0Vb5edX_ebEgkx7aIWqGWXQPOsM5ulHeJ1N6dUdP9afn4kTQb_HtOP0HRj_nq4c1kmCzePz3dPyTaLx0YXl7KN3Ifh2-Ckujh-3z0t-73qbFCd9yZGoq2r_Vbzd7zHgj-xAzYJRNblaIzjIDiCKmzBc6vJmgKVozWu2iRAKSAJfDUiMEI7LQliKbjxdTam5j0n48DTNzdxZvk**eAENyckBgAAIA7CZUKBlHM79R9B8sxRdQzhhy8R1K9IntiZv6RbyDPzYMlr2ViCE1EXo3x9HThGe; yun_portal_ssoid=eAGFjq9LBEEYhplDZDHJJuPGuw3uzncz831j8lw9jP4IgkVmZmej_gMGT5PVpiCecGAQFMFgEawWLaeCUdRdsFpsrojZ9vLyPi9PwMYP-7eN6Ojr4aVMIFCpBk5ST0WYCl2QIcrbKFQO1qGOtbEIBlJl9cyQha0Vb5edX_ebEgkx7aIWqGWXQPOsM5ulHeJ1N6dUdP9afn4kTQb_HtOP0HRj_nq4c1kmCzePz3dPyTaLx0YXl7KN3Ifh2-Ckujh-3z0t-73qbFCd9yZGoq2r_Vbzd7zHgj-xAzYJRNblaIzjIDiCKmzBc6vJmgKVozWu2iRAKSAJfDUiMEI7LQliKbjxdTam5j0n48DTNzdxZvk**eAENyckBgAAIA7CZUKBlHM79R9B8sxRdQzhhy8R1K9IntiZv6RbyDPzYMlr2ViCE1EXo3x9HThGe; _lx_utm=utm_source=xm; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALPg/ik4VuECePmga2VrKwGWZzr2Mrh4P4tpxjW+rgYv3pryaBk8Q25PDCjN9AAAAI01MdA86CVYX/Q2/pjckHP9i8aFxCRY4ygabS/Y94/HlQQow; _lxsdk_s=17e7b7d7b5e-fb1-d3a-717||221; logan_session_token=etwp5penv3eh2fj3zymt'

def send_mq(message):
	url = 'https://mafka.mws-test.sankuai.com/mafka/restful/message/send'
	headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded'}
	data = {}
	data['topicId'] = 202179
	data['messages'] = message
	data['swimlane'] = 'qinpeifa-ttkic'
	print(json.dumps(data))
	response = requests.post(url=url, data=data, headers=headers)
	return response.content


def blade_to_act_mq_msg(file_name='../data/act_db_data.data', out_file='../data/act_db_data.out'):
	data = {}
	template = {"bizType":0,"itemIds":[],"templateIdList":[20],"type":2,"wmPoiId":601810}

	with open(file_name, 'r') as f:
		while True:
			line = f.readline()
			if not line:
				break
			poi_id, sku_id = line.split()
			if poi_id not in data.keys():
				data[poi_id] = []
			data[poi_id].append(sku_id)
	
	time_interval = 1
	cnt = 1
	with open(out_file, 'w') as f:
		for k, v in data.items():
			template['itemIds'] = v
			template['wmPoiId'] = k
			response = send_mq(json.dumps(template))
			res = json.loads(response)
			while res['code'] != 0:
				time.sleep(time_interval)
				response = send_mq(json.dumps(template))
				res = json.loads(response)
				print("fail: " + str(cnt))
			print("success: " + str(cnt))
			cnt += 1
			time.sleep(time_interval)
			# f.write(json.dumps(template))
			# f.write("\n")


POI_ACT_TYPE = ("DISCOUNT_FOOD", "DISCOUNT_BY_INDEX_FOOD", "ITEM_COLLECTION_FULL_DISCOUNT", "BUY_DONATION", "PLUS_DISCOUNT", "SG_DISCOUNT_BY_N_INDEX_FOOD", "FIXED_GROUP_PRICE", "WM_GROUP_PURCHASING", "SG_EXPLOSIVE_DISCOUNT_FOOD")
PRICE_ACT_TYPE = ("DISCOUNT_FOOD", "SG_EXPLOSIVE_DISCOUNT_FOOD", "NEW_USER_DISCOUNT_FOOD")

EXCLUDE_SKU_IDS = (0, )

def compute_time(period):
	hour, minute = period.split(":")
	return int(hour), int(minute)

def compute_act_price(act_info, timestamp):
	if not act_info:
		return None

	localtime = time.localtime(timestamp)
	act_price = None
	priority = -1
	for act in act_info:
		wm_user_type = act['wmUserType']
		poi_user_type = act['poiUserType']
		if wm_user_type not in (0, 2) or poi_user_type not in(0, 2):
			continue
		stock = act['activityStock']
		if stock == 0:
			continue
		start_time = act['startTime']
		end_time = act['endTime']
		if timestamp > end_time or timestamp < start_time:
			continue

		if 'week' in act.keys() and str(localtime.tm_wday + 1) not in act['week']:
			continue

		if 'period' in act.keys():
			periods = json.loads(act['period'])
			effect = False
			hour, minute = localtime.tm_hour, localtime.tm_min
			for period in periods:
				# print("period: " + str(period))
				start, end = period.split("-")
				# print("start: " + start + ", end: " + end)
				_hour, _minute = compute_time(start)
				if hour < _hour or hour == _hour and minute < _minute:
					continue

				_hour, _end = compute_time(end)
				if hour > _hour or hour == _hour and minute > _minute:
					continue
				effect = True
				break
			if not effect:
				continue


		if act['wmActivityType'] not in POI_ACT_TYPE or act['wmActivityType'] not in PRICE_ACT_TYPE:
			continue
		if not act['benefitTypeAndValues']:
			continue
		for benefit in act['benefitTypeAndValues']:
			if benefit['benefitType'] != 'ACTIVITY_PRICE':
				continue
			if priority < act['priority']:
				priority = act['priority']
				act_price = float(benefit['benefitValue'])


	return act_price



# def check_act_price_test():



def check_act_price(file_name='../data/act_price_check.csv'):
	timestamp = time.time()

	with open(file_name, "r", encoding='utf-8') as f:
		reader = csv.reader(f, delimiter='\t')
		# header = next(reader)
		# print(header)
		cnt = 0
		for data in reader:
			act_info = data[3]
			sku_id = int(data[0])
			if sku_id in EXCLUDE_SKU_IDS:
				continue
			# act_info = data[3][1:-2]
			# act_info = act_info.replace('""', '"')
			# print(act_info)
			# print("data: " + str(data))
			act_price = compute_act_price(json.loads(act_info), timestamp)
			if not act_price:
				act_price = float(data[1])
			# print("sku: " + str(sku_id) + ", price: " + str(data[1]) + ", act_price: " + str(data[2]) + ", compute_price: " + str(act_price))
			if act_price != float(data[2]):
				print("sku: " + str(sku_id) + ", price: " + str(data[1]) + ", act_price: " + str(data[2]) + ", compute_price: " + str(act_price))
				print("sku: " + str(sku_id))
				cnt += 1
	print(cnt)



if __name__ == '__main__':
	check_act_price()
	# check_act_price('../data/1642683650407.csv')
	# blade_to_act_mq_msg()
	# data = '{"bizType":0,"itemIds":[1308162,1311788,1311791,1312581,1314353],"templateIdList":[20],"type":2,"wmPoiId":601810}\n{"bizType":0,"itemIds":[1308162,1311788,1311791,1312581,1314353],"templateIdList":[20],"type":2,"wmPoiId":601810}'
	# print(send_mq(data))
	



