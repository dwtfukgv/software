#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests
import json


def getProducts(spuId):
    url = 'https://bs.sankuai.com/api/index/rt/create?appName=tspproductares2&ids=' + str(spuId)
    cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; moa_deviceId=578770F794795F8291CADC0A81F79E66; _ga=GA1.2.2141095569.1687141678; _ga_9JGDVD6E56=GS1.2.1687141679.1.0.1687141679.0.0.0; b12de7a4d2_ssoid=eAGFjr1KA0EURlmREFJJKsstky1k7p3ZuXesjKvB0p9CsJGZ3ZlSX8AiSaeQQhtJQIgSsFAUtRHMC9j7CtH1HSyMiLXt4TsfpxotXIxe5-LO1fCzD1hzgIUnqwpcjgG0oqCkYC1Vbsn5AhJSIfhAQrFafYvqzV3vdnJ_4I9SYiLRJqPIpG1GA1lrLRMthhlb1zp-nJx_nUIjwn-P-SdppbIxuH166cPm9GQy6kEvSmqVre3ssPD1-nR8XT5cvh_ffIy65d24vO8uzsed50Gz8Ts-i6p_YcNoKbeoDXAuGawxAGitU4xBsQkoi3QfNCuUCBI0mr3YISMHJmsTqYTI2c0skVKqnUWC_BuMImKR**eAEFwYERADAEBLCVXJW-cfDsP0ITjwMH9l3tAqFByZxF1p0sRs-amS9Fy8QP2M2MbBuuygdTOhLo**Uz8AJ7Ykyotfp4-zcjYFXwgSzXIa4A-oxhU8ym4TACKaUZG8yeQatNHtUKqIRn6Ahd5IPXqCwSW26MlhdyW9qg**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjg3MzM3NDcyMjU2; __appkey=com.sankuai.product.query.bs; __write_appkey=com.sankuai.product.query.bs; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALL/VulVhtG9DBw2EJA37QPCD99XQnMGpOXxIwlFXrB/PBTd7hwRWl99zZ5GhAAAAI219FKSH1suXCS9mu9NmAC/wbA2W4Y8d+PyuuNuQUs6+yMOS; _lxsdk_s=188d948adaf-57-9a1-499%7C%7C9'
    header = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Cookie": cookie,
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded",
    }


    try:
        resp = requests.post(url=url, headers=header)
        print(spuId, json.loads(resp.content)['msg'])
        return json.loads(resp.content)
    except Exception as e:
        print(e)
    return None

if __name__ == '__main__':
    id_list_str = ''
    with open('../data/download.txt', 'r') as f:
        id_list_str = f.readline()
    # id_list_str = '5978729782'
    id_list = id_list_str.split(',')
    
    sz = len(id_list)
    cnt = 0

    for spu_id in id_list:
        cnt += 1
        if getProducts(spu_id) is None:
            print("spu_id:", spu_id, "has async to bs fail")
        if cnt % 100 == 0:
            print("cnt:", cnt, " total:", sz)
		