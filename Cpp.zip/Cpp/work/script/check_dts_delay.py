#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import browsercookie
import requests
from datetime import datetime, timedelta
import json
import sys


cookies = browsercookie.chrome()
site_cookies = []
mws_cookies=''
for cookie in cookies:
    if '.mws.sankuai.com' == cookie.domain or 'rhino.sankuai.com' == cookie.domain:
        site_cookies.append(cookie)
        mws_cookies += cookie.name + '=' + cookie.value + ';'
        
das_url = 'https://das.mws.sankuai.com/api/portal/das/dts/analysis'
time_threshold = 10000
headers = {
    "Authority": "das.mws.sankuai.com",
    "Accept": "application/json, text/plain, */*",
    "Accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Content-type": "application/json",
    "Cookie": mws_cookies
}

def convert_time(time):
    return time[:4] + "-" + time[4:6] + "-" + time[6:8] + "T" + time[8:10] + ":" + time[10:12] + ":" + time[12:]


def check_db_master_slave_delay(task_id, op, begin_time, end_time):
    data = {
        "router": "/api/v1/das/dts/metric/sec-delay-master/trend",
        "payload": {
            "task_id": task_id,
            "begin_at": convert_time(begin_time),
            "end_at": convert_time(end_time),
            "page_size": 5,
            "current": 1
        }
    }
    response = requests.post(url=das_url, data=json.dumps(data), headers=headers)
    res = json.loads(response.content.decode('utf-8'))
    if res['code'] == 0:
        for host in res['data']['data']:
            max_value, time = 0, ''
            for trend in host['data']:
                if trend['value'] and max_value <= trend['value']:
                    max_value = trend['value']
                    time = trend['time']
        print(op, task_id, time, max_value)

        if max_value >= time_threshold / 1000:
            return (task_id, time, max_value)
        return None


def check_dts_delay(task_id, op, begin_time, end_time):
    data = {
        "router": "/api/v1/das/dts/metric/{0}/delay".format(op),
        "payload": {
            "task_id": task_id,
            "begin_at": convert_time(begin_time),
            "end_at": convert_time(end_time),
            "page_size": 5,
            "current": 1
        }
    }
    response = requests.post(url=das_url, data=json.dumps(data), headers=headers)
    res = json.loads(response.content.decode('utf-8'))
    if res['code'] == 0:
        max_value, time = 0, ''
        for host in res['data']:
            for trend in host['trend']:
                if trend['value'] and max_value <= trend['value']:
                    max_value = trend['value']
                    time = trend['time']
                    
        print(op, task_id, time, max_value)
        if max_value >= time_threshold:
            return (task_id, time, max_value)
        return None

    print("查询 dts 任务失败");
    return None
                

sku_dts = {
    "68099": "waimaiproductsku10",
    "68100": "waimaiproductsku20",
    "68101": "waimaiproductsku14",
    "68102": "waimaiproductsku03",
    "68103": "waimaiproductsku13",
    "68104": "waimaiproductsku02",
    "68105": "waimaiproductsku01",
    "68106": "waimaiproductsku12",
    "68107": "waimaiproductsku11",
    "68108": "waimaiproductsku07",
    "68109": "waimaiproductsku18",
    "68110": "waimaiproductsku17",
    "68111": "waimaiproductsku06",
    "68112": "waimaiproductsku05",
    "68113": "waimaiproductsku16",
    "68114": "waimaiproductsku04",
    "68115": "waimaiproductsku15",
    "68116": "waimaiproductsku09",
    "68117": "waimaiproductsku19",
    "68118": "waimaiproductsku08"
}

spu_label_rel_dts = {
    "56451": "waimairelmisc01",
    "56452": "waimairelmisc02"
}

def compute_dts(dts_map, begin_time, end_time, log):
    print("=" * 50 + " start compute {0} dts ".format(log) + " {0} - {1}".format(begin_time, end_time) + "=" * 50)
    error_reader_list, error_writer_list, error_db_list = [], [], []
    for k,v in dts_map.items():
        res = check_dts_delay(k, "reader", begin_time, end_time)
        if res is not None:
            error_reader_list.append(res)
        res = check_dts_delay(k, "writer", begin_time, end_time)
        if res is not None:
            error_writer_list.append(res)
        res = check_db_master_slave_delay(k, "db", begin_time, end_time)
        if res is not None:
            error_db_list.append(res)
            
    print("=" * 150)
    print(log, "reader dts delay:")
    for error_dts in error_reader_list:
        print(dts_map[error_dts[0]], error_dts[1], error_dts[2])
    print(log, "writer dts delay:")
    for error_dts in error_writer_list:
        print(dts_map[error_dts[0]], error_dts[1], error_dts[2])
    print(log, "db dts delay:")
    for error_dts in error_db_list:
        print(dts_map[error_dts[0]], error_dts[1], error_dts[2])

    if not error_reader_list and not error_writer_list:
        print("{0} has no delay".format(log))
    print("=" * 50 + " end compute {0} dts ".format(log) + "=" * 50)
    print()

    
    
def get_time_interval(current_time=datetime.now(), interval=20):
    end_time = current_time.strftime("%Y%m%d%H%M%S")

    current_time = current_time - timedelta(minutes=interval)
    begin_time = current_time.strftime("%Y%m%d%H%M%S")
    return (begin_time, end_time)

def get_current_time(time, interval=20):
    now = datetime.now()
    if len(time) == 14:
        now = now.replace(year=int(time[:4]))
        time = time[4:]
    if len(time) == 10:
        now = now.replace(month=int(time[:2]))
        time = time[2:]
    if len(time) == 8:
        now = now.replace(day=int(time[:2]))
        time = time[2:]
    if len(time) == 6:
        now = now.replace(hour=int(time[:2]))
        time = time[2:]
    if len(time) == 4:
        now = now.replace(minute=int(time[:2]))
        time = time[2:]
    if len(time) == 2:
        now = now.replace(second=int(time))
     
    return get_time_interval(now, interval)


def compute_dts_all(op, begin_time, end_time):
    if op == 'sku':
        compute_dts(sku_dts, begin_time, end_time, "sku")
    elif op == 'spu_label_rel':
        compute_dts(spu_label_rel_dts, begin_time, end_time, "spu_label_rel")


if __name__ == '__main__':
    args = sys.argv

    if len(args) == 1:
        compute_dts(sku_dts, *get_time_interval(), "sku")
        compute_dts(spu_label_rel_dts, *get_time_interval(), "spu_label_rel")
    elif len(args) == 2:
        compute_dts_all(args[1], *get_time_interval())
    elif len(args) == 3:
        compute_dts_all(args[1], *get_current_time(args[2]))
    elif len(args) == 4:
        compute_dts_all(args[1], *get_current_time(args[2], int(args[3])))
