#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import time

import browsercookie

def get_cookie():
    cookies = browsercookie.chrome()
    mws_cookies = ''
    for cookie in cookies:
        if '.mws.sankuai.com' == cookie.domain:
            # print(cookie)
            mws_cookies += cookie.name + '=' + cookie.value + ';'
    return mws_cookies

def get_host_name(env, host):
	pass


def gen_delete_dts(table_name, env, host, port, host_name, binlog):
	data = {}
	data['paramTypes'] = ["java.util.Map<java.lang.String, java.lang.String>","java.lang.String"]
	params = []
	table_info = {}
	table_info['type'] = 'delete'
	table_info['tableName'] = table_name
	table_info['scn'] = "15707690"
	table_info['timestamp'] = str(int(time.time()))
	params.append(table_info)
	params.append(binlog)
	data['params'] = params
	data['env'] = env
	data['oneStepContext'] = {}
	data['foreverContext'] = {}
	data['appkey'] = 'com.sankuai.product.queryasync'
	data['host'] = host
	data['isTest'] = False
	data['port'] = port
	data['node'] = host_name + '(' + port + ')'
	data['serviceName'] = 'commonConsumer.dependency.thrift.DataBusEventServiceV2'
	data['method'] = 'handleDelete(java.util.Map,java.lang.String):String'
	data['invokeType'] = 'NEW'
	# print(json.dumps(data))
	return data


def gen_test_delete_dts(table_name, host, port, host_name, binlog):
	return gen_delete_dts(table_name, "test", host, port, host_name, binlog)


def gen_st_delete_dts(table_name, host, port, host_name, binlog):
	return gen_delete_dts(table_name, "staging", host, port, host_name, binlog)


def del_st_data_dts(cookie, table_name, host, port, host_name, binlog):
	headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
	del_data = gen_st_delete_dts(table_name, host, port, host_name, binlog)
	response = requests.post('https://octo.mws.sankuai.com/api/v1/thriftcheck/genericInvoke', headers=headers, data=json.dumps(del_data))
	print(response.content)
	res = json.loads(response.content.decode('utf-8'))
	return res

def del_test_data_dts(cookie, table_name, host, port, host_name, binlog):
	headers = {'Cookie': cookie, 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
	del_data = gen_test_delete_dts(table_name, host, port, host_name, binlog)
	response = requests.post('https://octo.mws-test.sankuai.com/api/v1/thriftcheck/genericInvoke', headers=headers, data=json.dumps(del_data))
	print(res)
	res = json.loads(response.content.decode('utf-8'))
	return res

# cookie = '_lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _ga=GA1.2.826890099.1621563183; uu=cfb71b50-2b4e-11ec-bd2b-a5fd86896aec; cid=1; ai=1; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; _lxsdk=qinpeifa; moa_deviceId=578770F794795F8291CADC0A81F79E66; WEBDFPID=752133wuv8665uw216z56vuvu55z2u9881393z12z0z979588y9y3wuw-1990508950010-1675148949678AQIMKME75613c134b6a252faa6802015be905511114; _lx_utm=utm_source=xm; logan_session_token=hs0afqjhl3llj0xm532p; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALHVsq7seljNkddDnhg/ME+p1/AppfvYs2RJdJ+rigCFAG9LlIsEyIqVK8OxgAAAAI9zJBLpJJRkOum5I0XQXWaW6dgP8QdLgGfk0r8jMA2v9OwrN; ssoid=eAGFjitLBFEYQLmyyGCSScaJuxPku-_vmlxHF6OPIFjkzn1E_QMGxyJis6koKywYFGWDINZFwa7gH1AnaRCzD8RsPRwOJyGjh927oWxncH30BixRYBhFaSYyx5Tl2jonFQqJzDoPucXIrFG8pDB1T9LWUigXXVgN61Kj1tDRRmgjO8gMLdrTBbSRfrMZpbLHh8_Ld2gS9m8Yf4YmG7ODm4OPV5jb6p9Vt7BJ8pHh-YVizYc0feqd1P3j5-3Tl25Vn_fqi2qskW1c7bWav_IuSf7G9sm45BZoFJ7L0jhLFTcRDYcIvhQoeVyhSiEo0EA558uZicY7HqxUORfBaXQylNpLpoxELeIXELxkXg**eAEFwQkBwDAIA0BL5RtUDinBv4TdmWnouli7iK4pBgVzyc-0O-sOa4izDySEkYxD6u0p8P0tgxJj**hVdNTwSdRsvaQ5ioLujFibeJE9WOzQaufuj1Hl256NJu8snkB6KKFFSgugKy919Kqxdy080xV9Vm7_7SwY_iHw**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjc5MTI3NjUwNjk5; yun_portal_ssoid=eAGFjitLBFEYQLmyyGCSScaJuxPku-_vmlxHF6OPIFjkzn1E_QMGxyJis6koKywYFGWDINZFwa7gH1AnaRCzD8RsPRwOJyGjh927oWxncH30BixRYBhFaSYyx5Tl2jonFQqJzDoPucXIrFG8pDB1T9LWUigXXVgN61Kj1tDRRmgjO8gMLdrTBbSRfrMZpbLHh8_Ld2gS9m8Yf4YmG7ODm4OPV5jb6p9Vt7BJ8pHh-YVizYc0feqd1P3j5-3Tl25Vn_fqi2qskW1c7bWav_IuSf7G9sm45BZoFJ7L0jhLFTcRDYcIvhQoeVyhSiEo0EA558uZicY7HqxUORfBaXQylNpLpoxELeIXELxkXg**eAEFwQkBwDAIA0BL5RtUDinBv4TdmWnouli7iK4pBgVzyc-0O-sOa4izDySEkYxD6u0p8P0tgxJj**hVdNTwSdRsvaQ5ioLujFibeJE9WOzQaufuj1Hl256NJu8snkB6KKFFSgugKy919Kqxdy080xV9Vm7_7SwY_iHw**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNjc5MTI3NjUwNjk5; _lxsdk_s=186ee2661da-0da-41d-058||518'
cookie = 'moa_deviceId=578770F794795F8291CADC0A81F79E66; uu=911473a0-55f1-11ee-998e-15626fb52c1f; cid=1; ai=1; _lxsdk_cuid=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; _lxsdk=179163b9fb5c8-094319e0792ac2-103e6054-1ea000-179163b9fb5c8; s_u_745896=fFRke2aoZ6Ya61iFqEwFiA==; WEBDFPID=15yz87z411805625z234uz4y68y66w418105w8z3y7z979583yx4ww2u-2004575724211-1689215724211WSKWGAK75613c134b6a252faa6802015be905512326; com.sankuai.rds.static_random=; _ga=GA1.2.1205143981.1714111927; _ga_9JGDVD6E56=GS1.2.1714111927.1.0.1714111927.0.0.0; ssoid=eAGFjytIg1EYhjkqYxhElox_MGwLcu7fOSbndBi9gWCR_9wMwhZ-wbLg1jTaFIQpQ4OgiAbBKAjaLRZZmM7oDAaDTsRsfXl4eN40Gt5v3PVFF19PrXdC0xJrSpTQ45EmNnBhsDRa8phgbS3LW6YxxIpzFSY_USa35M2C9WVfFaAAcAk0By1KimpSLEwVcUGR3jYtZdR9fDj6IFlE_xWrn6CJ1Ezr_q3dJbPXt5c3r6SO8oOpuflixflMpt087pwfPG-dvDRqndNm56w2MhBtXu3msr_wDkr_he2hMSJM0EzE0lIBYGLhwOvATIiDBGL5CgFCtOAUMOf8EI1ueFPlzrGAucfgGA9U9t4JBU6G4AzGGpajntJJRQlVecGlhph6zjgTGJQkIKCOhlb9esFanySLlTVf3kb9SVL5BqiveI4**eAEFwQkBACAIBLBKIIdAHD77R3CzxiK8xo3AKnak5DU6h3qnWbzoBFHOhV_T1EfABkfEcH4xahEm**LlQoX6lZNLHc8CdY4wqDrpawKC3ZneMEOFicqysQEOpzDjM4vbKDeBrCwMphwGLtbNPWQWI97rzvLtvS-vNR3Q**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE0NzAyMjU0MDAz; yun_portal_ssoid=eAGFjytIg1EYhjkqYxhElox_MGwLcu7fOSbndBi9gWCR_9wMwhZ-wbLg1jTaFIQpQ4OgiAbBKAjaLRZZmM7oDAaDTsRsfXl4eN40Gt5v3PVFF19PrXdC0xJrSpTQ45EmNnBhsDRa8phgbS3LW6YxxIpzFSY_USa35M2C9WVfFaAAcAk0By1KimpSLEwVcUGR3jYtZdR9fDj6IFlE_xWrn6CJ1Ezr_q3dJbPXt5c3r6SO8oOpuflixflMpt087pwfPG-dvDRqndNm56w2MhBtXu3msr_wDkr_he2hMSJM0EzE0lIBYGLhwOvATIiDBGL5CgFCtOAUMOf8EI1ueFPlzrGAucfgGA9U9t4JBU6G4AzGGpajntJJRQlVecGlhph6zjgTGJQkIKCOhlb9esFanySLlTVf3kb9SVL5BqiveI4**eAEFwQkBACAIBLBKIIdAHD77R3CzxiK8xo3AKnak5DU6h3qnWbzoBFHOhV_T1EfABkfEcH4xahEm**LlQoX6lZNLHc8CdY4wqDrpawKC3ZneMEOFicqysQEOpzDjM4vbKDeBrCwMphwGLtbNPWQWI97rzvLtvS-vNR3Q**NTM5NDQ2MSxxaW5wZWlmYSznp6bln7nlj5EscWlucGVpZmFAbWVpdHVhbi5jb20sMSwwMzIxMTA3OSwxNzE0NzAyMjU0MDAz; s_m_id_3299326472=AwMAAAA5AgAAAAIAAAE9AAAALGsk+x21f/t7SVZFmkUNprn0hPRo/Xz04pNo6T9M9ljpjr0x//BANgwkdfDVAAAAI9yupdxt727kpsB+tb9Pk4CP2zZ5V4DlpuJQTmHdqcFUrr8e; _lxsdk_s=18f2ca730d6-2f2-679-927%7C%7C318'


def del_test_host(data, table_name):
	res =  del_test_data_dts(get_cookie(), table_name, "10.199.124.107", "8902", "set-mt-product-queryasync-test05", json.dumps(data))
	print(res)


def del_st_host(data, table_name):
	# res = del_st_data_dts(get_cookie(), table_name, "10.188.45.55", "8902", "set-zf-product-queryasync-staging08", json.dumps(data));
	res = del_st_data_dts(get_cookie(), table_name, "10.50.22.56", "8902", "set-tx-product-queryasync-staging01", json.dumps(data));
	print(res)

if __name__ == '__main__':
	# data = {}
	# data['id'] = 1304849254
	# data['wm_poi_id'] = 614482
	# data['wm_food_spu_id'] = 12395634
	# res = del_test_data_dts(cookie, "waimai_pic_3.wm_product_spu_pic_82", "10.199.182.47", "8902", json.dumps(data))
	# print(res)

	# 数据库名 + 表名
	data = {}
	data['id'] = 7992402
	data['poi_id'] = 6047571
	# data['wm_poi_id'] = 6047571
	# data['wm_food_spu_id'] = 15079363692
	data['combo_sku_id'] = 23246417697
	data['combo_spu_id'] = 15079363692
	del_st_host(data, "waimai_product_sku_12.combo_group_593")




