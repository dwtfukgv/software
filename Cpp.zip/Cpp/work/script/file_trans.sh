#!/bin/bash
#

cd /opt/meituan
mkdir bs_index
cd bs_index
mv ~/read_bs_doc_id.py ./
ls /opt/meituan/search/bs/data/invt_data/tspproductares/
cp /opt/meituan/search/bs/data/invt_data/tspproductares/segment_1/attr.idx.gz ./attr_1.idx.gz
cp /opt/meituan/search/bs/data/invt_data/tspproductares/segment_2/attr.idx.gz ./attr_2.idx.gz
cp /opt/meituan/search/bs/data/invt_data/tspproductares/segment_3/attr.idx.gz ./attr_3.idx.gz
cp /opt/meituan/search/bs/data/invt_data/tspproductares/segment_4/attr.idx.gz ./attr_4.idx.gz
gunzip attr*
