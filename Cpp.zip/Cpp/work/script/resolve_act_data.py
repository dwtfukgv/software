#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import time


def resolve_db_data(file_name = "../data/act_db_data.json"):
	with open(file_name, "r") as f:
		# f.readlines().join("")
		data = json.loads("".join(f.readlines()))["data"]
		ans = {}
		for i in data:
			ans[int(i['wm_product_spu_id'])] = i
		return ans

def resolve_data(file_name):
	# db_data = resolve_db_data()
	print("(", end="")
	now = int(time.time())
	with open(file_name, "r") as f:
		while True:
			line = f.readline()
			if not line:
				break
			data = json.loads(line)
			if not len(data):
				continue
			act_info = json.loads(data[0]['act_extra_info'])
			if not len(act_info):
				continue
			wm_type = int(act_info[0]['wmUserType'])
			poi_type = int(act_info[0]['poiUserType'])
			if act_info[0]['wmActivityType'] != "DISCOUNT_FOOD":
				continue
			start_time = int(act_info[0]['startTime'])
			end_time = int(act_info[0]['endTime'])
			if now < start_time or now > end_time:
				continue
			if (wm_type == 0 or poi_type == 2) and (wm_type == 2 or poi_type == 0):
				spu_id = int(data[0]['wm_product_spu_id'])
				# print(data[0]['act_price'], db_data[spu_id]['act_price'], db_data[spu_id]['price'])
				print(spu_id, ",", end="")
	print(")")


			

if '__main__' == __name__:
	resolve_data("../data/act_data.txt")