#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import importlib.util,subprocess
import json

cmd = ""
lit_set = ('default', 'waimai-beifang', 'waimai-south', 'waimai-west', 'waimai-east', 'waimai-huabei', 'waimai-huanan', 'waimai-huadong', 'waimai-huazhong', 'waimai-huaxi', 'waimai-first-gray', 'waimai-second-gray')

def update_lion():
    for set_name in lit_set:
        new_cmd = cmd.replace("", lit_set)
        try:
            resp = subprocess.check_output(new_cmd, shell=True)
            res = json.loads(resp)
            print(set_name, res)
        except Exception as e:
            print(e)

if __name__ == '__main__':
    update_lion()