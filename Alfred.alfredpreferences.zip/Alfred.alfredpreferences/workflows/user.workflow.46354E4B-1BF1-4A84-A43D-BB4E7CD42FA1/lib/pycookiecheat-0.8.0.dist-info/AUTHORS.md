# Credits

## Core Contributors

- [Nathan Henrie](http://n8henrie.com) <nate@n8henrie.com>
- [jakob](https://github.com/grandchild) <grandchild@mailbox.org>

## Other Contributors

- <https://github.com/n8henrie/pycookiecheat/graphs/contributors>
